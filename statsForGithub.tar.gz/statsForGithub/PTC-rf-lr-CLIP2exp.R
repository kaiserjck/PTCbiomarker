#----------------------------------------------------------
# Random forest with PTC data
# jck, 2021/08/09
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# libraries
library(caTools)
library(randomForest)
library(caret)
library(MLmetrics)
library(DescTools)
library(scoring)
library(pdp) # for partial dependence plots from many packages!
library(vip)
library(pROC)
library(forcats)

# plotting
library(ggplot2)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

datdir <- "~/gsf/imodel/CLIP2/stats/data"
setwd(datdir)
load(file = "PTC-edited-20210809.Rdata")
dim(df0) # 468  19
names(df0)
#[1] "REBC_ID"      "Sex"          "AaO"          "AaE"          "Dose"         "lPur"         "CLIP2_VST_NT" "CLIP2_VST_TP" "csmDEL14"    
#[10] "csmDEL5p"     "cdelSNVr"     "cID5"         "cID8"         "drv"          "AaO2"         "AaE2"         "TsE"          "TsE2"        
#[19] "Exposed"        

df <- df0
dim(df)

# remove 14 outliers
hist(df$CLIP2_VST_TP)
df <- subset(df, CLIP2_VST_TP > 6)
hist(df$CLIP2_VST_TP)

# exclusion reproduces Fig 2E
#df <- subset(df, cdelSNVr >= 0 & cdelSNVr < 1)

df$CLIP2exp <- df$CLIP2_VST_TP-median(df$CLIP2_VST_TP[df$AaE2 == "unexp"])
df$DoseGy <- df$Dose/1000

df$csmDEL <- df$csmDEL14 + df$csmDEL5p

# only pure tumors: Fig S1
#df <- subset(df, lPur == "no")
dim(df)[1] # 394
#-----------------------------------------------------------------------------------------
# random forest
#-----------------------------------------------------------------------------------------
set.seed(1202)
selline <- c("CLIP2exp",
             "DoseGy","Sex","AaO",
             #"Exposed",
             "AaE",
             "TsE",
             #"AaO2",
             #"AaE2",
             #"TsE2",
             #"CLIP2_VST_NT",
             "csmDEL","cdelSNVr",    
             "cID5","cID8",
             "drv" 
)

cdf <- df[,selline]
str(cdf)
dim(cdf)
cdf <- cdf[complete.cases(cdf[c("CLIP2exp","AaO","AaE","TsE")]),]
#cdf <- subset(cdf, AaO < 20)
dim(cdf)
#cdf <- cdf[complete.cases(cdf[c("drv")]),]
#dim(cdf)
#cdf$AaO <- as.numeric(cdf$AaO)
#cdf$AaE <- as.numeric(cdf$AaE)
#cdf$TsE <- as.numeric(cdf$TsE)
#cdf$csmDEL <- as.numeric(cdf$csmDEL)
#cdf$cID5 <- as.numeric(cdf$cID5)
#cdf$cID8 <- as.numeric(cdf$cID8)
str(cdf)

cdf <- droplevels(cdf)

dim(cdf)
f <- as.formula(CLIP2exp ~ .)
cdf.imp <- rfImpute(f, data = cdf)
#cdf.imp$size <- as.integer(cdf.imp$size)-1 # recast to integer

cdf <- cdf[complete.cases(cdf),]

dim(cdf)
dim(cdf.imp)

cdf <- cdf.imp

hist(cdf[,1])
#---------------------------------------------------
# do it!
#---------------------------------------------------
f <- as.formula(CLIP2exp ~ .)
rf <- randomForest(f, data = cdf,
                   ntree = 1000,
                   #mtry = 4,
                   importance = TRUE,
                   proximity = TRUE)
print(rf)

#-------------------------------------------------------------------------
# some plots
#-------------------------------------------------------------------------
plot(rf)
varImpPlot(rf)
#varUsed(rf)

# extract vimp data
idf <- data.frame(importance(rf))

#------------------------------------------------
# plot X.IncMSE
#------------------------------------------------
both <- data.frame(idf[order(idf$X.IncMSE, decreasing = TRUE),])
pf.1 <- data.frame(rownames(both),as.numeric(both$X.IncMSE))
pf.1 <- data.frame(pf.1)
colnames(pf.1) <- c("Covariable","Value")
pf.1$Covariable <- factor(pf.1$Covariable, levels = pf.1$Covariable[order(pf.1$Value)])
#pf.1$Selected <- "no"
#pf.1$Selected[1:5] <- "yes"
#pf.1$Selected <- as.factor(pf.1$Selected)
pf.1$Covariable <- factor(pf.1$Covariable, levels = pf.1$Covariable[order(pf.1$Value)])

#table(pf.1$Selected,pf.1$Covariable)

fp.1 <- ggplot()+
  ggtitle("X.IncMSE")+
  geom_bar(data = pf.1, aes(y=Covariable, x=Value), stat = "identity", position = "dodge")+
  #scale_fill_manual(values = c("no" = cbPalette[1], "yes" = cbPalette[2])) +
  theme(legend.position=c(.6,.4)) 
print(fp.1)

#---------------------------------------------------------------------------
# GLM regression
#---------------------------------------------------------------------------
mf <- cdf

mf$TsE2 <- fct_relevel(mf$TsE2, "unexp", "<20")
mf$AaE2 <- fct_relevel(mf$AaE2, "unexp", "<5",">=5")

# all CVs
ptc.all <- glm(CLIP2exp ~ ., data = mf) 
summary(ptc.all)

#ptc.Exposed <- glm(CLIP2exp ~ Exposed, data = mf) 
#summary(ptc.Exposed)

ptc.TsE <- glm(CLIP2exp ~ TsE, data = mf) 
summary(ptc.TsE)

ptc.AaE <- glm(CLIP2exp ~ AaE, data = mf) 
summary(ptc.AaE)

#ptc.TsE2 <- glm(CLIP2exp ~ TsE2, data = mf) 
#summary(ptc.TsE2)

#ptc.AaE2 <- glm(CLIP2exp ~ AaE2, data = mf) 
#summary(ptc.AaE2)

ptc.DoseGy <- glm(CLIP2exp ~ DoseGy, data = mf) 
summary(ptc.DoseGy)

ptc.AaO <- glm(CLIP2exp ~ AaO, data = mf) 
summary(ptc.AaO)

ptc.csmDEL <- glm(CLIP2exp ~ csmDEL, data = mf) 
summary(ptc.csmDEL)

ptc.cID8 <- glm(CLIP2exp ~ cID8, data = mf) 
summary(ptc.cID8)

ptc.cID5 <- glm(CLIP2exp ~ cID5, data = mf) 
summary(ptc.cID5)

ptc.cdelSNVr <- glm(CLIP2exp ~ cdelSNVr, data = mf) 
summary(ptc.cdelSNVr)
 
#---------------------------------------------------------------------------
# partial plotting
# ATTENTION: partial is a function from package pdp
#---------------------------------------------------------------------------
vip::vip(rf, bar = FALSE, horizontal = FALSE, size = 1.5, feature_names = "hi")

pdp::partial(ptc.all, pred.var = c("TsE"), plot = T, prob = T) # package pdp
randomForest::partialPlot(rf, pred.data = cdf, x.var = c("TsE"))
randomForest::partialPlot(rf, pred.data = cdf, x.var = c("DoseGy"))

p2 <- pdp::partial(rf, train = cdf, pred.var = "AaO", which.class = 2, plot = TRUE, prob = T,
                   plot.engine = "ggplot2")
print(p2)

headline <- c("Model", "CV", "Value", "prob")
# continuous
# AaO
lAaO <- partial(ptc.AaO, pred.var = c("AaO"), plot = F, prob = T)
lAaO <- cbind("GLM","AaO",lAaO)
names(lAaO) <- headline

rAaO <- partial(rf, train = cdf, pred.var = "AaO", which.class = 2, plot = F, prob = T)
rAaO <- cbind("RF","AaO",rAaO)
names(rAaO) <- headline

# Exposed
#lExposed <- partial(ptc.Exposed, pred.var = c("Exposed"), plot = F, prob = T)
#lExposed <- cbind("GLM","Exposed",lExposed)
#names(lExposed) <- headline

#rExposed <- partial(rf, train = cdf, pred.var = "Exposed", which.class = 2, plot = F, prob = T)
#rExposed <- cbind("RF","Exposed",rExposed)
#names(rExposed) <- headline

# TsE2
lTsE2 <- partial(ptc.TsE2, pred.var = c("TsE2"), plot = F, prob = T)
lTsE2 <- cbind("GLM","TsE2",lTsE2)
names(lTsE2) <- headline

rTsE2 <- partial(rf, train = cdf, pred.var = "TsE2", which.class = 2, plot = F, prob = T)
rTsE2 <- cbind("RF","TsE2",rTsE2)
names(rTsE2) <- headline

# AaE2
lAaE2 <- partial(ptc.AaE2, pred.var = c("AaE2"), plot = F, prob = T)
lAaE2 <- cbind("GLM","AaE2",lAaE2)
names(lAaE2) <- headline

rAaE2 <- partial(rf, train = cdf, pred.var = "AaE2", which.class = 2, plot = F, prob = T)
rAaE2 <- cbind("RF","AaE2",rAaE2)
names(rAaE2) <- headline

# TsE
lTsE <- partial(ptc.TsE, pred.var = c("TsE"), plot = F, prob = T)
lTsE <- cbind("GLM","TsE",lTsE)
names(lTsE) <- headline

rTsE <- partial(rf, train = cdf, pred.var = "TsE", which.class = 2, plot = F, prob = T)
rTsE <- cbind("RF","TsE",rTsE)
names(rTsE) <- headline

# AaE
lAaE <- partial(ptc.AaE, pred.var = c("AaE"), plot = F, prob = T)
lAaE <- cbind("GLM","AaE",lAaE)
names(lAaE) <- headline

rAaE <- partial(rf, train = cdf, pred.var = "AaE", which.class = 2, plot = F, prob = T)
rAaE <- cbind("RF","AaE",rAaE)
names(rAaE) <- headline

# DoseGy
lDoseGy <- partial(ptc.DoseGy, pred.var = c("DoseGy"), plot = F, prob = T)
lDoseGy <- cbind("GLM","DoseGy",lDoseGy)
names(lDoseGy) <- headline
lDoseGy <- subset(lDoseGy, Value <= 2)

rDoseGy <- partial(rf, train = cdf, pred.var = "DoseGy", which.class = 2, plot = F, prob = T)
rDoseGy <- cbind("RF","DoseGy",rDoseGy)
names(rDoseGy) <- headline
rDoseGy <- subset(rDoseGy, Value <= 2)

# csmDEL
lcsmDEL <- partial(ptc.csmDEL, pred.var = c("csmDEL"), plot = F, prob = T)
lcsmDEL <- cbind("GLM","csmDEL",lcsmDEL)
names(lcsmDEL) <- headline

rcsmDEL <- partial(rf, train = cdf, pred.var = "csmDEL", which.class = 2, plot = F, prob = T)
rcsmDEL <- cbind("RF","csmDEL",rcsmDEL)
names(rcsmDEL) <- headline

# cdelSNVr
lcdelSNVr <- partial(ptc.cdelSNVr, pred.var = c("cdelSNVr"), plot = F, prob = T)
lcdelSNVr <- cbind("GLM","cdelSNVr",lcdelSNVr)
names(lcdelSNVr) <- headline

rcdelSNVr <- partial(rf, train = cdf, pred.var = "cdelSNVr", which.class = 2, plot = F, prob = T)
rcdelSNVr <- cbind("RF","cdelSNVr",rcdelSNVr)
names(rcdelSNVr) <- headline

# cID8
lcID8 <- partial(ptc.cID8, pred.var = c("cID8"), plot = F, prob = T)
lcID8 <- cbind("GLM","cID8",lcID8)
names(lcID8) <- headline

rcID8 <- partial(rf, train = cdf, pred.var = "cID8", which.class = 2, plot = F, prob = T)
rcID8 <- cbind("RF","cID8",rcID8)
names(rcID8) <- headline

# cID5
lcID5 <- partial(ptc.cID5, pred.var = c("cID5"), plot = F, prob = T)
lcID5 <- cbind("GLM","cID5",lcID5)
names(lcID5) <- headline

rcID5 <- partial(rf, train = cdf, pred.var = "cID5", which.class = 2, plot = F, prob = T)
rcID5 <- cbind("RF","cID5",rcID5)
names(rcID5) <- headline

#pf.1 <- rbind(lAaO,rAaO,lDoseGy,rDoseGy)
pf.1 <- rbind(lAaO,rAaO,lDoseGy,rDoseGy,lAaE,rAaE,lTsE,rTsE)
summary(pf.1)

#setwd(plotdir)
#write.csv(pf,file="Fig2A.csv")

# data frame of cut points
#xline <- c(55,3,3.5,5.5,10,7.8)
#type <- c("Age","Size","PFprot","PFldh","PFneutroP","PFneutroC")
#xline <- c(55,3,3.5,5.5,7.8)
#type <- c("Age","Size","PFprot","PFldh","PFneutroC")
#cutp <- data.frame(type,xline)
#names(cutp) <- c("CV","value")
#cutp

# data frame of labels
#xline <- c(55,3,3.5,5.5,10,7.8)
#tline <- c("55 yr","3 (> 50 %)","3.5 g/dL","exp(5.5) U/L","10 %","exp(7.8) x 1000/mm3")
#type <- c("Age","Size","PFprot","PFldh","PFneutroP","PFneutroC")
#xline <- c(55,3,3.5,5.5,7.8)
#tline <- c("55 yr","3 (> 50 %)","3.5 g/dL","exp(5.5) U/L","exp(7.8) x 1000/mm3")
#type <- c("AaO","TsE","Dose")
#cutp_text <- data.frame(type,xline,tline)
#names(cutp_text) <- c("CV","Value","char")
#cutp_text

myPalette <- c(cbPalette[2],cbPalette[3])

fp.1 <- ggplot() + 
  geom_point(data = pf.1, aes(x=Value, y=prob, color=Model)) + 
  facet_wrap(. ~ CV, nrow = 2, scales="free_x") + 
  scale_color_manual(values=myPalette) +
  scale_y_continuous(name = "CLIP2 expression (CLIP2_VST_TP)", limits = c(-.3,.5), breaks = seq(-.2,.6,.2)) +
  #geom_vline(data = cutp_text, aes(xintercept = Value, group = CV), linetype="dashed") +
  #geom_label(data = cutp_text, aes(x = xline, y = 0.6, label = tline, group = CV)) +
  #coord_cartesian(ylim = c(0.49, 1.01)) + 
  #guides(color=FALSE) +
  theme(text = element_text(size=15), legend.position=c(.09,.9)) 
print(fp.1)

pf.2 <- rbind(lcsmDEL,rcsmDEL,lcdelSNVr,rcdelSNVr,lcID8,rcID8,lcID5,rcID5)
summary(pf.2)

fp.2 <- ggplot() + 
  geom_point(data = pf.2, aes(x=Value, y=prob, color=Model)) + 
  facet_wrap(. ~ CV, nrow = 2, scales="free_x") + 
  scale_color_manual(values=myPalette) +
  scale_y_continuous(name = "CLIP2 expression (CLIP2_VST_TP)", limits = c(-.3,.5), breaks = seq(-.2,.6,.2)) +
  #geom_vline(data = cutp_text, aes(xintercept = Value, group = CV), linetype="dashed") +
  #geom_label(data = cutp_text, aes(x = xline, y = 0.6, label = tline, group = CV)) +
  #coord_cartesian(ylim = c(0.49, 1.01)) + 
  #guides(color=FALSE) +
  theme(text = element_text(size=15), legend.position=c(.09,.9)) 
print(fp.2)

pf.3 <- rbind(pf.1,pf.2)
pf.3$CV <- fct_relevel(pf.3$CV,c("DoseGy","AaO","cdelSNVr","csmDEL","cID5","cID8"))
fp.3 <- ggplot() + 
  ggtitle("n = 388") + 
  geom_point(data = pf.3, aes(x=Value, y=prob, color=Model)) + 
  facet_wrap(. ~ CV, nrow = 3, scales="free_x") + 
  scale_color_manual(values=myPalette) +
  scale_y_continuous(name = "CLIP2 expression (CLIP2_VST_TP)", limits = c(-.3,.5), breaks = seq(-.2,.6,.2)) +
  #geom_vline(data = cutp_text, aes(xintercept = Value, group = CV), linetype="dashed") +
  #geom_label(data = cutp_text, aes(x = xline, y = 0.6, label = tline, group = CV)) +
  #coord_cartesian(ylim = c(0.49, 1.01)) + 
  #guides(color=FALSE) +
  theme(text = element_text(size=15), legend.position=c(.69,.94)) 
print(fp.3)

pf.4 <- rbind(lAaE2,rAaE2,lTsE2,rTsE2)
summary(pf.1)
fp.4 <- ggplot() + 
  ggtitle("n = 388") + 
  geom_point(data = pf.4, aes(x=Value, y=prob, color=Model)) + 
  facet_wrap(. ~ CV, nrow = 3, scales="free_x") + 
  scale_color_manual(values=myPalette) +
  scale_y_continuous(name = "CLIP2 expression (CLIP2_VST_TP)", limits = c(-.3,.5), breaks = seq(-.2,.6,.2)) +
  #geom_vline(data = cutp_text, aes(xintercept = Value, group = CV), linetype="dashed") +
  #geom_label(data = cutp_text, aes(x = xline, y = 0.6, label = tline, group = CV)) +
  #coord_cartesian(ylim = c(0.49, 1.01)) + 
  #guides(color=FALSE) +
  theme(text = element_text(size=15), legend.position=c(.09,.9)) 
print(fp.4)













