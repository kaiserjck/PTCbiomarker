#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# Plot ERR and others
# jck, 2021/07/03
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
#library(psych) # pairs.panels

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/CLIP2"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#------------------------------------------------------------
# read parameters and covariance matrix
#------------------------------------------------------------
setwd(curvdir)

load(file = "DriverType-ERRdesc-all-no-pd-ps-AaO16.Rdata")
dtf <- desc

load(file = "CLIP2-ERRdesc-all-no-pd-ps-AaO16.Rdata")
c2f <- desc

load(file = "PTC-desc-kaiser2016-AaO16.Rdata")
ref <- desc
ref

#names(dtf)

dtf.poc <- subset(dtf, Estimator == "POC")
c2f.poc <- subset(c2f, Estimator == "POC")
ref.poc <- subset(ref, Estimator == "POC")

pf <- rbind(dtf.poc,c2f.poc,ref.poc)
pf <- droplevels(pf)
summary(pf)

myPalette <- c(cbPalette[2],cbPalette[3],cbPalette[4])

fp.1 <- ggplot() + 
  geom_line(data = pf, aes(x=Dose, y=estmn, color = Marker, group = Marker)) + 
  geom_ribbon(data = ref.poc, aes(x=Dose, ymin = estlo, ymax = esthi, group = Marker), alpha = 0.2) +
  scale_color_manual(values = myPalette, labels = c("CLIP2", "Driver type", "RadEpi")) +
  scale_x_continuous(name = "Thyroid dose (Gy)", limits = c(-0.01,2.01), breaks = seq(0.,2,0.5)) +
  scale_y_continuous(name = "Probability of causation") +
  coord_cartesian(ylim = c(-0.01, 1.01)) + 
  #guides(color=FALSE) +
  theme(text = element_text(size=15)) 
print(fp.1)

#-------------------------------------------------------------
# plotting with risk
#-------------------------------------------------------------

pf <- rbind(c2f.poc[c2f.poc$AaO <= 35,],dtf.poc)
pf <- droplevels(pf)
summary(pf)
ref.poc <- droplevels(ref.poc)
ref.poc <- ref.poc[ref.err$AaO <= 35,]

fp.2 <- ggplot() + 
  geom_line(data = pf, aes(x=Dose, y=estmn, color = Marker, group = Marker, linetype = Marker), size = 1) + 
  geom_line(data = ref.poc, aes(x=Dose, y=estmn, color = POC, group = POC), size = 1) + 
  geom_ribbon(data = ref.poc, aes(x=Dose, ymin = estlo, ymax = esthi), alpha = 0.2) +
  #geom_ribbon(data = dtf.err, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  scale_color_manual(values = myPalette, labels = c("CLIP2 marker", "Driver type marker", "Radiat. Epi.")) +
  scale_linetype_manual(values = c("dashed","solid","solid")) +
  scale_x_continuous(name = "Thyroid dose (Gy)", limits = c(-0.01,2.01), breaks = seq(0.,2,0.5)) +
  scale_y_continuous(name = "Probability of causation") +
  coord_cartesian(ylim = c(-0.01, 1.01)) +
  #guides(color=FALSE) +
  guides(linetype=FALSE) +
  theme(text = element_text(size=15), legend.position = c(0.85,0.8), legend.title = element_blank()) 
print(fp.2)

