#---------------------------------------------------------------------
# REIC calculations for thyroid cancer
# Kaiser et al. 2016, Carcinogenesis
#---------------------------------------------------------------------
rm(list = ls())

set.seed(1234)

maindir <- "~/imodel/CLIP2"
#maindir <- "~/gsf/imodel/UNSCEAR/thyroid/stats"
statsdir <- paste(maindir, "/stats/", sep = "")
modeldir <- paste(maindir, "/stats/models/", sep = "")
figdir <- paste(maindir, "/stats/figures/", sep = "")
curvdir <- paste(maindir, "/stats/curves/", sep = "")
pardir <- paste(maindir, "/stats/parms/", sep = "")
datdir <- paste(maindir, "/data/", sep = "")

# preferred EAR model of Kaiser et al. (2016), supplementary material
npar <- 6

# model parameters
mle <- vector(length=npar)
mle[1] <- 0.934651 # b0
mle[2] <- 3.82178 # lage25
mle[3] <- -0.924536 # bZhy
mle[4] <- 0.000650988 # EAR at 1 Gy
mle[5] <- -0.0891294 # pexp
mle[6] <- 0.428583 # ps

# stdev of model parameters
sig <- vector(length=npar)
sig[1] <- 0.233262
sig[2] <- 0.910587
sig[3] <- 0.233613
sig[4] <- 0.000137203
sig[5] <- 0.0441817
sig[6] <- 0.148712

# correlation matrix (not published)
cm <- matrix(nrow = npar, ncol = npar)
cm[1,1] <- 1
cm[2,2] <- 1
cm[3,3] <- 1
cm[4,4] <- 1
cm[5,5] <- 1
cm[6,6] <- 1

cm[1,2] <- -0.5968583
cm[1,3] <- -0.024594135
cm[1,4] <- -0.41034894
cm[1,5] <- 0.21168522
cm[1,6] <- 0.15159674

cm[2,1] <- cm[1,2]
cm[3,1] <- cm[1,3]
cm[4,1] <- cm[1,4]
cm[5,1] <- cm[1,5]
cm[6,1] <- cm[1,6]

cm[2,3] <- -0.079435127
cm[2,4] <- 0.3105321
cm[2,5] <- -0.11309618
cm[2,6] <- -0.14177574

cm[3,2] <- cm[2,3]
cm[4,2] <- cm[2,4]
cm[5,2] <- cm[2,5]
cm[6,2] <- cm[2,6]

cm[3,4] <- -0.31544076
cm[3,5] <- -0.22129761
cm[3,6] <- 0.0094882587

cm[4,3] <- cm[3,4]
cm[5,3] <- cm[3,5]
cm[6,3] <- cm[3,6]

cm[4,5] <- -0.48327799
cm[4,6] <- -0.36676262

cm[5,4] <- cm[4,5]
cm[6,4] <- cm[4,6]

cm[5,6] <- 0.0484909

cm[6,5] <- cm[5,6]

#covariance matrix
covmat <- cm * sig * rep (sig, each = nrow(cm))

# back to correlation matrix
cov2cor(covmat)

# case-weighted correction factor for oblast Zhytomir vs. Chernihiv & Kyiv
oblfac <- (28*exp(mle[3]) + (115-28))/115
wm <- 6489/13183
wf <- 6694/13183
wm+wf

#--------------------------------------------------------------------
# risk calculations: mvrnorm
#--------------------------------------------------------------------
library(MASS)
# simulate multivariate normal distribution
#sigma <- vcov(fit_ear2)
#pr <- coef(fit_ear2)
nsim = 10000
sigma <- covmat # covariance matrix
pr <- mle # coefficients
Z <- mvrnorm(n=nsim,mu=pr,Sigma=sigma)

apply(Z,2,mean)
apply(Z,2,sd)

#-------------------------------------------------------------
# excess relative risk model
#-------------------------------------------------------------

ERRtot <- function(b0, lage25, ear, pexp, ps, df) 
{ 
  dose <- df$DoseGy
  age <- df$AaO
  
  # DEMs
  sex <- df$msex
  
  # ERR
  ear <- ear*1e4
  earTot <- ear*dose*exp(pexp*dose + ps*sex) 
  
  # baseline
  h0 <- exp(b0 + lage25*log(age/25))
  
  errTot <- earTot/h0
  
  return (errTot)
}

POCtot <- function(b0, lage25, ear, pexp, ps, df) 
{ 
  dose <- df$DoseGy
  age <- df$AaO
  
  # DEMs
  sex <- df$msex
  
  # ERR
  ear <- ear*1e4
  earTot <- ear*dose*exp(pexp*dose + ps*sex) 
  
  # baseline
  h0 <- exp(b0 + lage25*log(age/25))
  
  errTot <- earTot/h0
  
  return (errTot/(1+errTot))
}

mnAaO <- 16
DoseGy <- seq(0,2,0.05)
ndf <- length(DoseGy)
AaO <- rep(mnAaO,ndf)
acen <- log(AaO/25)
msex <- rep(0,ndf)

df <- data.frame(AaO, acen, msex, DoseGy)
summary(df)


# ERR
errmn <- vector()
errlo <- vector()
errmd <- vector()
errhi <- vector()
errsav <- vector()
errmn <- ERRtot(b0=pr[1], lage25=pr[2], ear=pr[4], pexp=pr[5], ps=pr[6], df)
errsav <- unlist(lapply (1:nsim, function(j) ERRtot(b0=Z[j,1], lage25=Z[j,2], ear=Z[j,4], pexp=Z[j,5], ps=Z[j,6], df[1,])))

# POC
pocmn <- vector()
poclo <- vector()
pocmd <- vector()
pochi <- vector()
pocsav <- vector()
pocmn <- POCtot(b0=pr[1], lage25=pr[2], ear=pr[4], pexp=pr[5], ps=pr[6], df)
pocsav <- unlist(lapply (1:nsim, function(j) POCtot(b0=Z[j,1], lage25=Z[j,2], ear=Z[j,4], pexp=Z[j,5], ps=Z[j,6], df[1,])))

# pdf of ERR
for(i in 1:length(AaO))
{
  errsav <- unlist(lapply (1:nsim, function(j) ERRtot(b0=Z[j,1], lage25=Z[j,2], ear=Z[j,4], pexp=Z[j,5], ps=Z[j,6], df[i,]))) 
  errlo[i] <- quantile(errsav, probs = 0.025)
  errmd[i] <- quantile(errsav, probs = 0.5)
  errhi[i] <- quantile(errsav, probs = 0.975)
  
  pocsav <- unlist(lapply (1:nsim, function(j) POCtot(b0=Z[j,1], lage25=Z[j,2], ear=Z[j,4], pexp=Z[j,5], ps=Z[j,6], df[i,])))
  poclo[i] <- quantile(pocsav, probs = 0.025)
  pocmd[i] <- quantile(pocsav, probs = 0.5)
  pochi[i] <- quantile(pocsav, probs = 0.975)
}

#----------------------------------
# save model results
#----------------------------------

if(msex[1] == 0){Sex = "both"}
if(msex[1] == 1){Sex = "female"}
if(msex[1] == -1){Sex = "male"}

headline <- c("Marker","Estimator","AaO","Sex","Dose","estmn","estmd","estlo","esthi")

estimator <- "ERR"
errest <- data.frame("RadEpi",estimator,AaO,Sex,DoseGy,errmn,errmd,errlo,errhi)
names(errest) <- headline
errest


# probability of causation from epidemiology
estimator <- "POC"
pocest <- data.frame("RadEpi",estimator,AaO,Sex,DoseGy,pocmn,pocmd,poclo,pochi)
names(pocest) <- headline
pocest

desc <- rbind(errest,pocest)
summary(desc)

setwd(curvdir)
fbasename <- "PTC-desc-kaiser2016"
fbasename <- paste(fbasename,"AaO",sep="-")
fbasename <- paste(fbasename,as.character(mnAaO),sep="")
fsavname <- paste(fbasename,".Rdata",sep="")
save(desc, file = fsavname)


