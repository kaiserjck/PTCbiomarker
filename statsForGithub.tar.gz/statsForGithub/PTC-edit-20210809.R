#----------------------------------------------------------
# Editing NCI molecular PTC data
# jck, 2021/08/09
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

#------------------------------------------------------------
setwd("~/imodel/CLIP2/stats/data")
load(file = "PTC-selectedCOV-20210809.Rdata")
dim(df0) # 468   14
names(df0)
#[1] "REBC_ID"                   "SEX"                       "AGE_SURGERY"               "AGE_EXPOSURE"             
#[5] "DOSE"                      "Low_Purity"                "CLIP2_VST_NT"              "CLIP2_VST_TP"             
#[9] "SSV_DEL_1_4_Clonal"        "SSV_DEL_5plus_Clonal"      "WGS_TP_N_del_SNV_clonal"   "SigPro_DC83_Clonal_ID5_Ct"
#[13] "SigPro_DC83_Clonal_ID8_Ct" "Designated_DriverType"   

# rename covariables
names(df0) <- c("REBC_ID","Sex","AaO","AaE","Dose","lPur","CLIP2_VST_NT","CLIP2_VST_TP",
                "csmDEL14","csmDEL5p","cdelSNVr","cID5","cID8",
                "drv")
str(df0)

#--------------------------------------------------------------------------
# Factorisation
#--------------------------------------------------------------------------
# Sex
df0$Sex <- factor(df0$Sex, levels = c("female","male"), labels = c("w","m"))
table(df0$Sex, useNA = "ifany")
#    w    m <NA> 
#  335  105   28  

# Low purity
table(df0$lPur, useNA = "ifany")
df0$lPur <- factor(df0$lPur, levels = c("0","1"), labels = c("no","yes"))
table(df0$lPur, useNA = "ifany")
#   no  yes <NA> 
#  356   27   85 

#---------------------------------------------------------
# Driver type fusion vs. mutation
#---------------------------------------------------------
table(df0$drv, useNA = "ifany")
df0$drv[df0$drv == "Fusion.IGF2/IGF2BP3"] <- "Fusion"
df0$drv[df0$drv == "Fusion.OtherRTK"] <- "Fusion"
df0$drv[df0$drv == "Fusion.RET"] <- "Fusion"
df0$drv[df0$drv == "NTRK3-Fusion"] <- "Fusion"
df0$drv[df0$drv == "Mut.BRAF"] <- "Mut"
df0$drv[df0$drv == "Mut.RAS"] <- "Mut"
df0$drv <- factor(df0$drv, levels = c("Mut","Fusion"), labels = c("mut","fus"))
table(df0$drv,useNA = "ifany")
#  mut  fus <NA> 
#  253  176   39 

#------------------------------------------------------
# Age-related categories
#------------------------------------------------------

# only two levels
# AaO2
table(df0$AaO, useNA = "ifany")
df0$AaO2[is.na(df0$AaO)!= T] <- 1
df0$AaO2[df0$AaO > 19 ] <- 2
df0$AaO2 <- factor(df0$AaO2, levels = c(1:2), labels = c("<20",">=20"))
table(df0$AaO2, useNA = "ifany")
t.test(Dose ~ AaO2, data = df0)
tbl <- table(df0$drv,df0$AaO2)
tbl
chisq.test(tbl)

# AaE2
AaE <- df0$AaE
hist(AaE)
df0$AaE2[is.na(AaE)!= T] <- 1
df0$AaE2[AaE >= 5] <- 2
df0$AaE2[df0$Dose == 0] <- 3
df0$AaE2 <- factor(df0$AaE2, levels = c(1:3), labels = c("<5",">=5","unexp"))
table(df0$AaE2, useNA = "ifany") # contains unexposed (n=81)
#table(df0$AaE, useNA = "ifany")

# TsE, TsE2
df0$TsE <- df0$AaO-df0$AaE
hist(df0$TsE)
df0$TsE2 <- NA
df0$TsE2[is.na(df0$TsE)!= T] <- 1
df0$TsE2[df0$TsE >= 20] <- 2
df0$TsE2[df0$Dose == 0] <- 3
df0$TsE2 <- factor(df0$TsE2, levels = c(1:3), labels = c("<20",">=20","unexp"))
table(df0$TsE2, useNA = "ifany")
table(df0$TsE, useNA = "ifany")

# Exposed
df0$Exposed <- NA
df0$Exposed[is.na(df0$Dose)!= T] <- 1
df0$Exposed[is.na(df0$Dose)!= T & df0$Dose > 0] <- 2
df0$Exposed <- factor(df0$Exposed, levels = c(1:2), labels = c("no","yes"))
table(df0$Exposed, useNA = "ifany")

# show NAs
dim(df0) # 468 19
cs <- colSums(!is.na(df0))
cs <- as.data.frame(cs)
print(cs)
#cs
#REBC_ID      468
#Sex          440
#AaO          441
#AaE          360
#Dose         440
#lPur         383
#CLIP2_VST_NT 394
#CLIP2_VST_TP 408
#csmDEL14     356
#csmDEL5p     356
#cdelSNVr     382
#cID5         356
#cID8         356
#drv          429
#AaO2         441
#AaE2         441
#TsE          360
#TsE2         441
#Exposed      440

str(df0)
summary(df0)

setwd("~/imodel/CLIP2/stats/data")
save(df0, file = "PTC-edited-20210809.Rdata")

