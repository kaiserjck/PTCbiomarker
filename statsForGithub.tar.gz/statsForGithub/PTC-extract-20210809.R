#----------------------------------------------------------
# Extracting NCI molecular data
# jck, 2021/08/10
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# read original data file
setwd("~/imodel/CLIP2/stats/data")
test <- read.csv(file = "abg2538-data-S1.csv", sep = ",")
dim(test) # 468 415
str(test)
names(test)
#REBC_ID
#Low_Purity: qualtity filter
#CLIP2_VST_NT
#CLIP2_VST_TP, Fig 5C
# Fig. 2
#SSV_DEL_1_4_Clonal+SSV_DEL_5plus_Clonal, Fig 2B
#WGS_TP_N_del_SNV_clonal, Fig 2E
#SigPro_DC83_Clonal_ID5_Ct, Fig 2E
#SigPro_DC83_Clonal_ID8_Ct, Fig 2K
# Fig .3
#Designated_DriverType, Fig 3B

selline <- c("REBC_ID","SEX", "AGE_SURGERY", "AGE_EXPOSURE", "DOSE", 
              "Low_Purity", # quality filter
              "CLIP2_VST_NT", # Fig. 5C
              "CLIP2_VST_TP", 
              "SSV_DEL_1_4_Clonal","SSV_DEL_5plus_Clonal", # SSV_DEL_1_4_Clonal+SSV_DEL_5plus_Clonal: Fig 2B
              "WGS_TP_N_del_SNV_clonal", # Fig 2E
              "SigPro_DC83_Clonal_ID5_Ct","SigPro_DC83_Clonal_ID8_Ct", # Fig 2H+2K
              "Designated_DriverType" # # Fig 3B
             )

df0 <- test[,selline]
str(df0)
summary(df0)

dim(df0)
save(df0, file = "PTC-selectedCOV-20210809.Rdata")
