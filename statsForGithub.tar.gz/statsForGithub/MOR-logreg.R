#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# logistic regression of driver type data
# jck, 2022/04/29
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
#library(psych) # pairs.panels

library(caTools)

library(DescTools)
library(caret)
library(pROC)
library(reshape2)
library(forcats)
library(rstatix)

library(gnm) # generalized non-linear models
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/CLIP2"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#----------------------------------------------------------
# select marker data 
#----------------------------------------------------------
marker <- character()
#marker <- "CLIP2"
marker <- "DriverType"

setwd(datdir)
{
  if (marker == "CLIP2") {
    load(file = "CLIP2_20210621.Rdata")
    df0 <- thyroid
    # marker
    df0$marker <- 0
    df0$marker[df0$Clip2 == "pos"] <- 1
#    df0$DoseGy[df0$Exposed == "no"] <- 0 # DoseGy is already AaO-adjusted
    } 
  else if (marker == "DriverType") {
    load(file = "PTC-edited-20210809.Rdata")
    df0 <- df0[complete.cases(df0[,c("drv","Dose","AaO","Sex"),]),] # AaE, TsE not considered
    # like Selmansberger et al. 2015
    df0$DoseGy <- df0$Dose/1000
    df0$DoseGy[df0$Dose == 0] <-  df0$AaO[df0$Dose == 0]/1000
    # marker
    df0$marker <- 0
    df0$marker[df0$drv == "fus"] <- 1
    df0$Exposed <- factor(ifelse(df0$Dose > 0, "yes", "no"))} # df0 loaded
}

mmname <- character()
mmname <- "logreg"

fname <- marker
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-","lDose-acen-msex",sep="")
fname
fbasename <- fname

#---------------------------------------------
# PTC marker data
#---------------------------------------------
dim(df0)
#df0$DoseGy[df0$DoseGy > 1] <- 1
#df0$DoseGy[df0$DoseGy == 0] <- df0$AaO/1000
range(df0$Dose) # 0 8800
median(df0$Dose) # 63
median(df0$Dose[df0$Exposed == "yes"]) # 89.5
mean(df0$Dose) # 204.6247
mean(df0$Dose[df0$Exposed == "yes"]) # 250.8114 
#df0 <- subset(df0, DoseGy < 0.05)
#df0 <- subset(df0, AaO2 == "<20")
#df0 <- subset(df0, TsE2 != ">=20")
cene <- 10
cena <- as.integer(mean(df0$AaO)+.5)
df0$ecen <- (df0$AaE-cene)/10
#df0$acen <- log(df0$AaO/cena)
df0$acen <- (df0$AaO-cena)/10
df0$msex <- 1
df0$msex[df0$Sex == "m"] <- -1
table(df0$Sex,df0$msex)
table(df0$marker,df0$drv)
#   mut fus
# 0 253   0
# 1   0 176
table(df0$marker,df0$Exposed)

df0$lDose <- log(df0$DoseGy)

# Dose groups
df0$D3 <- 1
df0$D3[df0$Dose > 0] <- 2
df0$D3[df0$Dose >= 100] <- 3
df0$D3 <- factor(df0$D3, levels = 1:3, labels = c("unexp","<100",">=100"))
table(df0$D3, useNA = "ifany")
# unexp  <100 >=100 
#    79   188   162  

#TsE 17 wg. Selmansberger 2015
df0$TsE17 <- NA
df0$TsE17[df0$Exposed == "no"] <- 1
df0$TsE17[df0$TsE < 17] <- 2
df0$TsE17[df0$TsE >= 17] <- 3
df0$TsE17 <- factor(df0$TsE17, levels = 1:3, labels = c("unexp","<17",">=17"))
table(df0$TsE17, useNA = "ifany")
# unexp   <17  >=17 
#    70    56   294  
aggregate(df0$AaO,list(df0$TsE17),mean)
#   Group.1        x
# 1   unexp 20.68354
# 2     <17 23.51786
# 3    >=17 30.73810
aggregate(df0$Dose,list(df0$TsE17),mean)
#   Group.1        x
# 1   unexp   0.0000
# 2     <17 356.6786
# 3    >=17 230.6463

# handle
df <- df0
dim(df) #  429  27
str(df)
summary(df)

df$TsE2 <- fct_relevel(df$TsE2, c("unexp", "<20", ">=20"))
df$AaE2 <- fct_relevel(df$AaE2, c("unexp", "<5", ">=5"))

# Age means
aggregate(df$AaO,list(df$AaO2),mean)
aggregate(df$AaO,list(df$AaE2),mean)
aggregate(df$AaO,list(df$TsE2),mean)

cuts <- data.frame(Ref = c("median\n0.090 Gy", "gmean\n0.104 Gy", "amean\n0.251 Gy"),
                   vals = c(median(df$DoseGy[df$Exposed == "yes"]), exp(mean(log(df$DoseGy[df$Exposed == "yes"]))), 
                            mean(df$DoseGy[df$Exposed == "yes"])),
                   stringsAsFactors = FALSE)

ggplot(df[df$Exposed == "yes",], aes(x=DoseGy)) + 
  ggtitle("Exposed, n = 350") +
  geom_histogram(aes(y=..density..),      # Histogram with density instead of count on y-axis
                 binwidth=.1,
                 colour="black", fill="white") +
  geom_density(alpha=.2, fill="#FF6666") +   # Overlay with transparent density plot
  scale_x_log10(name = "Thyroid dose (Gy)") +
  geom_vline(mapping = aes(xintercept = vals, colour = Ref), data = cuts, show.legend = F) +
  geom_text(mapping = aes(x = vals,
                          y = c(1.2,1.1,1),
                          label = Ref,
                          hjust = -.1,
                          vjust = -.1),
            data = cuts) +
  theme(text = element_text(size=15)) 
#-----------------------------------------------------
# TsE2 and AaE2 dependence
#-----------------------------------------------------

aggregate(df$Dose,list(df$TsE2),mean)
#   Group.1        x
# 1   unexp   0.0000
# 2     <20 257.5769
# 3    >=20 247.9512

# gmeans
signif(exp(aggregate(df$lDose,list(df$TsE2),mean)$x), 3) # 0.0201 0.1120 0.1010
signif(exp(aggregate(df$lDose,list(df$TsE17),mean)$x), 3) # 0.0201 0.1580 0.0963

# LRTs for single cofactor Dose
m.1.d <- glm(drv ~ lDose, data = subset(df, TsE17 != ">=17"), family = binomial) # with TsE2 < 20
summary(m.1.d)
delDev <- m.1.d$null.deviance - deviance(m.1.d)
delDev
p.LRT.1 <- pchisq(delDev, 1, lower.tail = F)
p.LRT.1

m.2.d <- glm(drv ~ lDose, data = subset(df, TsE17 != "<17"), family = binomial) # with TsE2 >= 20
summary(m.2.d)
delDev <- m.2.d$null.deviance - deviance(m.2.d)
delDev
p.LRT.2 <- pchisq(delDev, 1, lower.tail = F)
p.LRT.2

m.3.d <- glm(drv ~ lDose + AaO + Sex, data = subset(df, TsE17 != "unexp"), family = binomial) 
summary(m.3.d)
delDev <- m.3.d$null.deviance - deviance(m.3.d)
delDev
p.LRT.3 <- pchisq(delDev, 1, lower.tail = F)
p.LRT.3

signif(p.adjust(c(p.LRT.1,p.LRT.2,p.LRT.3), method = "bonferroni", n = 3), 3) # 1.16e-05 9.04e-02 1.83e-13

m.0.d <- glm(drv ~ lDose, data = df, family = binomial) # all
summary(m.0.d)
delDev <- m.0.d$null.deviance - deviance(m.0.d)
delDev
p.LRT.0 <- pchisq(delDev, 1, lower.tail = F)
p.LRT.0

# LRTs for Dose, adjusted by AaO, Sex
m.1.0 <- glm(drv ~ AaO + Sex, data = subset(df, TsE17 != ">=17"), family = binomial) # with TsE17 < 17
m.1.d <- glm(drv ~ lDose + AaO + Sex, data = subset(df, TsE17 != ">=17"), family = binomial) # with TsE17 < 17
summary(m.1.d)
delDev <- deviance(m.1.0) - deviance(m.1.d)
delDev
p.LRT.1 <- pchisq(delDev, 1, lower.tail = F)
p.LRT.1

m.2.0 <- glm(drv ~ AaO + Sex, data = subset(df, TsE17 != "<17"), family = binomial) # with TsE17 >= 17
m.2.d <- glm(drv ~ lDose + AaO + Sex, data = subset(df, TsE17 != "<17"), family = binomial) # with TsE17 >= 17
summary(m.2.d)
delDev <- deviance(m.2.0) - deviance(m.2.d)
delDev
p.LRT.2 <- pchisq(delDev, 1, lower.tail = F)
p.LRT.2

m.3.0 <- glm(drv ~ AaO + Sex, data = subset(df, TsE17 != "unexp"), family = binomial) 
m.3.d <- glm(drv ~ lDose + AaO + Sex, data = subset(df, TsE17 != "unexp"), family = binomial) 
summary(m.3.d)
delDev <- deviance(m.3.0) - deviance(m.3.d)
delDev
p.LRT.3 <- pchisq(delDev, 1, lower.tail = F)
p.LRT.3

signif(p.adjust(c(p.LRT.1,p.LRT.2,p.LRT.3), method = "bonferroni", n = 3), 3) # 7.95e-06 4.68e-04 6.17e-04, TsE2
# 2.72e-05 1.44e-04 6.17e-04, TsE17

m.0.0 <- glm(drv ~ AaO + Sex, data = df, family = binomial) 
m.0.d <- glm(drv ~ lDose + AaO + Sex, data = df, family = binomial) 
summary(m.3.d)
delDev <- deviance(m.3.0) - deviance(m.3.d)
delDev
p.LRT.0 <- pchisq(delDev, 1, lower.tail = F)
p.LRT.0

# chisq tests
tbl <- with(table(drv,TsE17), data = droplevels(subset(df, TsE17 != ">=17"))) # with TsE2 < 20
tbl
p.chi.1 <- chisq.test(tbl)$p.value # p-value = 0.005944, TsE2
p.chi.1 # 0.001167637, TsE17

tbl <- with(table(drv,TsE17), data = droplevels(subset(df, TsE17 != "<17"))) # with TsE2 >= 20
tbl
p.chi.2 <- chisq.test(tbl)$p.value # p-value = 0.6278, TsE2
p.chi.2 # 0.9430583, TsE17

tbl <- with(table(drv,TsE17), data = droplevels(subset(df, TsE17 != "unexp")))
tbl
p.chi.3 <- chisq.test(tbl)$p.value # p-value = 1.727e-05
p.chi.3 # 2.90081e-05, TsE17

signif(p.adjust(c(p.chi.1,p.chi.2,p.chi.3), method = "bonferroni", n = 3), 3) # 1.78e-02 1.00e+00 5.18e-05, TsE2
# 3.5e-03 1.0e+00 8.7e-05, TsE17

tbl <- with(table(drv,TsE17), data = df)
tbl
p.chi.0 <- chisq.test(tbl)$p.value # p-value = 4.607856e-05, TsE2
p.chi.0 # 6.757556e-05, TsE17

# exclusion reproduces Fig 2E
df.1 <- subset(df, cdelSNVr >= 0 & cdelSNVr < 1)
aggregate(df.1$cdelSNVr,list(df.1$TsE17),mean, na.rm = T)
pairwise_t_test(cdelSNVr ~ TsE17, p.adjust.method = "bonferroni", data = df.1)
summary(glm(cdelSNVr ~ DoseGy, data = subset(df.1, TsE17 != ">=17"))) # with TsE2 < 20
summary(glm(cdelSNVr ~ DoseGy, data = subset(df.1, TsE17!= "<17"))) # with TsE2 >= 20

aggregate(df$Dose,list(df$AaE2),mean)
#   Group.1        x
# 1   unexp   0.0000
# 2      <5 359.7087
# 3     >=5 188.7937
summary(glm(drv ~ DoseGy, data = subset(df, AaE2 != ">=5"), family = binomial)) # with AaE2 < 5
summary(glm(drv ~ DoseGy, data = subset(df, AaE2 != "<5"), family = binomial)) # with AaE2 >= 5

tbl <- with(table(drv,AaE2), data = droplevels(subset(df, AaE2 != ">=5")))  # with AaE2 < 5
tbl
chisq.test(tbl)

tbl <- with(table(drv,AaE2), data = droplevels(subset(df, AaE2 != "<5"))) # with AaE2 >= 5
tbl
chisq.test(tbl)

tbl <- table(df$AaO2, df$marker)
tbl
chisq.test(tbl) # p-value = 0.002119

tbl <- table(df$marker,df$Exposed)
tbl
signif(chisq.test(tbl)$p.value, 3) # p-value = 0.629

# dose groups
tbl <- with(table(drv,D3), data = droplevels(subset(df, D3 != ">=100")))
tbl
signif(chisq.test(tbl)$p.value, 3) # pvalue = 0.282

tbl <- with(table(drv,D3), data = droplevels(subset(df, D3 != "<100")))
tbl
signif(chisq.test(tbl)$p.value, 3) # pvalue = 0.0195

tbl <- with(table(drv,D3), data = droplevels(subset(df, D3 != "unexp")))
tbl
signif(chisq.test(tbl)$p.value, 3) # p-value =  5.4e-06

summary(glm(drv ~ D3 + AaO + Sex, data = subset(df, D3 != "<100"), family = binomial)) 
summary(glm(drv ~ D3 + AaO + Sex, data = subset(df, D3 != ">=100"), family = binomial)) 
summary(glm(drv ~ D3 + AaO + Sex, data = subset(df, D3 != "unexp"), family = binomial)) 

#-----------------------------------------------------
# logistic regression
#-----------------------------------------------------

#summary(glm(marker ~ lDose, data = subset(df, AaO < 20), family = "binomial"))

dim(df)[1] # 429

lor.0 <- glm(marker ~ acen + msex, data = df, family = "binomial")
summary(lor.0)

lor.1 <- glm(marker ~ lDose + acen + msex, data = df, family = "binomial")
summary(lor.1)

# likelihood ratio test
dDev <- deviance(lor.0) - deviance(lor.1)
dDev # 27.70411
pchisq(dDev, df = 1, lower.tail = F) # 1.413617e-07

lor.2 <- glm(marker ~ lDose*acen + msex, data = df, family = "binomial")
summary(lor.2)
dDev <- deviance(lor.1) - deviance(lor.2)
dDev # 5.458868
pchisq(dDev, df = 1, lower.tail = F) # 0.01946925

prob = predict(lor.2,type=c("response"))
g <- roc(marker ~ prob, data=df)
auc(g) # Area under the curve: 0.6989
ci.auc(g) # 95% CI: 0.6478-0.75 (DeLong)
BrierScore(df$marker, prob) # 0.2095989

pLevel <- length(df$marker[df$marker == 1])/length(df$marker)
pLevel
pred <- factor(ifelse(prob > pLevel, "yes", "no"))
refe <- factor(ifelse(df$marker == 1, "yes", "no"))
confusionMatrix(reference = refe, data = pred, positive = "yes")

#------------------------------------------
# assign working model
#------------------------------------------
mle.1 <- lor.1
#mle.1 <- lor.2
#mle.1 <- lor.3

#--------------------------------------------------------------------------
# prepare plot data
#--------------------------------------------------------------------------
critval <- 1.96 ## approx 95% CI
cena
acenMin <- (10-cena)/10
acenMax <- (45-cena)/10
doseMin <- 0.01
doseMax <- 2
msex <- 0

# Create a sequence of incrementally increasing (by selected units) values for both AaO and DoseGy
xgrid <-  seq(acenMin, acenMax, 0.05)
length(xgrid)
ygrid <-  seq(doseMin, doseMax, doseMin)
ygrid <-  c(doseMin/100, ygrid)
length(ygrid)
# Generate a matrix with every possible combination of AaO and DoseGy
data.new <-  expand.grid(acen = xgrid, DoseGy = ygrid, msex = 0)
dim(data.new)

# melt in long form
df.melt <- melt(data.new, id.vars = c("acen","DoseGy","msex"))
df.melt$lDose <- log(df.melt$DoseGy)
df.melt$AaO <- df.melt$acen*10+cena
is.data.frame(df.melt)
head(df.melt)
dim(df.melt)
ndf <- dim(df.melt)[1]
ndf

preds <- predict(mle.1,type=c("link"), newdata = df.melt, se.fit = TRUE)
ERR.hi <- exp(preds$fit + (critval * preds$se.fit))
ERR.lo <- exp(preds$fit - (critval * preds$se.fit))
ERR.mle <- exp(preds$fit)

preds <- predict(mle.1,type=c("response"), newdata = df.melt, se.fit = TRUE)
POC.hi <- preds$fit + (critval * preds$se.fit)
POC.lo <- preds$fit - (critval * preds$se.fit)
POC.mle <- preds$fit

if(msex[1] == 0){Sex = "both"}
if(msex[1] == 1){Sex = "female"}
if(msex[1] == -1){Sex = "male"}

headline <- c("Marker","Estimator","AaO","Sex","Dose","estmn","estlo","esthi")

# excess relative risk
estimator <- "ERR"
errest <- data.frame(marker,estimator,df.melt$AaO,Sex,df.melt$DoseGy,ERR.mle,ERR.lo,ERR.hi)
names(errest) <- headline
head(errest)

# probability of causation among positive markers
estimator <- "POC"
pocest <- data.frame(marker,estimator,df.melt$AaO,Sex,df.melt$DoseGy,POC.mle,POC.lo,POC.hi)
names(pocest) <- headline
pocest

desc <- rbind(errest,pocest)
summary(desc)

setwd(curvdir)
fsavname <- paste(fbasename,"-2d.Rdata",sep="")
fsavname
save(desc, file = fsavname)

#--------------------------------------------------------------------------
# prepare plot data
#--------------------------------------------------------------------------
critval <- 1.96 ## approx 95% CI

AaO <- seq(10,45,1)
#acen <- log(AaO/cena)
acen <- (AaO-cena)/10
ndf <- length(AaO)
msex <- rep(0,ndf) # both sexes
DoseGy <- rep(0.2,ndf)
lDose <- log(DoseGy)

df <- data.frame(AaO, acen, msex, DoseGy, lDose)
summary(df)

preds <- predict(mle.1,type=c("link"), newdata = df, se.fit = TRUE)
ERR.hi <- exp(preds$fit + (critval * preds$se.fit))
ERR.lo <- exp(preds$fit - (critval * preds$se.fit))
ERR.mle <- exp(preds$fit)

preds <- predict(mle.1,type=c("response"), newdata = df, se.fit = TRUE)
POC.hi <- preds$fit + (critval * preds$se.fit)
POC.lo <- preds$fit - (critval * preds$se.fit)
POC.mle <- preds$fit

if(msex[1] == 0){Sex = "both"}
if(msex[1] == 1){Sex = "female"}
if(msex[1] == -1){Sex = "male"}

headline <- c("Marker","Estimator","AaO","Sex","Dose","estmn","estlo","esthi")

# excess relative risk
estimator <- "ERR"
errest <- data.frame(marker,estimator,AaO,Sex,DoseGy,ERR.mle,ERR.lo,ERR.hi)
names(errest) <- headline
errest

# probability of causation among positive markers
estimator <- "POC"
pocest <- data.frame(marker,estimator,AaO,Sex,DoseGy,POC.mle,POC.lo,POC.hi)
names(pocest) <- headline
pocest

desc <- rbind(errest,pocest)
summary(desc)

setwd(curvdir)
fbasename <- paste(fbasename,"intact",sep="-")
fsavname <- paste(fbasename,"-2d.Rdata",sep="")
fsavname
#save(desc, file = fsavname)

