#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# Calculation of ERR with binomial likelihood
# jck, 2021/06/27
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
#library(psych) # pairs.panels

library(caTools)
library(caret)
library(pROC)

library(gnm) # generalized non-linear models
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)



# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/CLIP2"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#----------------------------------------------------------
# select marker data 
#----------------------------------------------------------
marker <- character()
#marker <- "CLIP2"
marker <- "DriverType"

setwd(datdir)
{
  if (marker == "CLIP2") {
    load(file = "CLIP2_20210621.Rdata")
    df0 <- thyroid
    # marker
    df0$marker <- 0
    df0$marker[df0$Clip2 == "pos"] <- 1
    df0$DoseGy[df0$Exposed == "no"] <- 0
    } 
  else if (marker == "DriverType") {
    load(file = "PTC-edited-20210511.Rdata")
    df0 <- df0[complete.cases(df0[,c("CLIP2_VST_TP","drv","Dose","AaO","AaE","TsE"),]),]
    # like Selmansberger et al. 2015
    df0$DoseGy <- df0$Dose/1000
    #df0$DoseGy[df0$Dose == 0] <-  df0$AaO[df0$Dose == 0]/1000
    # marker
    df0$marker <- 0
    #df0$marker[df0$drv == "fus"] <- 1
    df0$CLIP2exp <- df0$CLIP2_VST_TP-(median(df0$CLIP2_VST_TP[df0$AaE2 == "unexp"]-0.0))
    df0$marker[df0$CLIP2exp > 0] <- 1
    df0$Exposed <- factor(ifelse(df0$Dose > 0, "yes", "no"))} # df0 loaded
}

mmname <- character()
mmname <- "ERRdesc"

fname <- marker
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-","all-no-pd-ps-trunc1Gy",sep="")
fname

#---------------------------------------------
# PTC marker data
#---------------------------------------------
#df0$DoseGy[df0$DoseGy > 1] <- 1
#range(df0$Dose)
df0 <- subset(df0, TsE2 != ">=20" & DoseGy < 0.125)
#df0 <- subset(df0, AaO2 == "<20")
cene <- 10
cena <- as.integer(mean(df0$AaO)+.5)
df0$ecen <- (df0$AaE-cene)/10
df0$acen <- log(df0$AaO/cena)
df0$msex <- -1
df0$msex[df0$Sex == "w"] <- 1
table(df0$Sex,df0$msex)
table(df0$marker,df0$drv)
#  mut fus
#0 227   0
#1   0 156
table(df0$marker,df0$Exposed)

# handle
df <- df0
dim(df)
str(df)
summary(df)

# Age means
aggregate(df$AaO,list(df$AaO2),mean)


aggregate(df$AaO,list(df$AaE2),mean)


aggregate(df$AaO,list(df$TsE2),mean)

#-----------------------------------------------------
# logistic regression
#-----------------------------------------------------

#dim(df)[1] 
#lor.1 <- glm(marker ~ lDose+AaO, data = df[df$Exposed == "yes",], family = "binomial")
#summary(lor.1)

#prob = predict(lor.1,type=c("response"))
#g <- roc(marker ~ prob, data=df)
#auc(g) # Area under the curve: 0.6967
#ci.auc(g) # 95% CI: 0.6428-0.7506 (DeLong)
#BrierScore(df$marker, prob) # 0.2084802

#pLevel <- length(df$marker[df$marker == 1])/length(df$marker)
#pLevel
#pred <- factor(ifelse(prob > pLevel, "yes", "no"))
#refe <- factor(ifelse(df$marker == 1, "yes", "no"))
#confusionMatrix(reference = refe, data = pred, positive = "yes")

#----------------------------------------------------------
# binomiL likelihood regression
#----------------------------------------------------------
setwd(statdir)
source("./subscripts/binlik.R")

{ # this bracket is needed!
  if (mmname == "ERRdesc")
  {
    sdeviance <- binlik_ERRdescC0a_deviance
    smloglik <- binlik_ERRdescC0a_mloglik
  }
  else
  {
    print("Not implemented\n")
  }
}

# read start pars
setwd(pardir)
parDF <- read.csv ("DriverType-ERRdesc-all-no-ps_parms.csv")

upar <- vector()
upar <- as.numeric(parDF$parval)
#upar[1] <- 1
#upar[2:5] <- 0
#upar[6] <- 0

npar <- length(upar[upar != 0])
system.time(
        dev <- sdeviance(upar[1], upar[2], upar[3], upar[4], upar[5], upar[6], df)
)
dev 
dev+2*npar

# optimisation
mmcall = 0
durat<- system.time(
        mle.1 <- mle2(minuslog = smloglik,
                      start=list(err = upar[1], ps = upar[2], pa = upar[3], pd = upar[4], c0 = upar[5], c1 = upar[6]), 
                      parameters=list(err~1, ps~1, pa~1, pd~1, c0~1, c1~1), 
                      fixed=list(
                      #err = upar[1],
                      ps = 0,
                      pa = 0,
                      #pd = 0,
                      #c0 = 0
                      c1 = 0
                      ),
                      #lower = c(err = 0, c0 = 0),
                      #upper = c(err = 20, c0 = 1),
                      #lower = c(err = 0, pa = -7, c0 = 0.1),
                      #upper = c(err = 20, pa = -3, c0 = 3),
                      lower = c(err = 0, pd = -100, c0 = 0.3),
                      upper = c(err = 200, pd = 100, c0 = 3),
                      #lower = c(err = 0, pa = -5, c0 = 0),
                      #upper = c(err = 100, pa = 0, c0 = 10),
                      #lower = c(err = 1e-4, pe = -4, pa = -2),
                      #upper = c(err = 1000, pe = 2, pa = 10),
                      method = "L-BFGS-B",
                      #method = "CG",
                      #method = "Brent",
                      data = df)
) # system.time
durat

cat(sprintf("Total calls: %d", mmcall))

summary(mle.1)
AIC(mle.1)

# correlation matrix
#is.positive.definite(vcov(mle.1),tol = 1e-5)
cov2cor(vcov(mle.1))
is.positive.definite(vcov(mle.1), tol = 1e-10)
isPD <- all(1 == sign(eigen(vcov(mle.1))$values)) # check if all eigenvalues > 0
isPD

#park <- mle.1
#mle.1 <- park

upar <- coef(mle.1)

#deviance(mle.1)[1] - dev0

# likelihood profile and confidence intervals
#mmcall = 0
pl <- profile(mle.1)
plot(pl)
coef(pl)
upar <- coef(pl)
lp.CI <- confint(pl)
round(lp.CI,5)
has.profile <- TRUE
#---------------------------------------------------------------
# write model parameters to file
#---------------------------------------------------------------
setwd(pardir)
parms <- data.frame (coef(mle.1))
names(parms)[c(1)] <- c("parval")
parms_adj <- data.frame(coef(mle.1,exclude.fixed=TRUE))
names(parms_adj)[c(1)] <- c("parval")

is.fixed <- !row.names(parms) %in% row.names(parms_adj) # create vector denoting fixed parameters 
fixpar <- data.frame (coef(mle.1)[is.fixed]) # fixed coefficients
names(fixpar)[c(1)] <- c("parval")

all(row.names(parms) %in% row.names(parms_adj))

ffname <- fname
f1 <- paste(ffname,"_parms.csv",sep="")
f2 <- paste(ffname,"_vcov.csv",sep="")
f3 <- paste(ffname,"_protocol.txt",sep="")

# parameters
write.csv(parms, file = f1, quote = F)

# covariance matrix
if (isPD == TRUE)
{
  cat(sprintf("--> write covariance matrix\n"))
  write.csv(vcov(mle.1), file = f2, quote = F)
  #  write.csv(vcov(mle.1), file = f2, quote = F)
}

# protocol
# start writing to file
sink(f3)

# write items
cat(sprintf("\n--> Model run: %s <--\n", ffname))
cat(sprintf("              PTCs: %d\n", length(df$marker)))
cat(sprintf("    Unexposed PTCs: %d\n", length(df$marker[df$Exposed == "no"])))
cat(sprintf("          Mean AaO: %6.1f (sd: %6.1f) yr\n", mean(df$AaO), sd(df$AaO)))
cat(sprintf("         Mean dose: %6.3f (median: %6.3f) Gy\n", mean(df$DoseGy), median(df$DoseGy)))
cat(sprintf(" Marker 'yes'/'no': %5d/%5d\n", sum(df$marker), length(df$marker) - sum(df$marker)))
cat(sprintf("       Share 'yes': %6.3f\n", sum(df$marker)/length(df$marker)))
cat(sprintf("        AaO center: %2d\n", cena))
#cat(sprintf("      MeanSz: %6.3f cm\n", sum(ad$size*ad$npat)/sum(ad$npat)))
#cat(sprintf("\n Detection limit (Lnd spacing)\n          smin: %6.3f cm\n          ymin: %6d cells\n", smin, df$ymin[1]))

cat(sprintf("\n"))
summary(mle.1)

savpar <- coef(mle.1)
npar <- length(savpar[savpar != 0])
dev <- sdeviance(savpar[1], savpar[2], savpar[3], savpar[4], savpar[5], savpar[6], df)
oAIC <- dev+2*npar
#cat(sprintf("deviance: %8.1f\n", dev))
cat(sprintf("     AIC: %7.1f\n", oAIC))
cat(sprintf("isPosDef: %s\n", isPD))
{ # print 95% CI if available
  if (has.profile == TRUE)
  {
    cat(sprintf("\nLikelihood profile CI\n"))
    print(lp.CI)
  }
}
cat(sprintf("\n"))

if (all(row.names(parms) %in% row.names(parms_adj)) == FALSE)
{cat(sprintf("\nFixed coefficients\n"))
  fixpar
}
if (all(row.names(parms) %in% row.names(parms_adj)) == FALSE) {cat(sprintf("\n"))}

cat(sprintf(" Total calls:  %4d\n", mmcall))
eltime <- as.numeric(durat[3])/60
cat(sprintf("Elapsed time: %6.2f min\n    per call: %6.2g sec\n",eltime, eltime*60/mmcall)) 
cat(sprintf("   Timestamp: %s", Sys.time()))

# stop writing to file
sink()

   