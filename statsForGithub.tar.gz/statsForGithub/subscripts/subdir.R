#------------------------------------------------------------------------------
# directory structure
#------------------------------------------------------------------------------

# subdirectories
statdir <- paste(dir, "/stats", sep = "")
datdir <- paste(statdir,"/data", sep = "")
curvdir <- paste(statdir,"/curves",sep = "")
plotdir <- paste(statdir,"/plots",sep = "")
pardir <- paste(statdir, "/parms", sep = "")
resdir <- paste(statdir, "/results", sep = "")
#figdir <- paste(dir, "/writeup/figures", sep = "")
