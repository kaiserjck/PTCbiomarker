
# model call counting
mmcall <- 0
mdl_call <- function() 
{
  mmcall <<- mmcall + 1 # global counter <<-
  if (mmcall < 10)
  {
    strg <- sprintf("Call: %d", mmcall)
    print(strg, quote = F)
  }
  else if (mmcall >= 10 & mmcall < 100)
  {
    if ((mmcall %% 10) == 0)
    {strg <- sprintf("Call: %d", mmcall)
    print(strg, quote = F)} 
  }
  else
  {
    if ((mmcall %% 100) == 0)
    {strg <- sprintf("Call: %d", mmcall)
    print(strg, quote = F)} 
  }
  return(mdl_call)
}

#---------------------------------------------------------
# binomial likelihood functions
#---------------------------------------------------------

binlik_ERRdesc_deviance <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  acen <- df$acen
  marker <- df$marker
  
  ERR <- (1+err*DoseGy*exp(ps*msex + pa*acen + pd*DoseGy))*exp(c0 + c1*acen)
  ppos <- ERR/(1+ERR)
  
  binlli <- vector()
  binlli <- marker*log(ppos) + (1-marker)*log(1-ppos)
  lnlik <- sum(binlli)
  return (-2*lnlik)
}

binlik_ERRdesc_mloglik <- function(err, ps, pa, pd, c0, c1)
{
  mdl_call()
  
  ERR <- (1+err*DoseGy*exp(ps*msex + pa*acen + pd*DoseGy))*exp(c0 + c1*acen)
  ppos <- ERR/(1+ERR)
  
  binlli <- vector()
  binlli <- marker*log(ppos) + (1-marker)*log(1-ppos)
  lnlik <- sum(binlli)
  
  return (-lnlik)
}

POC_ERRdesc <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  acen <- df$acen
  
  ERR <- (1+err*DoseGy*exp(ps*msex + pa*acen + pd*DoseGy))*exp(c0 + c1*acen)
  ppos <- ERR/(1+ERR)
  
  return (ppos)
}

ERR_ERRdesc <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  acen <- df$acen
  
  ERR <- (1+err*DoseGy*exp(ps*msex + pa*acen + pd*DoseGy))*exp(c0 + c1*acen)
  return (ERR)
}

ERRepi_ERRdesc <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  acen <- df$acen
  
  ERR <- err*DoseGy*exp(ps*msex + pa*acen + pd*DoseGy)*exp(c0 + c1*acen)
  
  return (ERR)
}

binlik_EARdesc_deviance <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  acen <- df$acen
  marker <- df$marker
  
  ERR <- err*DoseGy*exp(ps*msex + pa*acen + pd*DoseGy) + exp(c0 + c1*acen) 
  ppos <- ERR/(1+ERR)
  
  binlli <- vector()
  binlli <- marker*log(ppos) + (1-marker)*log(1-ppos)
  lnlik <- sum(binlli)
  return (-2*lnlik)
}

binlik_EARdesc_mloglik <- function(err, ps, pa, pd, c0, c1)
{

  mdl_call()
  
  ERR <- err*DoseGy*exp(ps*msex + pa*acen + pd*DoseGy) + exp(c0 + c1*acen) 
  ppos <- ERR/(1+ERR)
  
  binlli <- vector()
  binlli <- marker*log(ppos) + (1-marker)*log(1-ppos)
  lnlik <- sum(binlli)
  return (-lnlik)
}

POC_EARdesc <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  acen <- df$acen
  
  ERR <- err*DoseGy*exp(ps*msex + pa*acen + pd*DoseGy) + exp(c0 + c1*acen)  
  ppos <- ERR/(1+ERR)
  
  return (ppos)
}

ERR_EARdesc <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  acen <- df$acen
  
  ERR <- err*DoseGy*exp(ps*msex + pa*acen + pd*DoseGy) + exp(c0 + c1*acen) 
  return (ERR)
}

ERRepi_EARdesc <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  acen <- df$acen
  
  ERR <- err*DoseGy*exp(ps*msex + pa*acen + pd*DoseGy) 
  return (ERR)
}

logitlike_morton_deviance <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  AaO <- df$AaO
  acen <- df$acen
  marker <- df$marker
  
  #OR <- pd + c0*msex + c1*AaO + err*DoseGy
  #ppos <- 1/(1+exp(-OR))
  OR <- exp(c0 + ps*msex + pa*(AaO-28)/10)*(1 + err*DoseGy*exp(pd*DoseGy))
  ppos <- OR/(1+OR)
  
  logitli <- vector()
  logitli <- marker*log(ppos) + (1-marker)*log(1-ppos)
  lnlik <- sum(logitli)
  return (-2*lnlik)
}

logitlike_morton_mloglik <- function(err, ps, pa, pd, c0, c1)
{
  mdl_call()
  
  #OR <- pd + c0*msex + c1*AaO + err*DoseGy
  #ppos <- 1/(1+exp(-OR))
  OR <- exp(c0 + ps*msex + pa*(AaO-28)/10)*(1 + err*DoseGy*exp(pd*DoseGy))
  ppos <- OR/(1+OR)
  
  logitli <- vector()
  logitli <- marker*log(ppos) + (1-marker)*log(1-ppos)
  lnlik <- sum(logitli)
  
  return (-lnlik)
}

POC_logitlike_morton <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  acen <- df$acen
  
  OR <- exp(c0 + ps*msex + pa*acen)*(1 + err*DoseGy*exp(pd*DoseGy))
  ppos <- OR/(1+OR)

  return (ppos)
}

ERR_logitlike_morton <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  acen <- df$acen
  
  OR <- exp(c0 + ps*msex + pa*acen)*(1 + err*DoseGy*exp(pd*DoseGy))
  
  return (OR)
}

ERRepi_logitlike_morton <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  acen <- df$acen
  
  OR <- exp(c0 + ps*msex + pa*acen)*err*DoseGy*exp(pd*DoseGy) # ERR(epi)

  return (OR)
}

logit_morton_deviance <- function(err, ps, pa, pd, c0, c1, df)
{
  msex <- df$msex
  DoseGy <- df$DoseGy
  AaO <- df$AaO
  acen <- df$acen
  marker <- df$marker
  
  #OR <- pd + c0*msex + c1*AaO + err*DoseGy
  #ppos <- 1/(1+exp(-OR))
  OR <- exp(c0 + ps*msex + pa*(AaO-28)/10 + err*DoseGy)
  ppos <- OR/(1+OR)
  
  logitli <- vector()
  logitli <- marker*log(ppos) + (1-marker)*log(1-ppos)
  lnlik <- sum(logitli)
  return (-2*lnlik)
}

logit_morton_mloglik <- function(err, ps, pa, pd, c0, c1)
{
  mdl_call()
  
  #OR <- pd + c0*msex + c1*AaO + err*DoseGy
  #ppos <- 1/(1+exp(-OR))
  OR <- exp(c0 + ps*msex + pa*(AaO-28)/10 + err*DoseGy)
  ppos <- OR/(1+OR)
  
  logitli <- vector()
  logitli <- marker*log(ppos) + (1-marker)*log(1-ppos)
  lnlik <- sum(logitli)
  
  return (-lnlik)
}