#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# Calculation of ERR with binomial likelihood
# jck, 2022/05/03
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
#library(psych) # pairs.panels

library(caTools)
library(caret)
library(pROC)
library(reshape2)

library(gnm) # generalized non-linear models
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)


# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/CLIP2"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#------------------------------------------------------------
# read parameters and covariance matrix
#------------------------------------------------------------
setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
#fbasename <- "DriverType-ERRdesc-err-pa-ps-c0-c1-linAa0"
#fbasename <- "DriverType-ERRdesc-true-err-pa-c0-c1"
#fbasename <- "CLIP2-ERRdesc-c0-AaOlt20"
#fbasename <- "DriverType-EARdesc-err-pa-c0-c1-linAa0"
fbasename <- "DriverType-morton-err-c0-ps-pa"


namvec <- strsplit(fbasename, split ="-")

marker <- namvec[[1]][1]
mmname <- namvec[[1]][2]

f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")
#exit <- file.exists("peduncular-all-distboth-m-K0-agAS2_parms.csv")
#ifelse(exit == T, mat <- read.csv(file = fname), "no")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#--------------------------------------------------------------------
# uncertainty calculations: mvrnorm
#--------------------------------------------------------------------
library(MASS)
# simulate multivariate normal distribution
nsim = 10000
sigma <- data.matrix(dcov[,-1]) # covariance matrix, skip first column containing row names

# hack: make sigma symmetric
sigma[upper.tri(sigma)] <- t(sigma)[upper.tri(sigma)]

cat(sprintf("--> CovMat dimens: %d\n", dim(sigma)[1]))
cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma, tol = 1e-20)))
cat(sprintf("--> CovMat eigenv: '%s'\n", all(1 == sign(eigen(sigma)$values)))) # check if all eigenvalues > 0
has.cov <- dpar$X %in% dcov$X # create vector denoting parameters present in dcov
pr <- dpar$parval[has.cov] # coefficients present in dcov

if (is.positive.definite(sigma,tol = 1e-20) == TRUE)
{Z <- mvrnorm(n=nsim,mu=pr,Sigma=sigma)}

apply(Z,2,mean)
apply(Z,2,sd)

#---------------------------------------------------------
# matrix of simulated parameters for uncertainty calculations
#--------------------------------------------------------- 
is.complete <- all(dpar$X %in% dcov$X) # check if dcov parameter set is complete
{ # if statement
  if(is.complete) {
    
    df.par <- data.frame(Z)
    colnames(df.par) <- dpar$X
    
  } else {
    
    nmpar <- dim(dpar[!has.cov,])[1] # no. of fixed parameters (not present in dcov)
    Y <- matrix(ncol = nmpar, nrow = nsim) # define matrix with NAs
    #dpar$parval[!has.cov]
    for(i in 1:nmpar)
    {
      Y[1:nsim,i] <- dpar$parval[!has.cov][i] # assign fixed parameter estimates to nsim rows
    }
    df.par <- data.frame(cbind(Z,Y)) # combine simulated and fixed parameters and convert to data frame
    colnames(df.par) <- c(dpar$X[has.cov],dpar$X[!has.cov]) # assign parameter names to columns
    df.par <- df.par[,dpar$X] # sort columns to original order
    
  }
} # end of if statement

summary(df.par)

#--------------------------------------------------------------------------
# prepare plot data
#--------------------------------------------------------------------------
setwd(statdir)
source("./subscripts/binlik.R")

{ # this bracket is needed!
  if (mmname == "ERRdesc")
  {
    POCdesc <- POC_ERRdesc
    ERRdesc <- ERR_ERRdesc
    ERRepi <- ERRepi_ERRdesc
  }
  else if (mmname == "EARdesc")
  {
    POCdesc <- POC_EARdesc
    ERRdesc <- ERR_EARdesc
    ERRepi <- ERRepi_EARdesc
  }
  else if (mmname == "morton")
  {
    POCdesc <- POC_logitlike_morton
    ERRdesc <- ERR_logitlike_morton
    ERRepi <- ERRepi_logitlike_morton
  }
  else
  {
    print("Not implemented\n")
  }
}
upar <- vector()
upar <- as.numeric(dpar$parval)
upar

{
if (marker == "DriverType"){cena <- 28}
  else if (marker == "CLIP2"){cena <- 17} # 21 for all AaO
}
#--------------------------------------------------------------------------
# prepare plot data
#--------------------------------------------------------------------------
cena
acenMin <- (10-cena)/10
acenMax <- (45-cena)/10
doseMin <- 0.1
doseMax <- 1
msex <- 0

# Create a sequence of incrementally increasing (by selected units) values for both AaO and DoseGy
xgrid <-  seq(acenMin, acenMax, 0.05)
length(xgrid)
#ygrid <-  seq(doseMin, doseMax, 0.9)
ygrid <-  c(0, 0.1, 0.2, 1)
length(ygrid)
# Generate a matrix with every possible combination of AaO and DoseGy
data.new <-  expand.grid(acen = xgrid, DoseGy = ygrid, msex = 0)
dim(data.new)

# melt in long form
df.melt <- melt(data.new, id.vars = c("acen","DoseGy","msex"))
is.data.frame(df.melt)
head(df.melt)
dim(df.melt)
ndf <- dim(df.melt)[1]
ndf

errsav <- list()
errlo <- vector()
errhi <- vector()
errmle <- vector()
episav <- list()
epilo <- vector()
epihi <- vector()
epimle <- vector()
pocsav <- list()
poclo <- vector()
pochi <- vector()
pocmle <- vector()
# loop of nsim sets of simulated parameters
for(i in 1:ndf)
{
  errmle[i] <- ERRdesc(upar[1], upar[2], upar[3], upar[4], upar[5], upar[6], df.melt[i,])
  errsav <- unlist(lapply (1:nsim, function(j) ERRdesc(df.par[j,1], df.par[j,2], df.par[j,3], df.par[j,4], 
                                                      df.par[j,5], df.par[j,6], df.melt[i,])))
  errlo[i] <- quantile(errsav, probs = 0.025)
#  errmd[i] <- quantile(errsav, probs = 0.5)
  errhi[i] <- quantile(errsav, probs = 0.975)
  
  epimle[i] <- ERRepi(upar[1], upar[2], upar[3], upar[4], upar[5], upar[6], df.melt[i,])
  episav <- unlist(lapply (1:nsim, function(j) ERRepi(df.par[j,1], df.par[j,2], df.par[j,3], df.par[j,4], 
                                                       df.par[j,5], df.par[j,6], df.melt[i,])))
  epilo[i] <- quantile(episav, probs = 0.025)
#  epimd[i] <- quantile(episav, probs = 0.5)
  epihi[i] <- quantile(episav, probs = 0.975)
 
  pocmle[i] <- POCdesc(upar[1], upar[2], upar[3], upar[4], upar[5], upar[6], df.melt[i,])
  pocsav <- unlist(lapply (1:nsim, function(j) POCdesc(df.par[j,1], df.par[j,2], df.par[j,3], df.par[j,4], 
                                                       df.par[j,5], df.par[j,6], df.melt[i,])))
  poclo[i] <- quantile(pocsav, probs = 0.025)
#  pocmd[i] <- quantile(pocsav, probs = 0.5)
  pochi[i] <- quantile(pocsav, probs = 0.975)
}

#----------------------------------
# save model results
#----------------------------------

if(msex == 0){Sex = "both"}
if(msex == 1){Sex = "female"}
if(msex == -1){Sex = "male"}

headline <- c("Marker","Estimator","AaO","Sex","Dose","estmn","estlo","esthi")

DoseGy <- df.melt$DoseGy
AaO <- df.melt$acen*10+cena

estimator <- "ERR"
errest <- data.frame(marker,estimator,AaO,Sex,DoseGy,errmle,errlo,errhi)
names(errest) <- headline
head(errest)

estimator <- "ERRepi"
epiest <- data.frame(marker,estimator,AaO,Sex,DoseGy,epimle,epilo,epihi)
names(epiest) <- headline
head(epiest)

# probability of causation among positive markers
estimator <- "POC"
pocest <- data.frame(marker,estimator,AaO,Sex,DoseGy,pocmle,poclo,pochi)
names(pocest) <- headline
head(pocest)

desc <- rbind(errest,epiest,pocest)
summary(desc)

setwd(curvdir)
fsavname <- paste(fbasename,"-2d.Rdata",sep="")
fsavname
save(desc, file = fsavname)
