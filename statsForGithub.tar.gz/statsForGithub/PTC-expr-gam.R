#----------------------------------------------------------
# CLIP2 expression
# jck, 2021/07/28
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# libraries
library(caTools)
library(randomForest)
library(caret)
library(MLmetrics)
library(DescTools)
library(scoring)
library(pdp) # for partial dependence plots from many packages!
library(vip)
library(pROC)
library(rstatix)
library(psych)

# plotting
library(ggplot2)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

datdir <- "~/imodel/CLIP2/stats/data"
setwd(datdir)
load(file = "PTC-edited-20210511.Rdata")
dim(df0)
names(df0)
#[1] "Sex"          "AaO"          "AaE"          "Dose"         "CLIP2_VST_NT" "CLIP2_VST_TP" "cdelSNVr"     "cID8"         "drv"         
#[10] "C2rat"        "C2sur"        "AaEcat"       "AaE2"         "AaOcat"       "AaO2"         "TsE"          "TsE2"         "Dcat"        
#[19] "D3" 

#df <- subset(df0, Dose < 2000)


#---------------------------------------------------------------------------------
# CLIP2 expression
#---------------------------------------------------------------------------------
df <- df0
dim(df)
set.seed(1503)
df <- df[complete.cases(df[c("CLIP2_VST_TP","Sex","AaO","AaE","TsE","Dose")]),]
#df <- df[complete.cases(df[c("CLIP2_VST_TP","Dose")]),]
dim(df[df$AaO2 == "<20",])[1]

#df$Dose[df$Dose > 1000] <- 1000

df$DoseAaO <- df$Dose + df$AaO

dim(df) # 369   19
hist(df$CLIP2_VST_TP)
hist(df$CLIP2_VST_TP[df$AaO2 == "<20"])
df <- subset(df, CLIP2_VST_TP > 6) # remove outliers
dim(df)# 356 19
hist(df$CLIP2_VST_TP)
hist(df$CLIP2_VST_TP[df$AaO2 == "<20"])
df$Exposed <- 1
df$Exposed[df$Dose > 0] <- 2
df$Exposed <- factor(df$Exposed, levels = 1:2, labels = c("no","yes"))
table(df$Exposed,df$AaE2)
# no yes 
# 66 290 

hist(log10(df$DoseAaO))

df$D5 <- 1
df$D5[df$Dose > 0] <- 2
df$D5[df$Dose > 50] <- 3
df$D5[df$Dose > 100] <- 4
df$D5[df$Dose > 200] <- 5

df$D5 <- factor(df$D5, levels = 1:5, labels = c("unexp","<50","50-100","100-200",">200"))
table(df$D5)

df$D3 <- 1
df$D3[df$Dose > 0] <- 2
df$D3[df$Dose > 100] <- 3

df$D3 <- factor(df$D3, levels = 1:3, labels = c("unexp","<=100",">100"))
table(df$D3)

t.test(data = df, CLIP2_VST_TP ~ Sex)
t.test(data = df, CLIP2_VST_TP ~ Exposed)
dim(df[df$AaO2 == "<20",])[1] # 32
t.test(data = df[df$AaO2 == "<20",], CLIP2_VST_TP ~ Exposed)
t.test(data = df[df$TsE2 != ">=20",], CLIP2_VST_TP ~ Exposed)

pwc <- pairwise_t_test(CLIP2_VST_TP ~ TsE2, p.adjust.method = "bonferroni", data = df)
pwc
pwc <- pairwise_t_test(CLIP2_VST_TP ~ D5, p.adjust.method = "bonferroni", data = df)
pwc
pwc <- pairwise_t_test(CLIP2_VST_TP ~ D3, p.adjust.method = "bonferroni", data = df)
pwc


#---------------------------------------------------------------------------
# GLM regression
#---------------------------------------------------------------------------
mf <- df

mf$CLIP2exp <- mf$CLIP2_VST_TP-median(mf$CLIP2_VST_TP[mf$AaE2 == "unexp"])

dim(mf)[1] # 356

aggregate(df$TsE,list(df$TsE2),mean)
aggregate(df$Dose,list(df$TsE2),mean)
aggregate(df$Dose,list(df$TsE2),length)
aggregate(df$Dose,list(df$D5),mean)
aggregate(df$Dose,list(df$D5),length)
aggregate(df$Dose,list(df$Exposed),mean)

# TsE2
ptc.1 <- glm(CLIP2exp ~ TsE2, data = mf) 
summary(ptc.1)

ptc.2 <- glm(CLIP2exp ~ AaE2, data = mf) 
summary(ptc.2)

ptc.3 <- glm(CLIP2exp ~ Exposed, data = mf[mf$TsE2 != ">=20",]) 
summary(ptc.3)

ptc.4 <- glm(CLIP2exp ~  D3 + Sex, data = mf[mf$TsE2 != ">=20",])
summary(ptc.4)

ptc.5 <- glm(CLIP2exp ~  D3 + Sex, data = mf) 
summary(ptc.5)

ptc.6 <- glm(CLIP2exp ~  Dose + Sex, data = mf[mf$Dose <= 100 & mf$TsE2 != ">=20",]) 
summary(ptc.6)

ptc.7 <- glm(CLIP2exp ~  Dose + Sex, data = mf[mf$Dose <= 50,]) 
summary(ptc.7)

ptc.8 <- glm(CLIP2exp ~  Dose + Sex, data = mf[mf$AaO < 20 & mf$Dose < 100,]) 
summary(ptc.8)

ptc.9 <- glm(CLIP2exp ~  Dose:AaO2 + Sex, data =  mf[mf$Dose < 100,]) 
summary(ptc.9)

ptc.10 <- glm(CLIP2exp ~  Dose + Sex, data =  mf[mf$D3 != ">100",]) 
summary(ptc.10)

ptc.11 <- glm(CLIP2exp ~ Exposed, data = mf[mf$D3 != ">100",]) 
summary(ptc.11)

Dose = seq(0,1000,10)
predict(ptc.9, newdata = data.frame(Dose))

#---------------------------------------------------------------------------
# GAM regression
#---------------------------------------------------------------------------

library(mgcv)
gam.1 <-gam(CLIP2exp ~  te(Dose,AaO,k=7) + TsE2, data = mf)
summary(gam.1)
deviance(gam.1)
AIC(gam.1)
hist(predict(gam.1))

gam.2 <-gam(CLIP2exp ~  s(Dose) + TsE2, data = mf[mf$Dose < 200,], method = "REML")
summary(gam.2)
deviance(gam.2)
AIC(gam.2)
gam.check(gam.2)
hist(predict(gam.2))

gam.3 <-gam(CLIP2exp ~  D5 + s(AaO), data = mf[mf$TsE2 != ">=20",], method = "REML")
summary(gam.3)
deviance(gam.3)
AIC(gam.3)
gam.check(gam.3)
hist(predict(gam.3))


Dose <- seq(0,2000,50)
Dose <- aggregate(df$Dose,list(df$D5),mean)$x
D5 <- c("unexp","<50","50-100","100-200",">200")
ndf <- length(Dose)


pdf <- data.frame(Dose,D5,20,"<20","w")
names(pdf) <- c("Dose","D5","AaO","TsE2","Sex")
summary(pdf)

plot(x=Dose, y=predict(gam.1, newdata = pdf))
plot(x=Dose, y=predict(ptc.4, newdata = pdf))

pl <- profile(ptc.9)
plot(pl)
coef(pl)
upar <- coef(pl)
lp.CI <- confint(pl)
round(lp.CI,5)
has.profile <- TRUE


#-------------------------------------------------------------------------
# box plots
#-------------------------------------------------------------------------

bp.1 <- ggplot() +
  geom_boxplot(data = mf[mf$TsE2 != ">=20",], aes(x=Exposed,y=CLIP2_VST_TP)) +
  geom_jitter(data = mf[mf$TsE2 != ">=20",], aes(x=Exposed,y=CLIP2_VST_TP)) + 
  geom_label(aes(x=1.5, y = 8, label = "p = 0.009")) +
  geom_label(aes(x=1, y = 8, label = "n = 66")) +
  geom_label(aes(x=2, y = 8, label = "n = 107 (TsE < 20 yr)"))
bp.1 <- bp.1 + scale_x_discrete(name = "Exposed") + 
  scale_y_continuous(name = "CLIP2_VST_TP",limits=c(8,12.5), breaks = seq(8,12,1)) +
  theme_gray() + 
  theme(text = element_text(size=15))

print(bp.1)

bp.2 <- ggplot() +
  geom_boxplot(data = mf[mf$TsE2 != ">=20",], aes(x=Exposed,y=CLIP2exp)) +
  geom_jitter(data = mf[mf$TsE2 != ">=20",], aes(x=Exposed,y=CLIP2exp)) + 
  geom_label(aes(x=1.5, y = 8, label = "p = 0.009")) +
  geom_label(aes(x=1, y = 8, label = "n = 66")) +
  geom_label(aes(x=2, y = 8, label = "n = 107 (TsE < 20 yr)"))
bp.2 <- bp.2 + scale_x_discrete(name = "Exposed") + 
  scale_y_continuous(name = "CLIP2exp",limits=c(-3,3), breaks = seq(-3,3,1)) +
  theme_gray() + 
  theme(text = element_text(size=15))

print(bp.2)


library(ggdist)
bp.3 <- ggplot(data = mf[mf$TsE2 != ">=20",]) +
  aes(x = Exposed, y = CLIP2exp, fill = Exposed, width = 0.7) +
  scale_fill_manual(values = c(cbPalette[3],cbPalette[2])) +
  ggdist::stat_halfeye(adjust = 0.5, justification = -0.2, .width = 0, point_color = NA, alpha = 0.5) + 
  geom_boxplot(width = 0.15, alpha = 1) + 
  ggdist::stat_dots(side = "left", justification = 1.15, binwidth = 0.05, color = NA, alpha = 0.5) + 
  #geom_text(aes(x=1.5, y = 1.7, label = "p = 0.009")) +
  #geom_text(aes(x=1, y = 2, label = "n = 66")) +
  #geom_text(aes(x=2, y = 2, label = "n = 107\n(TsE < 20 yr)")) +
  theme(text = element_text(size=15), legend.position = "none")
print(bp.3)


selline <- c("CLIP2exp","AaO","AaE","TsE","Dose")
cdf <- mf[mf$Exposed == "yes",]
cdf <- subset(cdf, Dose < 100)
cdf$Dose <- log10(cdf$Dose+1)
pairs.panels(cdf[,selline],
             smooth = FALSE,
             ellipses = FALSE,
             gap=0,
             bg =c("blue","red")[as.integer(cdf$drv)], 
             #             bg =c("#E69F00", "#56B4E9")[as.integer(df$ucsex)],
             pch = 21)











