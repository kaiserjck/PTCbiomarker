#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# Plot ERR and others
# jck, 2021/07/03
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
library(forcats)
#library(psych) # pairs.panels

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/Nextcloud/imodel/CLIP2"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#------------------------------------------------------------
# read parameters and covariance matrix
#------------------------------------------------------------
setwd(curvdir)

load(file = "CLIP2-logreg-lDose-acen-msex-intact.Rdata")
c2f <- desc

c2f.err <- subset(c2f, Estimator == "ERR")
dim(c2f.err)

load(file = "DriverType-logreg-lDose-AaE-msex-intact.Rdata")
dtf <- desc

dtf.err <- subset(dtf, Estimator == "ERR")
dim(dtf.err)

#-------------------------------------------------------------
# plotting with risk
#-------------------------------------------------------------
pf.AaE <- subset(dtf.err, AaE == 3 | AaE == 8 | AaE == 13 | AaE == 18)
#pf.AaO <- subset(mtrx.melt, AaO == 15 |  AaO == 20 | AaO == 25)
head(pf.AaE)

#myPalette <- c(cbPalette[2],cbPalette[3],cbPalette[4])
myPalette <- cbPalette

fp.1 <- ggplot() + 
  geom_line(data = pf.AaE, aes(x=Dose, y=estmn, group=factor(AaE), color=factor(AaE)), size = 1) + 
  #geom_ribbon(data = pf, aes(x=AaO, ymin = estlo, ymax = esthi, group = factor(AaO)), alpha = 0.2) +
  #geom_line(data = ref.err, aes(x=AaO, y=estmn, color = ERR, group = ERR), size = 1) + 
  #geom_ribbon(data = ref.err, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  #geom_ribbon(data = dtf.err, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  scale_color_manual(values = cbbPalette[2:8], name = "AaE (yr)") +
  #scale_linetype_manual(values = c("dashed","solid","solid")) +
  scale_x_continuous(name = "Thyroid dose (Gy)", limits = c(0,1), breaks = seq(0,1,0.2)) +
  scale_y_continuous(name = "Excess Relative Risk at 1 Gy", limits = c(0,100), breaks = seq(0,20,5)) +
  coord_cartesian(ylim = c(0,10)) +
  theme(text = element_text(size=15), legend.position = c(0.75,0.85)) 
print(fp.1)

pf.Dose <- subset(dtf.err, (Dose > 0.009 & Dose < 0.011) | (Dose > 0.09 & Dose < 0.11) | Dose == 0.5 | Dose == 1)
head(pf.Dose)

#myPalette <- c(cbPalette[2],cbPalette[3],cbPalette[4])
myPalette <- cbPalette

fp.2 <- ggplot() + 
  geom_line(data = pf.Dose, aes(x=AaE, y=estmn, group=factor(Dose), color=factor(Dose)), size = 1) + 
  #geom_ribbon(data = pf.Dose, aes(x=AaE, ymin = estlo, ymax = esthi, group = factor(Dose)), alpha = 0.2) +
  #geom_line(data = ref.err, aes(x=AaE, y=estmn, color = ERR, group = ERR), size = 1) + 
  #geom_ribbon(data = ref.err, aes(x=AaE, ymin = estlo, ymax = esthi), alpha = 0.2) +
  #geom_ribbon(data = dtf.err, aes(x=AaE, ymin = estlo, ymax = esthi), alpha = 0.2) +
  scale_color_manual(values = cbbPalette[2:8], name = "Dose (Gy)") +
  #scale_linetype_manual(values = c("dashed","solid","solid")) +
  scale_x_continuous(name = "Age at exposure (yr)", limits = c(0,19), breaks = seq(5,15,5)) +
  scale_y_continuous(name = "Excess Relative Risk", limits = c(0,100), breaks = seq(0,20,5)) +
  coord_cartesian(ylim = c(0,10)) +
  theme(text = element_text(size=15), legend.position = c(0.75,0.85)) 
print(fp.2)



