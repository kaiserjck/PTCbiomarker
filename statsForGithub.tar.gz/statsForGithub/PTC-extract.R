#----------------------------------------------------------
# Extracting NCI CLIP2 data
# jck, 2021/05/11
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# read original data file
setwd("~/imodel/CLIP2/stats/data")
test <- read.csv(file = "abg2538-data-S1.csv", sep = ",")
dim(test)
str(test)
names(test)
#CLIP2_VST_NT
#CLIP2_VST_TP
#WGS_TP_N_del_SNV_clonal
#SigPro_DC83_Clonal_ID8_Ct
#Designated_DriverType

df0 <- data.frame(test$SEX,test$AGE_SURGERY,test$AGE_EXPOSURE,test$DOSE,
                  test$CLIP2_VST_NT,test$CLIP2_VST_TP,
                  test$WGS_TP_N_del_SNV_clonal,
                  test$SigPro_DC83_Clonal_ID8_Ct,
                  test$Designated_DriverType)
str(df0)
headline <- c("SEX","AGE_SURGERY","AGE_EXPOSURE","DOSE","CLIP2_VST_NT","CLIP2_VST_TP",
              "WGS_TP_N_del_SNV_clonal","SigPro_DC83_Clonal_ID8_Ct","Designated_DriverType")
names(df0) <- headline
summary(df0)

hist(df0$CLIP2_VST_TP)
#save(df0, file = "PTC-selectedCOV-20210511.Rdata")

#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

pf <- df0
summary(pf)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
#myPalette <- c(cbbPalette[2],cbbPalette[6])
myPalette <- c(cbPalette[2],cbPalette[4],cbPalette[7],cbPalette[1])

library(ggplot2)

fp.1 <- ggplot() + 
  geom_bar(data = pf, aes(x=AGE_SURGERY, y=CLIP2_VST_TP), stat="identity", position="dodge", width = 0.8) +
  #geom_bar(data = surv, aes(x=agecat, y=npat,fill=shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(values = myPalette) +
  xlab("Age at Operation (yr)") +
  facet_grid(SEX ~ .) + 
  #scale_x_discrete(limits = levels(pfagrp$grp), breaks = levels(pfagrp$grp)) +
  #scale_y_continuous(name="No. of patients", limits=c(1,3200), breaks = c(1,10,100,1000), trans = 'log10') +
  #scale_y_continuous(name="Rel. frequency", labels = scales::percent, limits=c(0,1.2), breaks = seq(0,1,0.5)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=12)) 
#  + theme_bw()  # use a white background
print(fp.1)
