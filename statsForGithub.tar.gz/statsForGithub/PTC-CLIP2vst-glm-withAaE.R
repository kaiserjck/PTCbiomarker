#----------------------------------------------------------
# CLIP2_VST_TP mRNA expression
# jck, 2021/08/05
# AaE excluded to increase case numbers
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# libraries
library(caTools)
library(randomForest)
library(caret)
library(MLmetrics)
library(DescTools)
library(scoring)
library(pdp) # for partial dependence plots from many packages!
#library(vip)
library(pROC)
library(rstatix)
library(psych)

# plotting
library(ggplot2)
library(ggpubr)
library(ggprism)
library(patchwork)
library(magrittr)
library(reshape2)
library(stringr)
library(directlabels)
library(metR)
library(RColorBrewer)
library(forcats)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#--------------------------------------------
# read pre-edited data set
#--------------------------------------------
datdir <- "~/Nextcloud/imodel/CLIP2/stats/data"
setwd(datdir)
load(file = "PTC-edited-20210809.Rdata")
dim(df0) # 468 19
names(df0)
#[1] "REBC_ID"      "Sex"          "AaO"          "AaE"          "Dose"         "lPur"         "CLIP2_VST_NT" "CLIP2_VST_TP"
#[9] "csmDEL14"     "csmDEL5p"     "cdelSNVr"     "cID5"         "cID8"         "drv"          "AaO2"         "AaE2"        
#[17] "TsE"          "TsE2"         "Exposed"  

#---------------------------------------------------------------------------------
# CLIP2 expression in focus
#---------------------------------------------------------------------------------
df <- df0
dim(df)[1] # 468

df$TsE2 <- fct_relevel(df$TsE2, c("unexp", "<20", ">=20"))
table(df$TsE2)

# Fig 2B
df$csmDEL <- df$csmDEL14 + df$csmDEL5p

df <- df[complete.cases(df[c("CLIP2_VST_TP","Sex","AaO","Dose","AaE2")]),] # note: AaE not used
dim(df)[1] # 408

#-----------------------------------
# remove 14 outliers
#----------------------------------
hist(df$CLIP2_VST_TP)
shapiro.test(df$CLIP2_VST_TP)
# Density plot
ggdensity(df$CLIP2_VST_TP, fill = "lightgray")
# QQ plot
ggqqplot(df$CLIP2_VST_TP)

df <- subset(df, CLIP2_VST_TP > 6)

hist(df$CLIP2_VST_TP)
# shapiro-wilk test on normality
shapiro.test(df$CLIP2_VST_TP)
shapiro.test(log10(df$CLIP2_VST_TP))
# Density plot
ggdensity(df$CLIP2_VST_TP, fill = "lightgray")
# QQ plot
ggqqplot(df$CLIP2_VST_TP)
ggqqplot(log10(df$CLIP2_VST_TP))
dim(df)[1] # 394

table(df$Exposed, useNA = "ifany")
# no yes 
# 70 324

table(df$TsE, useNA = "always")
table(df$TsE2)
# <20  >=20 unexp 
#  95   229    70 

#TsE 17 wg. Selmansberger 2015
df$TsE17 <- NA
df$TsE17[df$Exposed == "no"] <- 1
df$TsE17[df$TsE < 17] <- 2
df$TsE17[df$TsE >= 17] <- 3
df$TsE17 <- factor(df$TsE17, levels = 1:3, labels = c("unexp","<17",">=17"))
table(df$TsE17, useNA = "ifany")
# unexp   <17  >=17 
#    70    52   272  
aggregate(df$AaO,list(df$TsE17),mean)
#   Group.1        x
# 1   unexp 20.68571
# 2     <17 24.01923
# 3    >=17 30.63971
aggregate(df$Dose,list(df$TsE17),mean)
#   Group.1        x
# 1   unexp   0.0000
# 2     <17 369.2885
# 3    >=17 243.2537

table(df$TsE, useNA = "always")
table(df$TsE2)
# <20  >=20 unexp 
#  95   229    70 

#AaE < 15 for testing
df$AaE15 <- NA
df$AaE15[df$Exposed == "no"] <- 1
df$AaE15[df$AaE < 15] <- 2
df$AaE15[df$AaE >= 15] <- 3
df$AaE15 <- factor(df$AaE15, levels = 1:3, labels = c("unexp","<15",">=15"))
table(df$AaE15, useNA = "ifany")
# unexp   <15  >=15 
#    70   294    30 
aggregate(df$AaO,list(df$AaE15),mean)
#   Group.1        x
# 1   unexp 20.68571
# 2     <15 29.00680
# 3    >=15 35.16667
aggregate(df$Dose,list(df$AaE15),mean)
#   Group.1        x
# 1   unexp   0.0000
# 2     <15 279.8571
# 3    >=15 103.0000

# Dose groups
df$D3 <- NA
df$D3[df$Dose == 0] <- 1
df$D3[df$Dose > 0] <- 2
df$D3[df$Dose >= 100] <- 3
df$D3 <- factor(df$D3, levels = 1:3, labels = c("unexp","<100",">=100"))
table(df$D3, useNA = "ifany")
# unexp  <100 >=100 
#    70   171   153  

# some tests
t.test(data = df, CLIP2_VST_TP ~ Sex) # p-value = 0.02379
t.test(data = df, CLIP2_VST_TP ~ Exposed) # p-value = = 0.1062
t.test(data = df[df$Dose < 50,], CLIP2_VST_TP ~ Exposed) # p-value = 0.03212
round(mean(df$AaO[df$Dose < 50]),1) # 27.4

aggregate(df$AaO,list(df$AaO2),length)
#   Group.1   x
# 1     <20  51
# 2    >=20 343
t.test(data = df[df$AaO2 == "<20",], CLIP2_VST_TP ~ Exposed) # p-value = 0.1035
t.test(data = df[df$TsE2 != ">=20",], CLIP2_VST_TP ~ Exposed) # p-value = 0.004615
t.test(data = df[df$AaE2 != ">=5",], CLIP2_VST_TP ~ Exposed) # p-value = 0.7237
t.test(data = df[df$AaE2 != "unexp",], CLIP2_VST_TP ~ AaE2) # p-value = 0.04371
t.test(data = df[df$AaE15 != ">=15",], CLIP2_VST_TP ~ Exposed) # p-value = 0.194
t.test(data = df[df$AaE15 != "unexp",], CLIP2_VST_TP ~ AaE15) # p-value = 0.02012

aggregate(df$AaO,list(df$TsE2),mean)
#   Group.1        x
# 1     <20 25.00000
# 2    >=20 31.47598
# 3   unexp 20.68571

aggregate(df$AaE[df$TsE2 != "unexp"],list(df$TsE2[df$TsE2 != "unexp"]),mean)
#   Group.1        x
# 1     <20 8.852632
# 2    >=20 6.598253
aggregate(df$AaE[df$TsE2 != "unexp"],list(df$TsE17[df$TsE2 != "unexp"]),sd)
#   Group.1        x
# 1     <20 5.686805
# 2    >=20 4.617396

aggregate(df$TsE[df$TsE2 != "unexp"],list(df$TsE2[df$TsE2 != "unexp"]),mean)

# pairwise t-tests
aggregate(df$CLIP2_VST_TP,list(df$TsE2),mean)
pairwise_t_test(CLIP2_VST_TP ~ TsE2, p.adjust.method = "bonferroni", data = df)
pairwise_t_test(CLIP2_VST_TP ~ TsE17, p.adjust.method = "bonferroni", data = df)

# AaE
aggregate(df$CLIP2_VST_TP,list(df$AaE15),mean)
#  Group.1         x
#1   unexp  9.949698
#2     <15 10.064400
#3    >=15 10.351900
aggregate(df$Dose,list(df$AaE15),mean)
#   Group.1        x
# 1   unexp   0.0000
# 2     <15 279.8571
# 3    >=15 103.0000
aggregate(df$AaE[df$AaE15 != "unexp"],list(df$AaE15[df$AaE15 != "unexp"]),mean)
#  Group.1         x
#1     <15  6.319728
#2    >=15 16.466667
aggregate(df$TsE[df$AaE15 != "unexp"],list(df$AaE15[df$AaE15 != "unexp"]),mean)
#   Group.1        x
# 1     <15 22.68707
# 2    >=15 18.70000
aggregate(df$AaO[df$AaE15 != "unexp"],list(df$AaE15[df$AaE15 != "unexp"]),mean)
#  Group.1        x
#1     <15 29.00680
#2    >=15 35.16667
pairwise_t_test(CLIP2_VST_TP ~ AaE2, p.adjust.method = "bonferroni", data = df)
#.y.          group1     group2    n1    n2      p p.signif p.adj p.adj.signif
#  1 CLIP2_VST_TP <5     >=5      118   206 0.0391 *        0.117 ns          
#  2 CLIP2_VST_TP <5     unexp    118    70 0.731  ns       1     ns          
#  3 CLIP2_VST_TP >=5    unexp    206    70 0.0361 *        0.108 ns 
pairwise_t_test(CLIP2_VST_TP ~ AaE15, p.adjust.method = "bonferroni", data = df)
#.y.              group1 group2    n1    n2       p p.signif  p.adj p.adj.signif
#  1 CLIP2_VST_TP unexp  <15       70   294 0.214   ns       0.642  ns          
#  2 CLIP2_VST_TP unexp  >=15      70    30 0.00812 **       0.0244 *           
#  3 CLIP2_VST_TP <15    >=15     294    30 0.031   *        0.0929 ns  

# exclusion reproduces Fig 2E
df.1 <- subset(df, cdelSNVr >= 0 & cdelSNVr < 1)
aggregate(df.1$cdelSNVr,list(df.1$TsE2),mean, na.rm = T)
pairwise_t_test(cdelSNVr ~ TsE2, p.adjust.method = "bonferroni", data = df.1[is.na(df$cdelSNVr) == F,])

aggregate(df$csmDEL,list(df$TsE2),median, na.rm = T)
pairwise_t_test(csmDEL ~ TsE2, p.adjust.method = "bonferroni", data = df[is.na(df$csmDEL) == F,])

aggregate(df$cID5[is.na(df$cID5) == F],list(df$TsE2[is.na(df$cID5) == F]),mean)
pairwise_t_test(cID5 ~ TsE2, p.adjust.method = "bonferroni", data = df[is.na(df$cID5) == F,])
aggregate(df$cID8[is.na(df$cID8) == F],list(df$TsE2[is.na(df$cID8) == F]),mean)
pairwise_t_test(cID8 ~ TsE2, p.adjust.method = "bonferroni", data = df[is.na(df$cID8) == F,])

aggregate(df$CLIP2_VST_TP,list(df$AaO2),mean)
pairwise_t_test(CLIP2_VST_TP ~ AaO2, p.adjust.method = "bonferroni", data = df)
t_test(df[df$AaO < 20,], CLIP2_VST_TP ~ Exposed)

#-----------------------------------------------------------------
# Violin plots
#-----------------------------------------------------------------
#------------------------------------------------------------------------
#https://cran.r-project.org/web/packages/ggprism/vignettes/pvalues.html
#-------------------------------------------------------------------------
# add p-values

# two groups

pf <- subset(df, AaE15 != ">=15")
#pf <- subset(df, TsE25 != ">=25")

df_p_val <- rstatix::t_test(pf, CLIP2_VST_TP ~ Exposed) %>% 
  rstatix::add_xy_position()

fp.1 <- ggplot() + 
  geom_violin(data = pf, aes(x=Exposed,y=CLIP2_VST_TP), size = 1, trim=T) + 
  geom_jitter(data = pf, aes(x=Exposed,y=CLIP2_VST_TP), position=position_jitter(0.2)) + 
  geom_boxplot(data = pf, aes(x=Exposed,y=CLIP2_VST_TP), width=0.1, size = 1, outlier.shape = NA) +
  geom_label(aes(x=1, y = 8, label = "n =  70")) +
  geom_label(aes(x=2, y = 8, label = "n = 294 (AaE < 15)")) +
  scale_y_continuous(name = "CLIP2 expression (CLIP2_VST_TP)",limits=c(8,12.5), breaks = seq(8,12,1)) +
  theme(text = element_text(size=15)) 

fp.1 <- fp.1 + add_pvalue(df_p_val, 
           label = "p = {signif(p, digits = 2)}",
           label.size = 5,
           remove.bracket = TRUE)
print(fp.1)

# three groups
df$AaE2 <- fct_relevel(df$TsE2,c("unexp","<5",">=5"))
df_p_val2 <- rstatix::t_test(df, CLIP2_VST_TP ~ TsE2,
                             p.adjust.method = "bonferroni") %>% 
  rstatix::add_xy_position()
fp.2 <- ggplot() + 
  geom_violin(data = df, aes(x=TsE2,y=CLIP2_VST_TP), size = 1, trim=T) + 
  geom_jitter(data = df, aes(x=TsE2,y=CLIP2_VST_TP), position=position_jitter(0.2)) + 
  geom_boxplot(data = df, aes(x=TsE2,y=CLIP2_VST_TP), width=0.1, size = 1, outlier.shape = NA) +
  scale_y_continuous(name = "CLIP2 expression (CLIP2_VST_TP)",limits=c(7.8,13), breaks = seq(8,13,1)) +
  scale_x_discrete(name = " ", labels = c("unexposed", "exposed (TsE < 20)", "exposed (TsE >= 20)")) +
  #geom_label(aes(x=1, y = 8, label = "n = 70")) +
  #geom_label(aes(x=2, y = 8, label = "n = 95")) +
  #geom_label(aes(x=3, y = 8, label = "n = 229")) +
  geom_label(aes(x=1, y = 8, label = "n = 70\nmAaO = 21 yrs"), size = 4.5) +
  geom_label(aes(x=2, y = 8, label = "n = 294\nmAaO = 29 yrs\n mDose = 0.28 Gy"), size = 4.5) +
  geom_label(aes(x=3, y = 8, label = "n = 30\nmAaO = 35 yrs\n mDose = 0.10 Gy"), size = 4.5) +
  theme(text = element_text(size=15)) 

#  p-values
  fp.2 <- fp.2 + add_pvalue(df_p_val2,
                            label = "p = {p.adj}",
                            label.size = 5,
                            tip.length = 0.01,
                            bracket.nudge.y = .2,
                            step.increase = 0.025)
print(fp.2)

# three groups with AaE15, Selmansberger 2015 has TsE17
df$AaE15 <- fct_relevel(df$AaE15,c("unexp","<15",">=15"))
df_p_val2 <- rstatix::t_test(df, CLIP2_VST_TP ~ AaE15,
                             p.adjust.method = "bonferroni") %>% 
  rstatix::add_xy_position()
fp.2.1 <- ggplot() + 
  geom_violin(data = df, aes(x=AaE15,y=CLIP2_VST_TP), size = 1, trim=T) + 
  geom_jitter(data = df, aes(x=AaE15,y=CLIP2_VST_TP), position=position_jitter(0.2)) + 
  geom_boxplot(data = df, aes(x=AaE15,y=CLIP2_VST_TP), width=0.1, size = 1, outlier.shape = NA) +
  scale_y_continuous(name = "CLIP2 expression (CLIP2_VST_TP)",limits=c(7.8,13), breaks = seq(8,13,1)) +
  scale_x_discrete(name = " ", labels = c("unexposed", "exposed (AaE < 15)", "exposed (AaE >= 15)")) +
  #geom_label(aes(x=1, y = 8, label = "n = 70")) +
  #geom_label(aes(x=2, y = 8, label = "n = 95")) +
  #geom_label(aes(x=3, y = 8, label = "n = 229")) +
  geom_label(aes(x=1, y = 8, label = "n = 70\nmAaO = 20 yrs"), size = 4.5) +
  geom_label(aes(x=2, y = 8, label = "n = 294\nmAaO = 29 yrs\n mDose = 0.28 Gy"), size = 4.5) +
  geom_label(aes(x=3, y = 8, label = "n =  30\nmAaO = 35 yrs\n mDose = 0.10 Gy"), size = 4.5) +
  theme(text = element_text(size=15)) 

#  p-values
fp.2.1 <- fp.2.1 + add_pvalue(df_p_val2,
                          label = "p = {p.adj}",
                          label.size = 5,
                          tip.length = 0.01,
                          bracket.nudge.y = .2,
                          step.increase = 0.03)
print(fp.2.1)

ggsave("Figure2-h20-AaE15.eps", device=cairo_ps, fallback_resolution = 600, width = 17.4, height = 20, units = "cm")

pf <- subset(df, AaO2 != ">=20")
table(pf$Exposed)

df_p_val <- rstatix::t_test(pf, CLIP2_VST_TP ~ Exposed) %>% 
  rstatix::add_xy_position()

fp.3 <- ggplot() + 
  geom_violin(data = pf, aes(x=Exposed,y=CLIP2_VST_TP), size = 1, trim=T) + 
  geom_jitter(data = pf, aes(x=Exposed,y=CLIP2_VST_TP), position=position_jitter(0.2)) + 
  geom_boxplot(data = pf, aes(x=Exposed,y=CLIP2_VST_TP), width=0.1, size = 1, outlier.shape = NA) +
  geom_label(aes(x=1, y = 8, label = "n = 30\n mAaO = 15.7 yr")) +
  geom_label(aes(x=2, y = 8, label = "n = 21\n mAaO = 17.1 yr\n mDose = 0.26 Gy")) +
  scale_y_continuous(name = "CLIP2 expression (CLIP2_VST_TP)",limits=c(8,12.5), breaks = seq(8,12,1)) +
  theme(text = element_text(size=15)) 

fp.3 <- fp.3 + add_pvalue(df_p_val, 
                          label = "p = {signif(p, digits = 3)}",
                          label.size = 5,
                          tip.length = 0.01,
                          bracket.nudge.y = .2,
                          step.increase = 0.025)
print(fp.3)


selline <- c("CLIP2_VST_TP","AaO","AaE","TsE","l10Dose")
cdf <- df[df$Exposed == "yes",]
#cdf <- subset(cdf, Dose < 100)
cdf$l10Dose <- log10(cdf$Dose)
pairs.panels(cdf[,selline],
             smooth = FALSE,
             ellipses = FALSE,
             gap=0,
             #bg =c("blue","red")[as.integer(cdf$Sex)], 
             bg =c(cbPalette[2],cbPalette[3])[as.integer(cdf$Sex)], 
             pch = 21)



#---------------------------------------------------------------------------
# more data screening
#---------------------------------------------------------------------------

aggregate(df$CLIP2_VST_TP,list(df$D3),mean)
pairwise_t_test(CLIP2_VST_TP ~ D3, p.adjust.method = "bonferroni", data = df)
aggregate(df$CLIP2_VST_TP[df$TsE2 != ">=20"],list(df$D3[df$TsE2 != ">=20"]),mean)
pairwise_t_test(CLIP2_VST_TP ~ D3, p.adjust.method = "bonferroni", data = subset(df, TsE2 != ">=20"))

aggregate(df$CLIP2_VST_TP,list(df$AaE2),mean)
pairwise_t_test(CLIP2_VST_TP ~ AaE2, p.adjust.method = "bonferroni", data = df)

aggregate(df$AaO,list(df$D3),mean)
aggregate(df$Dose,list(df$D3),mean)
pairwise_t_test(AaO ~ D3, p.adjust.method = "bonferroni", data = df)


aggregate(df$Dose,list(df$TsE2),mean)
aggregate(df$Dose,list(df$TsE2),length)
aggregate(df$Dose,list(df$Exposed),mean)
aggregate(df$AaO,list(df$AaO2),mean)
#   Group.1        x
# 1     <20 16.31373
# 2    >=20 29.73469
aggregate(df$Dose,list(df$AaO2),mean)
#   Group.1        x
# 1     <20 105.4118
# 2    >=20 233.2128
aggregate(df$Dose,list(df$AaO2,df$Exposed),mean)
#   Group.1 Group.2        x   n
# 1     <20      no   0.0000  30
# 2    >=20      no   0.0000  40
# 3     <20     yes      256  21
# 4    >=20     yes      264 303
aggregate(df$Dose,list(df$AaO2,df$Exposed),length)

tbl <- table(df$Exposed,df$AaO2)
tbl
#     <20 >=20
# no   30   40
# yes  21  303
chisq.test(tbl) # p-value = 1.014e-15
#------------------------------------------------
# GLMs
#------------------------------------------------
#mf <- df
mf <- subset(df, Exposed == "yes")
dim(mf)

# subtract median of unexposed for simplification
#mdCLIP2 <- median(df$CLIP2_VST_TP[mf$AaE2 == "unexp"])
mf$CLIP2_VST_TPs <- mf$CLIP2_VST_TP - median(mf$CLIP2_VST_TP)
#mf$CLIP2_VST_TPs <- log(mf$CLIP2_VST_TP)
mf$DoseGy <- mf$Dose/1000

mf$DoseGytr <- mf$DoseGy
mf$DoseGytr[mf$DoseGytr > 1] <- 1
#hist(mf$DoseGytr)
#range(mf$DoseGytr)

dim(mf)[1] # 324

# 
ptc.1 <- glm(CLIP2_VST_TPs ~ AaE + Sex, data = mf) 
summary(ptc.1)

ptc.1.0 <- glm(CLIP2_VST_TPs ~ DoseGy*AaE + Sex, data = mf) 
summary(ptc.1.0)

ptc.1.1 <- glm(CLIP2_VST_TPs ~ DoseGy:TsE17 + Sex, data = mf) 
summary(ptc.1.1)

# LRT
dDev <- deviance(ptc.1.0) - deviance(ptc.1.1)
dDev
pchisq(dDev, df = length(coef(ptc.1.1))-length(coef(ptc.1.0)), lower.tail = F) # 0.05086081

pl <- profile(ptc.1.1)
plot(pl)
coef(pl)
upar <- coef(pl)
lp.CI <- confint(pl)
round(lp.CI,5)

# DoseGy, as in Morton 2021
ptc.2 <- glm(CLIP2_VST_TPs ~ DoseGy+AaO+Sex, data = mf) 
summary(ptc.2)

# truncated Dose Fig 5C: passt in etwa
ptc.2.tr <- glm(CLIP2_VST_TPs ~ DoseGytr+AaO+Sex, data = mf) 
summary(ptc.2.tr)

pl <- profile(ptc.2.tr)
plot(pl)
coef(pl)
upar <- coef(pl)
lp.CI <- confint(pl)
round(lp.CI,5)

# DoseGy*AaO, as in Morton 2021
ptc.2.i <- glm(CLIP2_VST_TPs ~ DoseGy*AaO+Sex, data = mf) 
summary(ptc.2.i)
delDF <- length(coef(ptc.2.i))-length(coef(ptc.2)) # 1
deldev <- deviance(ptc.2)-deviance(ptc.2.i) # 
pval <- pchisq(deldev, delDF,lower.tail = F)
cat(sprintf("LRT: deldev: %4.2f, delDF: %2d, pval: %6.2g\n", deldev, delDF, pval))
# LRT: deldev: 0.02, delDF:  1, pval:   0.88      1

# DoseGy, AaO < 20
dim(mf[mf$AaO < 20,])[1] # 51
ptc.3 <- glm(CLIP2_VST_TPs ~ DoseGy+AaO+Sex, data = mf[mf$AaO < 20,]) 
summary(ptc.3)

# DoseGy, AaO >= 20
dim(mf[mf$AaO >= 20,])[1] # 343
ptc.3.hi <- glm(CLIP2_VST_TPs ~ DoseGy+AaO+Sex, data = mf[mf$AaO >= 20,]) 
summary(ptc.3.hi)

# with interaction
ptc.3.int <- glm(CLIP2_VST_TPs ~ DoseGy*AaO+Sex, data = mf) 
summary(ptc.3.int)

# Exposed
ptc.4 <- glm(CLIP2_VST_TPs ~ Exposed+AaO+Sex, data = mf) 
summary(ptc.4)

# Exposed, AaO < 20 : Voila!
ptc.5 <- glm(CLIP2_VST_TPs ~ Exposed+AaO+Sex, data = mf[mf$AaO < 20,]) 
summary(ptc.5)
# Exposedyes   0.44302    0.21645   2.047   0.0463 *

ptc.5.0 <- glm(CLIP2_VST_TPs ~ AaO+Sex, data = mf[mf$AaO < 20,]) 
summary(ptc.5.0)

# LRT
dDev <- deviance(ptc.5.0) - deviance(ptc.5)
dDev
pchisq(dDev, df = 1, lower.tail = F) # 0.140241

pl <- profile(ptc.5)
plot(pl)
coef(pl)
upar <- coef(pl)
lp.CI <- confint(pl)
round(lp.CI,5)

aggregate(mf$CLIP2_VST_TPs[mf$AaO < 20],list(mf$Exposed[mf$AaO < 20]),mean)
aggregate(mf$CLIP2_VST_TPs[mf$AaO >= 20],list(mf$Exposed[mf$AaO >= 20]),mean)
t_test(CLIP2_VST_TPs ~ Exposed, data = mf[mf$AaO < 20,])
t_test(CLIP2_VST_TPs ~ Exposed, data = mf[mf$AaO >= 20,])

# Exposed, AaO >= 20
ptc.5.hi <- glm(CLIP2_VST_TPs ~ Exposed+AaO+Sex, data = mf[mf$AaO >= 20,]) 
summary(ptc.5.hi)

# pure interaction
ptc.6 <- glm(CLIP2_VST_TPs ~ DoseGy*AaO, data = mf) 
summary(ptc.6)

ptc.6.0 <- glm(CLIP2_VST_TPs ~ AaO, data = mf) 
summary(ptc.6.0)

# LRT
dDF <- length(coef(ptc.6)) - length(coef(ptc.6.0))
dDev <- deviance(ptc.6.0) - deviance(ptc.6)
dDev
pchisq(dDev, df = dDF, lower.tail = F) # 

doseLim <- 0.05
dim(mf[mf$DoseGy < doseLim,])[1] # 165
ptc.7 <- glm(CLIP2_VST_TPs ~ DoseGy, data = mf[mf$DoseGy < doseLim,]) 
summary(ptc.7)
pr <- profile(ptc.7)
lp.CI <- confint(pr)
signif(lp.CI,3)


