#----------------------------------------------------------
# Simulation of surrogate marker from CLIP2_VST_TP
# jck, 2021/05/11
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# libraries
library(caTools)
library(randomForest)
library(caret)
library(MLmetrics)
library(DescTools)
library(scoring)
library(pdp) # for partial dependence plots from many packages!
library(vip)
library(pROC)
library(rstatix)
library(psych)

# plotting
library(ggplot2)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

datdir <- "~/imodel/CLIP2/stats/data"
setwd(datdir)
load(file = "PTC-edited-20210511.Rdata")
dim(df0)
names(df0)
#[1] "Sex"          "AaO"          "AaE"          "Dose"         "CLIP2_VST_NT" "CLIP2_VST_TP" "cdelSNVr"     "cID8"         "drv"         
#[10] "C2rat"        "C2sur"        "AaEcat"       "AaE2"         "AaOcat"       "AaO2"         "TsE"          "TsE2"         "Dcat"        
#[19] "D3" 

#df <- subset(df0, Dose < 2000)


#---------------------------------------------------------------------------------
# simulate surrogate marker C2sur
#---------------------------------------------------------------------------------
df <- df0
dim(df)
set.seed(1503)
df <- df[complete.cases(df[c("CLIP2_VST_TP","Sex","AaO","AaE","TsE","Dose")]),]
#df <- df[complete.cases(df[c("CLIP2_VST_TP","Dose")]),]
dim(df[df$AaO2 == "<20",])[1]

dim(df) # 369   19
hist(df$CLIP2_VST_TP)
hist(df$CLIP2_VST_TP[df$AaO2 == "<20"])
df <- subset(df, CLIP2_VST_TP > 6) # remove outliers
dim(df)# 356 19
hist(df$CLIP2_VST_TP)
hist(df$CLIP2_VST_TP[df$AaO2 == "<20"])
df$Exposed <- 1
df$Exposed[df$Dose > 0] <- 2
df$Exposed <- factor(df$Exposed, levels = 1:2, labels = c("no","yes"))
table(df$Exposed,df$AaE2)
# no yes 
# 66 290 

hist(log10(df$Dose+1))

df$D5 <- 1
df$D5[df$Dose > 0] <- 2
df$D5[df$Dose > 50] <- 3
df$D5[df$Dose > 100] <- 4
df$D5[df$Dose > 200] <- 5

df$D5 <- factor(df$D5, levels = 1:5, labels = c("unexp","<50","50-100","100-200",">200"))
table(df$D5)

t.test(data = df, CLIP2_VST_TP ~ Sex)
t.test(data = df, CLIP2_VST_TP ~ Exposed)
dim(df[df$AaO2 == "<20",])[1] # 32
t.test(data = df[df$AaO2 == "<20",], CLIP2_VST_TP ~ Exposed)
t.test(data = df[df$TsE2 != ">=20",], CLIP2_VST_TP ~ Exposed)

pwc <- pairwise_t_test(CLIP2_VST_TP ~ TsE2, p.adjust.method = "bonferroni", data = df)
pwc
pwc <- pairwise_t_test(CLIP2_VST_TP ~ D5, p.adjust.method = "bonferroni", data = df)
pwc


#---------------------------------------------------------------------------
# GLM regression
#---------------------------------------------------------------------------
mf <- df

dim(mf)[1] # 356

aggregate(df$TsE,list(df$TsE2),mean)
aggregate(df$Dose,list(df$TsE2),mean)
aggregate(df$Dose,list(df$TsE2),length)
aggregate(df$Dose,list(df$D5),mean)
aggregate(df$Dose,list(df$D5),length)
aggregate(df$Dose,list(df$Exposed),mean)

# TsE2
ptc.1 <- glm(CLIP2_VST_TP ~ TsE2, data = mf) 
summary(ptc.1)

ptc.2 <- glm(CLIP2_VST_TP ~ AaE2, data = mf) 
summary(ptc.2)

ptc.3 <- glm(CLIP2_VST_TP ~ Exposed, data = mf[mf$TsE2 != ">=20",]) 
summary(ptc.3)

ptc.4 <- glm(CLIP2_VST_TP ~  D5 + Sex, data = mf[mf$TsE2 != ">=20",]) 
summary(ptc.4)

ptc.5 <- glm(CLIP2_VST_TP ~  Dose + Sex + TsE2, data = mf) 
summary(ptc.5)

ptc.6 <- glm(CLIP2_VST_TP ~  Dose + Sex, data = mf[mf$TsE2 != ">=20" & mf$Dose < 100,]) 
summary(ptc.6)

ptc.7 <- glm(CLIP2_VST_TP ~  Dose, data = mf[mf$Dose < 50,]) 
summary(ptc.7)

ptc.8 <- glm(CLIP2_VST_TP ~  Dose, data = mf[mf$AaO < 20 & mf$Dose < 100,]) 
summary(ptc.8)

ptc.9 <- glm(CLIP2_VST_TP ~  I(Dose*Dose), data = mf) 
summary(ptc.9)
Dose = seq(0,1000,10)
predict(ptc.9, newdata = data.frame(Dose))
#-------------------------------------------------------------------------
# box plots
#-------------------------------------------------------------------------

bp <- ggplot() +
  geom_boxplot(data = mf[mf$TsE2 != ">=20",], aes(x=Exposed,y=CLIP2_VST_TP)) +
  geom_jitter(data = mf[mf$TsE2 != ">=20",], aes(x=Exposed,y=CLIP2_VST_TP)) + 
  geom_label(aes(x=1.5, y = 8, label = "p = 0.009")) +
  geom_label(aes(x=1, y = 8, label = "n = 66")) +
  geom_label(aes(x=2, y = 8, label = "n = 107 (TsE < 20 yr)"))
bp <- bp + scale_x_discrete(name = "Exposed") + 
  scale_y_continuous(name = "CLIP2_VST_TP",limits=c(8,12.5), breaks = seq(8,12,1)) +
  theme_gray() + 
  theme(text = element_text(size=15))

print(bp)

selline <- c("CLIP2_VST_TP","AaO","AaE","TsE","Dose")
cdf <- df[df$Exposed == "yes",]
cdf <- subset(cdf, Dose < 100)
cdf$Dose <- log10(cdf$Dose+1)
pairs.panels(cdf[,selline],
             smooth = FALSE,
             ellipses = FALSE,
             gap=0,
             bg =c("blue","red")[as.integer(cdf$Sex)], 
             #             bg =c("#E69F00", "#56B4E9")[as.integer(df$ucsex)],
             pch = 21)











