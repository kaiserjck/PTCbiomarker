#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# Plot ERR and others
# jck, 2021/07/03
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
#library(psych) # pairs.panels

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/gsf/imodel/CLIP2"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#------------------------------------------------------------
# read parameters and covariance matrix
#------------------------------------------------------------
setwd(curvdir)

load(file = "DriverType-ERRdesc-all-no-ps.Rdata")
dtf <- desc

load(file = "CLIP2-ERRdesc-all-no-ps.Rdata")
c2f <- desc

load(file = "PTC-desc-kaiser2016.Rdata")
ref <- desc
names(ref)[1] <- c("ERR")
ref$ERR <- "Kaiser 2016"
ref

#names(dtf)

dtf.err <- subset(dtf, Estimator == "ERR")
c2f.err <- subset(c2f, Estimator == "ERR")
ref.err <- subset(ref, Estimator == "ERR")

pf <- rbind(dtf.err,c2f.err)
pf <- droplevels(pf)
summary(pf)

myPalette <- c(cbPalette[2],cbPalette[3],cbPalette[4])

fp.1 <- ggplot() + 
  geom_line(data = pf, aes(x=AaO, y=estmn, color = Marker)) + 
  geom_ribbon(data = ref.err, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  scale_color_manual(values = myPalette, labels = c("CLIP2", "Driver type", "RadEpi")) +
  scale_x_continuous(name = "Age at Operation (yr)", limits = c(15,45), breaks = seq(15,45,10)) +
  scale_y_log10(name = "Excess Relative Risk at 1 Gy") +
  coord_cartesian(ylim = c(-0.01, 15.01)) + 
  #guides(color=FALSE) +
  theme(text = element_text(size=15)) 
print(fp.1)

#-------------------------------------------------------------
# plotting with risk
#-------------------------------------------------------------

# Tronko 2006
errm <- 5.25
errlo <- 1.7
errhi <- 27.5
p.T <- data.frame("mean(AaO) 16",16.5,errm,errlo,errhi)
names(p.T) <- c("CVCat","AaO","ERR","lo","hi")

# Tronko 2006
errm <- 7.26
errlo <- 2.27
errhi <- 17.52
p.C2 <- data.frame("mean(AaO) 16",15.5,errm,errlo,errhi)
names(p.C2) <- c("CVCat","AaO","ERR","lo","hi")

# Brenner 2001
errm <- 1.91
errlo <- 0.43
errhi <- 6.34
p.B <- data.frame("mean(AaO) 27",27,errm,errlo,errhi)
names(p.B) <- c("CVCat","AaO","ERR","lo","hi")

# Tronko 2017
errlo <- 0.39 # lo
errm <- 1.36 # mle
errhi <- 4.15 # hi
p.T17 <- data.frame("mean(AaO) 27",38,errm,errlo,errhi)
names(p.T17) <- c("CVCat","AaO","ERR","lo","hi")

# Morton 2021
errlo <- 3.7 # lo
errm <- 9.3 # mle
errhi <- 21.1 # hi
p.M21 <- data.frame("mean(AaO) 28",28,errm,errlo,errhi)
names(p.M21) <- c("CVCat","AaO","ERR","lo","hi")

p.ERR <- rbind(p.T,p.C2,p.B,p.T17,p.M21)
p.ERR

xline <- c(19.7,13.5,30.5,41.3,31)
yline <- c(5.2,7.2,2,1.3,9.3)
tline <- c("Tronko 2006","CLIP2","Brenner 2011","Tronko 2017","Driver type")
cvcat <- c("mean(AaO) 16","mean(AaO) 16","mean(AaO) 27", "mean(AaO) 38","mean(AaO) 28")
study_text <- data.frame(cvcat,tline,xline,yline)
names(study_text) <- c("CVCat","Study","AaO","ERR")
study_text

#geom_point(data = ukram, aes(x=age, y=mle, group= Study, color = Study), size=5) +
#geom_errorbar(data = ukram, aes(x=age, ymin=lo, ymax=hi, group = Study, color = Study), width = 1, size = 1) +

pf <- rbind(c2f.err[c2f.err$AaO <= 35,],dtf.err)
pf <- droplevels(pf)
summary(pf)
ref.err <- droplevels(ref.err)
ref.err <- ref.err[ref.err$AaO <= 35,]

fp.2 <- ggplot() + 
  geom_line(data = pf, aes(x=AaO, y=estmn, color = Marker, group = Marker, linetype = Marker), size = 1) + 
  geom_line(data = ref.err, aes(x=AaO, y=estmn, color = ERR, group = ERR), size = 1) + 
  geom_ribbon(data = ref.err, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  #geom_ribbon(data = dtf.err, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  scale_color_manual(values = myPalette, labels = c("Marker: CLIP2", "Marker: Driver type", "ERR: Kaiser 2016")) +
  scale_linetype_manual(values = c("dashed","solid","solid")) +
  scale_x_continuous(name = "Age at Operation (yr)", limits = c(10,45), breaks = seq(10,45,5)) +
  scale_y_log10(name = "Excess Relative Risk at 1 Gy") +
  coord_cartesian(ylim = c(0.1, 25.1)) +
  geom_point(data = p.ERR, aes(x=AaO, y=ERR), size=4) +
  geom_errorbar(data = p.ERR, aes(x=AaO, ymin=lo, ymax=hi), width = .1, size = 1) +
  geom_label(data = study_text, aes(x = AaO, y = ERR, label = Study, group = CVCat)) +
  #guides(color=FALSE) +
  guides(linetype=FALSE) +
  theme(text = element_text(size=15), legend.position = c(0.85,0.8), legend.title = element_blank()) 
print(fp.2)

