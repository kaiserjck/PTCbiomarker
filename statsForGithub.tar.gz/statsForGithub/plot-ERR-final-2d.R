#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# Plot ERR and others
# jck, 2021/07/03
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
library(forcats)
#library(psych) # pairs.panels

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/CLIP2"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#------------------------------------------------------------
# read parameters and covariance matrix
#------------------------------------------------------------
setwd(curvdir)

load(file = "DriverType-morton-err-c0-ps-pa-2d.Rdata")
mf <- desc
mf$src <- "morton"

mf.err <- subset(mf, Estimator == "ERR")
dim(mf.err)

mf.epi <- subset(mf, Estimator == "ERRepi")
dim(mf.epi)

load("DriverType-logreg-lDose-acen-msex-2d.Rdata")
lf <- desc
lf$src <- "logreg"

lf.err <- subset(lf, Estimator == "ERR")
dim(lf.err)

load("DriverType-logreg-lDose-acen-msex-intact-2d.Rdata")
lif <- desc
lif$src <- "logint"

lif.err <- subset(lif, Estimator == "ERR")
dim(lif.err)

#load(file = "DriverType-EARdesc-err-pa-c0-c1-linAa0-2d.Rdata")
#af <- desc

#af.err <- subset(af, Estimator == "ERR")
#dim(af.err)

#af.epi <- subset(af, Estimator == "ERRepi")
#dim(af.epi)

#-------------------------------------------------------------
# plotting with risk
#-------------------------------------------------------------

# Tronko 2006
errm <- 5.25/5
errlo <- 1.7/5
errhi <- 27.5/5
p.T <- data.frame("mean(AaO) 16",16.5,errm,errlo,errhi)
names(p.T) <- c("CVCat","AaO","ERR","lo","hi")

# CLIP2 recalc
#errm <- 7.26
#errlo <- 2.27
#errhi <- 17.52
errm <- 5.2/5
errlo <- 2.1/5
errhi <- 13/5
p.C2 <- data.frame("mean(AaO) 16",15.5,errm,errlo,errhi)
names(p.C2) <- c("CVCat","AaO","ERR","lo","hi")

# Brenner 2001
errm <- 1.91/5
errlo <- 0.43/5
errhi <- 6.34/5
p.B <- data.frame("mean(AaO) 27",27,errm,errlo,errhi)
names(p.B) <- c("CVCat","AaO","ERR","lo","hi")

# Tronko 2017
errlo <- 0.39/5 # lo
errm <- 1.36/5 # mle
errhi <- 4.15/5 # hi
p.T17 <- data.frame("mean(AaO) 27",38,errm,errlo,errhi)
names(p.T17) <- c("CVCat","AaO","ERR","lo","hi")

p.ERR <- rbind(p.T,p.B,p.T17)
p.ERR

# Morton 2021
#errlo <- 2.89 # lo
#errm <- 7.92 # mle
#errhi <- 18.8 # hi
#errlo <- 3.7 # lo
#errm <- 9.3 # mle
#errhi <- 21.1 # hi
#p.M21 <- data.frame("mean(AaO) 28",28,errm,errlo,errhi)
#names(p.M21) <- c("CVCat","AaO","ERR","lo","hi")

p.marker <- rbind(p.C2)
p.marker

xline <- c(20,30.5,41.3)
yline <- c(5.2/5,1.91/5,1.36/5)
tline <- c("Tronko 2006","Brenner 2011","Tronko 2017")
cvcat <- c("mean(AaO) 16","mean(AaO) 27", "mean(AaO) 38")
study_text <- data.frame(cvcat,tline,xline,yline)
names(study_text) <- c("CVCat","Study","AaO","ERR")
study_text

xline <- c(11.6)
yline <- c(5.2/5)
#tline <- c("CLIP2\n(Kaiser 2016\nrecalc.)","Driver type\n(Morton 2021, Fig. 3B)")
tline <- c("CLIP2\n(Kaiser 2016)")
cvcat <- c("mean(AaO) 16")
marker_text <- data.frame(cvcat,tline,xline,yline)
names(marker_text) <- c("CVCat","Study","AaO","ERR")
marker_text


#-------------------------------------------------------------
# plotting with risk
#-------------------------------------------------------------
pf <- rbind(mf.epi,lf.err,lif.err)
pf$src <- fct_relevel(pf$src,"logreg","logint","morton")
#pf.AaO <- subset(pf, AaO == 15 |  AaO == 20 | AaO == 25 | AaO == 30 | AaO == 35 | AaO == 40)
pf.AaO <- subset(pf, AaO == 15 |  AaO == 30)
epf.AaO <- subset(lf.err, AaO == 15 |  AaO == 30)
#pf.AaO <- subset(pf, AaO == 15)
head(pf.AaO)

#myPalette <- c(cbPalette[2],cbPalette[3],cbPalette[4])
myPalette <- cbPalette

fp.1 <- ggplot() + 
  geom_line(data = pf.AaO, aes(x=Dose, y=estmn, color=factor(AaO), linetype = src), size = 1) + 
  #geom_errorbar(data = lf.err, aes(x=Dose, y=estmn, ymin = estlo, ymax = esthi), size = 0.2) +
  #geom_line(data = ref.err, aes(x=AaO, y=estmn, color = ERR, group = ERR), size = 1) + 
  geom_ribbon(data = epf.AaO, aes(x=Dose, y=estmn, ymin = estlo, ymax = esthi, group = factor(AaO)), alpha = 0.2) +
  scale_color_manual(values = cbbPalette[2:8], name = "AaO (yr)") +
  scale_linetype_manual(name = "ERR from", labels = c("LR with 95% CI", "LR (Dose*AaO)", "Morton 2021"), values = c("solid","dashed","dotted")) +
  scale_x_continuous(name = "Thyroid dose (Gy)", limits = c(0,1), breaks = seq(0,1,0.2)) +
  scale_y_continuous(name = "Excess Relative Risk at 1 Gy", limits = c(0,100), breaks = seq(0,20,5)) +
  coord_cartesian(ylim = c(0,10)) +
  theme(text = element_text(size=15), legend.position = c(0.5,0.85)) 
print(fp.1)

pf.Dose <- subset(pf, (Dose > 0.19 & Dose < 0.21) |  Dose == 1)
epf.Dose <- subset(lf.err, (Dose > 0.19 & Dose < 0.21) |  Dose == 1)
head(pf.Dose)

#myPalette <- c(cbPalette[2],cbPalette[3],cbPalette[4])
myPalette <- cbPalette

fp.2 <- ggplot() + 
  #ggtitle("DriverType-EARdesc-err-pa-c0-c1-linAa0") +
  geom_line(data = pf.Dose, aes(x=AaO, y=estmn, color=factor(Dose), linetype = src), size = 1) + 
  geom_ribbon(data = epf.Dose, aes(x=AaO, y=estmn, ymin = estlo, ymax = esthi, group = factor(Dose)), alpha = 0.2) +
  #geom_line(data = ref.err, aes(x=AaO, y=estmn, color = ERR, group = ERR), size = 1) + 
  #geom_ribbon(data = ref.err, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  #geom_ribbon(data = dtf.err, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  scale_color_manual(values = cbbPalette[2:8], name = "Dose (Gy)") +
  scale_linetype_manual(name = "ERR from", labels = c("LR with 95% CI", "LR (Dose*AaO)", "Morton 2021"), values = c("solid","dashed","dotted")) +
  scale_x_continuous(name = "Age at operation (yr)", limits = c(10,45), breaks = seq(10,45,5)) +
  scale_y_continuous(name = "Excess Relative Risk at 1 Gy", limits = c(0,100), breaks = seq(0,20,5)) +
  coord_cartesian(ylim = c(0,15)) +
  theme(text = element_text(size=15), legend.position = c(0.75,0.85)) 
print(fp.2)

myPalette <- c(cbPalette[2],cbPalette[3],cbPalette[4])
pf <- subset(pf, (Dose > 0.19 & Dose < 0.21))
epf <- subset(mf.epi, (Dose > 0.19 & Dose < 0.21))
head(pf)

fp.3 <- ggplot() + 
  geom_line(data = pf, aes(x=AaO, y=estmn, color = src), size = 1) + 
  geom_ribbon(data = epf, aes(x=AaO, ymin = estlo, ymax = esthi, group = Marker), alpha = 0.2) +
  #scale_color_manual(values = myPalette) +
  scale_color_manual(values = myPalette, 
                     labels = c("LR (AaO+Dose)", "LR (AaO*Dose)","Morton 2021 with 95% CI"), name = "age-dep. ERR") +
  #scale_linetype_manual(values = c("dashed","solid","solid")) +
  scale_x_continuous(name = "Age at Operation (yrs)", limits = c(10,45), breaks = seq(10,45,5)) +
  scale_y_continuous(name = "Excess Relative Risk at 0.2 Gy", limits = c(0,20), breaks = seq(0,20,1)) +
  coord_cartesian(ylim = c(0,3)) +
  geom_point(data = p.ERR, aes(x=AaO, y=ERR), size=4) +
  #geom_errorbar(data = p.ERR, aes(x=AaO, ymin=lo, ymax=hi), width = .1, size = 1) +
  geom_linerange(data = p.ERR, aes(x=AaO, ymin=lo, ymax=hi), size = 1) +
  geom_point(data = p.marker, aes(x=AaO, y=ERR), color = cbPalette[8], size=4) +
  #geom_errorbar(data = p.marker, aes(x=AaO, ymin=lo, ymax=hi), color = cbPalette[8], width = .1, size = 1) +
  geom_linerange(data = p.marker, aes(x=AaO, ymin=lo, ymax=hi), color = cbPalette[8], size = 1) +
  geom_label(data = study_text, aes(x = AaO, y = ERR, label = Study, group = CVCat)) +
  geom_label(data = marker_text, aes(x = AaO, y = ERR, label = Study, group = CVCat)) +
  #guides(color=FALSE) +
  guides(linetype="none") +
  theme(text = element_text(size=15), legend.position = c(0.75,0.85)) 
print(fp.3)


