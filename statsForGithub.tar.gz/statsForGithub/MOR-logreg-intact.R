#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# logistic regression of driver type data
# jck, 2022/04/29
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
#library(psych) # pairs.panels

library(caTools)
library(reshape2)

library(DescTools)
library(caret)
library(pROC)

library(gnm) # generalized non-linear models
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/Nextcloud/imodel/CLIP2"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#----------------------------------------------------------
# select marker data 
#----------------------------------------------------------
marker <- character()
#marker <- "CLIP2"
marker <- "DriverType"

setwd(datdir)
{
  if (marker == "CLIP2") {
    load(file = "CLIP2_20210621.Rdata")
    df0 <- thyroid
    # marker
    df0$marker <- 0
    df0$marker[df0$Clip2 == "pos"] <- 1
#    df0$DoseGy[df0$Exposed == "no"] <- 0 # DoseGy is already AaO-adjusted
    } 
  else if (marker == "DriverType") {
    load(file = "PTC-edited-20210805.Rdata")
    df0 <- df0[complete.cases(df0[,c("drv","Dose","AaO","Sex"),]),] # AaE, TsE not considered
    # like Selmansberger et al. 2015
    df0$DoseGy <- df0$Dose/1000
    df0$DoseGy[df0$Dose == 0] <-  df0$AaO[df0$Dose == 0]/1000
    # marker
    df0$marker <- 0
    df0$marker[df0$drv == "fus"] <- 1
    df0$Exposed <- factor(ifelse(df0$Dose > 0, "yes", "no"))} # df0 loaded
}

mmname <- character()
mmname <- "logreg"

fname <- marker
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-","lDose-acen-msex",sep="")
fname
fbasename <- fname

#---------------------------------------------
# PTC marker data
#---------------------------------------------
#df0$DoseGy[df0$DoseGy > 1] <- 1
#df0$DoseGy[df0$DoseGy == 0] <- df0$AaO/1000
range(df0$DoseGy)
#df0 <- subset(df0, DoseGy < 0.2)
#df0 <- subset(df0, AaO2 == "<20")
#df0 <- subset(df0, TsE2 != ">=20")
cene <- 10
cena <- as.integer(mean(df0$AaO)+.5)
df0$ecen <- (df0$AaE-cene)/10
#df0$acen <- log(df0$AaO/cena)
df0$acen <- (df0$AaO-cena)/10
df0$msex <- 1
df0$msex[df0$Sex == "m"] <- -1
table(df0$Sex,df0$msex)
table(df0$marker,df0$drv)
#   mut fus
# 0 253   0
# 1   0 176
table(df0$marker,df0$Exposed)

df0$lDose <- log(df0$DoseGy)

# handle
df <- df0
dim(df)
str(df)
summary(df)

# Age means
aggregate(df$AaO,list(df$AaO2),mean)
aggregate(df$AaO,list(df$AaE2),mean)
aggregate(df$AaO,list(df$TsE2),mean)

#-----------------------------------------------------
# logistic regression
#-----------------------------------------------------

dim(df)[1] # 429

lor.0 <- glm(marker ~ acen + msex, data = df, family = "binomial")
summary(lor.0)

lor.1 <- glm(marker ~ lDose + acen + msex, data = df, family = "binomial")
summary(lor.1)

# likelihood ratio test
dDF <- length(coef(lor.1)) - length(coef(lor.0))
dDF
dDev <- deviance(lor.0) - deviance(lor.1)
dDev # 27.70411
signif(pchisq(dDev, df = dDF, lower.tail = F),3) # 1.41e-07

lor.2 <- glm(marker ~ lDose*acen + msex, data = df, family = "binomial")
summary(lor.2)
dDF <- length(coef(lor.2)) - length(coef(lor.1))
dDF
dDev <- deviance(lor.1) - deviance(lor.2)
signif(dDev, 3) # 5.46
signif(pchisq(dDev, df = dDF, lower.tail = F),3) # 0.0195

prob = predict(lor.2,type=c("response"))
g <- roc(marker ~ prob, data=df)
auc(g) # Area under the curve: 0.701
ci.auc(g) # 95% CI:  0.6505-0.7514 (DeLong)
signif(BrierScore(df$marker, prob), 3) # 0.208

pLevel <- length(df$marker[df$marker == 1])/length(df$marker)
pLevel
pred <- factor(ifelse(prob > pLevel, "yes", "no"))
refe <- factor(ifelse(df$marker == 1, "yes", "no"))
confusionMatrix(reference = refe, data = pred, positive = "yes")

lor.3.0 <- glm(marker ~ lDose+acen, data = df, family = "binomial")
lor.3 <- glm(marker ~ lDose*acen, data = df, family = "binomial")
summary(lor.3)
dDF <- length(coef(lor.3)) - length(coef(lor.3.0))
dDF
dDev <- deviance(lor.3.0) - deviance(lor.3)
dDev # 5.699327
signif(pchisq(dDev, df = dDF, lower.tail = F),3) # 0.017

#------------------------------------------
# assign working model
#------------------------------------------
#mle.1 <- lor.1
#mle.1 <- lor.2
mle.1 <- lor.3

#--------------------------------------------------------------------------
# prepare plot data
#--------------------------------------------------------------------------
critval <- 1.96 ## approx 95% CI

#doseMax <- max(exp(df$lDose))
#doseMin <- min(exp(df$lDose))
AaOmin <- 10
AaOmax <- 45
acenMin <- (AaOmin-cena)/10 # 10 yr
acenMax <- (AaOmax-cena)/10  # 35 yr
doseMin <- 0.01
doseMax <- 2

# Create a sequence of incrementally increasing (by selected units) values for both AaO and DoseGy
xgrid <-  seq(acenMin, acenMax, 0.05)
length(xgrid)
ygrid <-  seq(doseMin, doseMax, 0.01)
length(ygrid)
# Generate a matrix with every possible combination of AaO and DoseGy
data.new <-  expand.grid(acen = xgrid, lDose = log(ygrid), msex = 0)
dim(data.new)

# melt in long form
df.melt <- melt(data.new, id.vars = c("acen","lDose","msex"))
is.data.frame(df.melt)
head(df.melt)
dim(df.melt)

# ERR
preds <- predict(mle.1, type = "link", newdata = data.new, se.fit = TRUE)
erf <- data.frame("DriverType","ERR",df.melt$acen*10+cena,"both",exp(df.melt$lDose),
                 exp(preds$fit),exp(preds$fit-critval*preds$se.fit),exp(preds$fit+critval*preds$se.fit))
headline <- c("Marker","Estimator","AaO","Sex","Dose","estmn","estlo","esthi")
names(erf) <- headline
dim(erf)

# POC
preds <- predict(mle.1, type = "response", newdata = data.new, se.fit = TRUE)
pcf <- data.frame("DriverType","POC",df.melt$acen*10+cena,"both",exp(df.melt$lDose),
                  preds$fit,preds$fit-critval*preds$se.fit,preds$fit+critval*preds$se.fit)
headline <- c("Marker","Estimator","AaO","Sex","Dose","estmn","estlo","esthi")
names(pcf) <- headline
dim(pcf)

desc <- rbind(erf,pcf)
summary(desc)

#pf.AaO <- subset(desc, AaO == 15 |  AaO == 20 | AaO == 25 | AaO == 30 | AaO == 35)
#pf.Dose <- subset(desc, Dose == 1)

setwd(curvdir)
fbasename <- paste(fbasename,"intact",sep="-")
fsavname <- paste(fbasename,".Rdata",sep="")
fsavname
save(desc, file = fsavname)

