#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# Calculation of ERR with binomial likelihood
# jck, 2021/06/27
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
#library(psych) # pairs.panels

library(caTools)
library(caret)
library(pROC)

library(gnm) # generalized non-linear models
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/gsf/imodel/CLIP2"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#----------------------------------------------------------
# select marker data 
#----------------------------------------------------------
setwd(datdir)
load(file = "CLIP2_20210621.Rdata")
szg <- thyroid
load(file = "PTC-edited-20210511.Rdata")
nci <- df0
names(szg)
#[1] "Case"    "Clip2"   "Dose"    "l10Dose" "DoseGy"  "Cohort"  "Sex"     "Oblast"  "AaO"     "AaO2"    "AaE"     "AaE2"    "TsE"    
#[14] "TsE2"    "Type"    "DST"     "Exposed" "Score"   "CN"      "RET"     "BRAF" 
names(nci)
#[1] "Sex"          "AaO"          "AaE"          "Dose"         "CLIP2_VST_NT" "CLIP2_VST_TP" "cdelSNVr"     "cID8"        
#[9] "drv"          "C2rat"        "C2sur"        "AaEcat"       "AaE2"         "AaOcat"       "AaO2"         "TsE"         
#[17] "TsE2"         "Dcat"         "D3"

szg$AaE
nci$AaE
table(szg$Exposed)
szg$AaE[szg$Exposed == "no"] <- -1
szg$AaE
as.integer(szg$AaO)

# pairwise comparison
szgAaE <- rep(0,length(szg$AaO))
nciAaE <- rep(0,length(nci$AaO))
for(i in 1:length(szg$AaO))
{
  for(j in 1:length(nci$AaO))
  {
    diffAaE <- as.integer(szg$AaE[i])-as.integer(nci$AaE[j])
    diffAaO <- as.integer(szg$AaO[i])-as.integer(nci$AaO[j])
    #cat(sprintf("%3d %3d %3d\n", i, j, diffe))
    if(diffAaE == 0 & diffAaO == 0 & szg$Sex[i] == nci$Sex[j])
    {
      cat(sprintf("%3d %3d %3d %3d %2s\n", i, j, nci$AaE[j], nci$AaO[j], nci$Sex[j]))
      szgAaE[i] <- j
      nciAaE[j] <- i
    }
  }
}
