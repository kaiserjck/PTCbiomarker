#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# Calculation of ERR with binomial likelihood
# jck, 2021/06/27
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
#library(psych) # pairs.panels

library(caTools)
library(caret)
library(pROC)

library(gnm) # generalized non-linear models
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)



# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/CLIP2"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#------------------------------------------------------------
# read parameters and covariance matrix
#------------------------------------------------------------
setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- "DriverType-ERRdesc-err-pa-c0-c1-linAa0"
#fbasename <- "DriverType-ERRdesc-true-err-pa-c0-c1"
#fbasename <- "CLIP2-ERRdesc-c0-AaOlt20"

namvec <- strsplit(fbasename, split ="-")

marker <- namvec[[1]][1]

f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")
#exit <- file.exists("peduncular-all-distboth-m-K0-agAS2_parms.csv")
#ifelse(exit == T, mat <- read.csv(file = fname), "no")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#--------------------------------------------------------------------
# uncertainty calculations: mvrnorm
#--------------------------------------------------------------------
library(MASS)
# simulate multivariate normal distribution
nsim = 10000
sigma <- data.matrix(dcov[,-1]) # covariance matrix, skip first column containing row names

# hack: make sigma symmetric
sigma[upper.tri(sigma)] <- t(sigma)[upper.tri(sigma)]

cat(sprintf("--> CovMat dimens: %d\n", dim(sigma)[1]))
cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma, tol = 1e-20)))
cat(sprintf("--> CovMat eigenv: '%s'\n", all(1 == sign(eigen(sigma)$values)))) # check if all eigenvalues > 0
has.cov <- dpar$X %in% dcov$X # create vector denoting parameters present in dcov
pr <- dpar$parval[has.cov] # coefficients present in dcov

if (is.positive.definite(sigma,tol = 1e-20) == TRUE)
{Z <- mvrnorm(n=nsim,mu=pr,Sigma=sigma)}

apply(Z,2,mean)
apply(Z,2,sd)

#---------------------------------------------------------
# matrix of simulated parameters for uncertainty calculations
#--------------------------------------------------------- 
is.complete <- all(dpar$X %in% dcov$X) # check if dcov parameter set is complete
{ # if statement
  if(is.complete) {
    
    df.par <- data.frame(Z)
    colnames(df.par) <- dpar$X
    
  } else {
    
    nmpar <- dim(dpar[!has.cov,])[1] # no. of fixed parameters (not present in dcov)
    Y <- matrix(ncol = nmpar, nrow = nsim) # define matrix with NAs
    #dpar$parval[!has.cov]
    for(i in 1:nmpar)
    {
      Y[1:nsim,i] <- dpar$parval[!has.cov][i] # assign fixed parameter estimates to nsim rows
    }
    df.par <- data.frame(cbind(Z,Y)) # combine simulated and fixed parameters and convert to data frame
    colnames(df.par) <- c(dpar$X[has.cov],dpar$X[!has.cov]) # assign parameter names to columns
    df.par <- df.par[,dpar$X] # sort columns to original order
    
  }
} # end of if statement

summary(df.par)

#--------------------------------------------------------------------------
# prepare plot data
#--------------------------------------------------------------------------
setwd(statdir)
source("./subscripts/binlik.R")
upar <- vector()
upar <- as.numeric(dpar$parval)
upar

{
if (marker == "DriverType"){cena <- 28}
  else if (marker == "CLIP2"){cena <- 17} # 21 for all AaO
}
cena

AaO <- seq(10,45,1)
#acen <- log(AaO/cena)
acen <- (AaO-cena)/10
ndf <- length(AaO)
msex <- rep(0,ndf)
DoseGy <- rep(1,ndf)

df <- data.frame(AaO, acen, msex, DoseGy)
summary(df)

# ERR
errmn <- vector()
errlo <- vector()
errmd <- vector()
errhi <- vector()
errsav <- vector()
errmn <- ERRMarkDesc(upar[1], upar[2], upar[3], upar[4], df)
errsav <- unlist(lapply (1:nsim, function(j) ERRMarkDesc(df.par[j,1], df.par[j,2], df.par[j,3], df.par[j,4], df)))

# POC among positive markers
pocmn <- vector()
poclo <- vector()
pocmd <- vector()
pochi <- vector()
pocsav <- vector()
pocmn <- pocMarkDesc(upar[1], upar[2], upar[3], upar[4], upar[5], upar[6], df)
pocsav <- unlist(lapply (1:nsim, function(j) pocMarkDesc(df.par[j,1], df.par[j,2], df.par[j,3], df.par[j,4], 
                                                         df.par[j,5], df.par[j,6],df)))
# probability of causation for positive marker
mshmn <- vector()
mshlo <- vector()
mshmd <- vector()
mshhi <- vector()
mshsav <- vector()
mshmn <- mshMarkDesc(upar[1], upar[2], upar[3], upar[4], upar[5], upar[6], df)
mshsav <- unlist(lapply (1:nsim, function(j) mshMarkDesc(df.par[j,1], df.par[j,2], df.par[j,3], df.par[j,4], 
                                                         df.par[j,5], df.par[j,6],df)))
# sporadic relative risk
spomn <- vector()
spolo <- vector()
spomd <- vector()
spohi <- vector()
sposav <- vector()
spomn <- pSporMarkDesc (upar[5], upar[6], df)
sposav <- unlist(lapply (1:nsim, function(j) pSporMarkDesc(df.par[j,5], df.par[j,6], df)))

# loop of nsim sets of simulated parameters
for(i in 1:ndf)
{
  errsav <- unlist(lapply (1:nsim, function(j) ERRMarkDesc(df.par[j,1], df.par[j,2], df.par[j,3], df.par[j,4], df[i,])))
  errlo[i] <- quantile(errsav, probs = 0.025)
  errmd[i] <- quantile(errsav, probs = 0.5)
  errhi[i] <- quantile(errsav, probs = 0.975)
  sposav <- unlist(lapply (1:nsim, function(j) pSporMarkDesc (df.par[j,5], df.par[j,6], df[i,])))
  spolo[i] <- quantile(sposav, probs = 0.025)
  spomd[i] <- quantile(sposav, probs = 0.5)
  spohi[i] <- quantile(sposav, probs = 0.975)
  pocsav <- unlist(lapply (1:nsim, function(j) pocMarkDesc(df.par[j,1], df.par[j,2], df.par[j,3], df.par[j,4], 
                                                           df.par[j,5], df.par[j,6], df[i,])))
  poclo[i] <- quantile(pocsav, probs = 0.025)
  pocmd[i] <- quantile(pocsav, probs = 0.5)
  pochi[i] <- quantile(pocsav, probs = 0.975)
  mshsav <- unlist(lapply (1:nsim, function(j) mshMarkDesc(df.par[j,1], df.par[j,2], df.par[j,3], df.par[j,4], 
                                                           df.par[j,5], df.par[j,6], df[i,])))
  mshlo[i] <- quantile(mshsav, probs = 0.025)
  mshmd[i] <- quantile(mshsav, probs = 0.5)
  mshhi[i] <- quantile(mshsav, probs = 0.975)
}

#----------------------------------
# save model results
#----------------------------------

if(msex[1] == 0){Sex = "both"}
if(msex[1] == 1){Sex = "female"}
if(msex[1] == -1){Sex = "male"}

headline <- c("Marker","Estimator","AaO","Sex","Dose","estmn","estmd","estlo","esthi")

estimator <- "ERR"
errest <- data.frame(marker,estimator,AaO,Sex,DoseGy,errmn,errmd,errlo,errhi)
names(errest) <- headline
errest

estimator <- "SPO"
spoest <- data.frame(marker,estimator,AaO,Sex,DoseGy,spomn,spomd,spolo,spohi)
names(spoest) <- headline
spoest

# probability of causation among positive markers
estimator <- "POC"
pocest <- data.frame(marker,estimator,AaO,Sex,DoseGy,pocmn,pocmd,poclo,pochi)
names(pocest) <- headline
pocest

# probability of positive marker
estimator <- "MSH"
mshest <- data.frame(marker,estimator,AaO,Sex,DoseGy,mshmn,mshmd,mshlo,mshhi)
names(mshest) <- headline
mshest

desc <- rbind(errest,spoest,pocest,mshest)
summary(desc)

setwd(curvdir)
fsavname <- paste(fbasename,".Rdata",sep="")
save(desc, file = fsavname)
