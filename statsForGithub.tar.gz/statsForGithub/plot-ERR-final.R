#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# Plot ERR and others
# jck, 2021/07/03
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
library(forcats)
#library(psych) # pairs.panels

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/CLIP2"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#------------------------------------------------------------
# read parameters and covariance matrix
#------------------------------------------------------------
setwd(curvdir)

load(file = "DriverType-logreg-lDose-acen-msex.Rdata")
dtf <- desc
dtf

load(file = "CLIP2-logreg-lDose-acen-msex-intact.Rdata")
c2f <- subset(desc, Dose == 1)

load(file = "PTC-desc-kaiser2016.Rdata")
ref <- desc

names(ref)[1] <- c("ERR")
ref$ERR <- "Kaiser 2016"
ref

#names(dtf)

dtf.err <- subset(dtf, Estimator == "ERR")
c2f.err <- subset(c2f, Estimator == "ERR")
ref.err <- subset(ref, Estimator == "ERR")

#-------------------------------------------------------------
# plotting with risk
#-------------------------------------------------------------

# Tronko 2006
errm <- 5.25
errlo <- 1.7
errhi <- 27.5
p.T <- data.frame("mean(AaO) 16",16.5,errm,errlo,errhi)
names(p.T) <- c("CVCat","AaO","ERR","lo","hi")

# CLIP2 recalc
#errm <- 7.26
#errlo <- 2.27
#errhi <- 17.52
errm <- 5.2
errlo <- 2.1
errhi <- 13
p.C2 <- data.frame("mean(AaO) 16",15.5,errm,errlo,errhi)
names(p.C2) <- c("CVCat","AaO","ERR","lo","hi")

# Brenner 2001
errm <- 1.91
errlo <- 0.43
errhi <- 6.34
p.B <- data.frame("mean(AaO) 27",27,errm,errlo,errhi)
names(p.B) <- c("CVCat","AaO","ERR","lo","hi")

# Tronko 2017
errlo <- 0.39 # lo
errm <- 1.36 # mle
errhi <- 4.15 # hi
p.T17 <- data.frame("mean(AaO) 27",38,errm,errlo,errhi)
names(p.T17) <- c("CVCat","AaO","ERR","lo","hi")

p.ERR <- rbind(p.T,p.B,p.T17)
p.ERR

# Morton 2021
#errlo <- 2.89 # lo
#errm <- 7.92 # mle
#errhi <- 18.8 # hi
#errlo <- 3.7 # lo
#errm <- 9.3 # mle
#errhi <- 21.1 # hi
#p.M21 <- data.frame("mean(AaO) 28",28,errm,errlo,errhi)
#names(p.M21) <- c("CVCat","AaO","ERR","lo","hi")

p.marker <- rbind(p.C2)
p.marker

xline <- c(20,30.5,41.3)
yline <- c(5.2,1.91,1.36)
tline <- c("Tronko 2006","Brenner 2011","Tronko 2017")
cvcat <- c("mean(AaO) 16","mean(AaO) 27", "mean(AaO) 38")
study_text <- data.frame(cvcat,tline,xline,yline)
names(study_text) <- c("CVCat","Study","AaO","ERR")
study_text

xline <- c(11.6)
yline <- c(5.2)
#tline <- c("CLIP2\n(Kaiser 2016\nrecalc.)","Driver type\n(Morton 2021, Fig. 3B)")
tline <- c("Kaiser 2016\n(CLIP2)")
cvcat <- c("mean(AaO) 16")
marker_text <- data.frame(cvcat,tline,xline,yline)
names(marker_text) <- c("CVCat","Study","AaO","ERR")
marker_text

#geom_point(data = ukram, aes(x=age, y=mle, group= Study, color = Study), size=5) +
#geom_errorbar(data = ukram, aes(x=age, ymin=lo, ymax=hi, group = Study, color = Study), width = 1, size = 1) +

pf <- rbind(c2f.err,dtf.err)
pf$Marker <- fct_relevel(pf$Marker,c("DriverType","CLIP2"))
pf <- droplevels(pf)
summary(pf)
ref.err <- droplevels(ref.err)
ref.err <- ref.err[ref.err$AaO <= 35,]

myPalette <- c(cbPalette[2],cbPalette[3],cbPalette[4])
setwd(plotdir)
fp.1 <- ggplot() + 
  geom_line(data = pf, aes(x=AaO, y=estmn, color = Marker, group = Marker), size = 1) + 
  geom_ribbon(data = pf, aes(x=AaO, ymin = estlo, ymax = esthi, group = Marker), alpha = 0.2) +
  #geom_line(data = ref.err, aes(x=AaO, y=estmn, color = ERR, group = ERR), size = 1) + 
  #geom_ribbon(data = ref.err, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  #geom_ribbon(data = dtf.err, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  scale_color_manual(values = myPalette, 
                     labels = c("Morton 2021 (driver type)", "Kaiser 2016 (epidem.)"), name = "Study") +
  #scale_linetype_manual(values = c("dashed","solid","solid")) +
  scale_x_continuous(name = "Age at Operation (yrs)", limits = c(10,45), breaks = seq(10,45,5)) +
  scale_y_continuous(name = "Excess Relative Risk at 1 Gy", limits = c(0,100), breaks = seq(0,20,5)) +
  coord_cartesian(ylim = c(0,15)) +
  geom_point(data = p.ERR, aes(x=AaO, y=ERR), size=4) +
  #geom_errorbar(data = p.ERR, aes(x=AaO, ymin=lo, ymax=hi), width = .1, size = 1) +
  geom_linerange(data = p.ERR, aes(x=AaO, ymin=lo, ymax=hi), size = 1) +
  geom_point(data = p.marker, aes(x=AaO, y=ERR), color = cbPalette[8], size=4) +
  #geom_errorbar(data = p.marker, aes(x=AaO, ymin=lo, ymax=hi), color = cbPalette[8], width = .1, size = 1) +
  geom_linerange(data = p.marker, aes(x=AaO, ymin=lo, ymax=hi), color = cbPalette[8], size = 1) +
  geom_label(data = study_text, aes(x = AaO, y = ERR, label = Study, group = CVCat)) +
  geom_label(data = marker_text, aes(x = AaO, y = ERR, label = Study, group = CVCat)) +
  #guides(color=FALSE) +
  guides(linetype="none") +
  theme(text = element_text(size=15), legend.position = c(0.75,0.85)) 
print(fp.1)

ggsave("Figure3.eps", device=cairo_ps, fallback_resolution = 600, width = 17.4, height = 17.4, units = "cm")

fp.2 <- ggplot() + 
  geom_line(data = pf, aes(x=AaO, y=estmn, color = Marker, group = Marker, linetype = Marker), size = 1) + 
  #geom_ribbon(data = pf, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  geom_line(data = ref.err, aes(x=AaO, y=estmn, color = ERR, group = ERR), size = 1) + 
  #geom_ribbon(data = ref.err, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  geom_ribbon(data = dtf.err, aes(x=AaO, ymin = estlo, ymax = esthi), alpha = 0.2) +
  scale_color_manual(values = myPalette, 
                     labels = c("Driver type (with 95%CI)", "Kaiser 2016"), name = "age-dep. ERR") +
  #scale_linetype_manual(values = c("dashed","solid","solid")) +
  scale_x_continuous(name = "Age at Operation (yr)", limits = c(10,45), breaks = seq(10,45,5)) +
  scale_y_log10(name = "Excess Relative Risk at 1 Gy") +
  coord_cartesian(ylim = c(0.1, 25.1)) +
  geom_point(data = p.ERR, aes(x=AaO, y=ERR), size=4) +
  #geom_errorbar(data = p.ERR, aes(x=AaO, ymin=lo, ymax=hi), width = .1, size = 1) +
  geom_linerange(data = p.ERR, aes(x=AaO, ymin=lo, ymax=hi), size = 1) +
  geom_point(data = p.marker, aes(x=AaO, y=ERR), color = cbPalette[8], size=4) +
  #geom_errorbar(data = p.marker, aes(x=AaO, ymin=lo, ymax=hi), color = cbPalette[8], width = .1, size = 1) +
  geom_linerange(data = p.marker, aes(x=AaO, ymin=lo, ymax=hi), color = cbPalette[8], size = 1) +
  geom_label(data = study_text, aes(x = AaO, y = ERR, label = Study, group = CVCat)) +
  geom_label(data = marker_text, aes(x = AaO, y = ERR, label = Study, group = CVCat)) +
  #guides(color=FALSE) +
  guides(linetype="none") +
  theme(text = element_text(size=15), legend.position = c(0.25,0.15)) 
print(fp.2)

