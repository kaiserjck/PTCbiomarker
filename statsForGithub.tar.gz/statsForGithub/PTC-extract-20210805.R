#----------------------------------------------------------
# Extracting NCI CLIP2 data
# jck, 2021/08/05
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# read original data file
setwd("~/imodel/CLIP2/stats/data")
test <- read.csv(file = "abg2538-data-S1.csv", sep = ",")
dim(test) # 468 415
str(test)
names(test)
#CLIP2_VST_NT
#CLIP2_VST_TP
#WGS_TP_N_del_SNV_clonal
#SigPro_DC83_Clonal_ID5_Ct
#SigPro_DC83_Clonal_ID8_Ct
#Designated_DriverType

df0 <- data.frame(test$SEX,test$AGE_SURGERY,test$AGE_EXPOSURE,test$DOSE,
                  test$CLIP2_VST_NT,test$CLIP2_VST_TP,
                  test$Designated_DriverType)
str(df0)
headline <- c("SEX", "AGE_SURGERY", "AGE_EXPOSURE", "DOSE", "CLIP2_VST_NT", "CLIP2_VST_TP", "Designated_DriverType")
names(df0) <- headline
summary(df0)

dim(df0)
#save(df0, file = "PTC-selectedCOV-20210805.Rdata")
