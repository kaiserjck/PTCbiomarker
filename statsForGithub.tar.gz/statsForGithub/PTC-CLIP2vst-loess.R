#----------------------------------------------------------
# CLIP2_VST_TP mRNA expression
# jck, 2021/08/05
# AaE excluded to increase case numbers
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# libraries
library(caTools)
library(randomForest)
library(caret)
library(MLmetrics)
library(DescTools)
library(scoring)
library(pdp) # for partial dependence plots from many packages!
library(vip)
library(pROC)
library(rstatix)
library(psych)

# plotting
library(ggplot2)
library(ggpubr)
library(reshape2)
library(stringr)
library(directlabels)
library(metR)
library(RColorBrewer)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#--------------------------------------------
# read pre-edited data set
#--------------------------------------------
datdir <- "~/imodel/CLIP2/stats/data"
setwd(datdir)
load(file = "PTC-edited-20210809.Rdata")
dim(df0) # 468 19
names(df0)
#[1] "REBC_ID"      "Sex"          "AaO"          "AaE"          "Dose"         "lPur"         "CLIP2_VST_NT" "CLIP2_VST_TP"
#[9] "csmDEL14"     "csmDEL5p"     "cdelSNVr"     "cID5"         "cID8"         "drv"          "AaO2"         "AaE2"        
#[17] "TsE"          "TsE2"         "Exposed"   

#---------------------------------------------------------------------------------
# CLIP2 expression in focus
#---------------------------------------------------------------------------------
df <- df0
dim(df)[1] # 468

df <- df[complete.cases(df[c("CLIP2_VST_TP","Sex","AaO","Dose")]),] # note: AaE not used
dim(df)[1] # 408

#-----------------------------------
# remove 14 outliers
#----------------------------------
hist(df$CLIP2_VST_TP)
shapiro.test(df$CLIP2_VST_TP)
shapiro.test(log10(df$CLIP2_VST_TP))
# Density plot
#ggdensity(df$CLIP2_VST_TP, fill = "lightgray")
# QQ plot
#ggqqplot(df$CLIP2_VST_TP)

# remove outliers
df <- subset(df, CLIP2_VST_TP > 6)

hist(df$CLIP2_VST_TP)
# shapiro-wilk test on normality
shapiro.test(df$CLIP2_VST_TP)
shapiro.test(log10(df$CLIP2_VST_TP))
# Density plot
#ggdensity(df$CLIP2_VST_TP, fill = "lightgray")
# QQ plot
#ggqqplot(df$CLIP2_VST_TP)
#ggqqplot(log10(df$CLIP2_VST_TP))
dim(df)[1] # 394

table(df$Exposed, useNA = "ifany")
# no yes 
# 70 324

# Dose groups
df$D3 <- 1
df$D3[df$Dose > 0] <- 2
df$D3[df$Dose >= 100] <- 3
df$D3 <- factor(df$D3, levels = 1:3, labels = c("unexp","<100",">=100"))
table(df$D3, useNA = "ifany")
# unexp  <100 >=100 
#    70   171   153  

#------------------------------------------------
# scaling
#------------------------------------------------
mf <- df

# subtract median of unexposed for simplification
mdCLIP2 <- median(mf$CLIP2_VST_TP[mf$AaE2 == "unexp"])
mf$CLIP2_VST_TPs <- mf$CLIP2_VST_TP-median(mf$CLIP2_VST_TP[mf$AaE2 == "unexp"])

# rescale Dose
mf$DoseGy <- mf$Dose/1000
range(mf$DoseGy)

# like Kaiser CARCIN
mf$lDose <- log(mf$AaO)
mf$lDose[mf$Dose > 0] <- log(mf$Dose[mf$Dose > 0])
hist(mf$lDose)
range(mf$lDose)
shapiro.test(mf$lDose)

# like Morton SCIENCE
mf$DoseGytr <- mf$DoseGy
mf$DoseGytr[mf$DoseGytr > 1] <- 1
#hist(mf$DoseGytr)
#range(mf$DoseGytr)

dim(mf)[1] # 394
#-----------------------------------------------------------------
# density plot
#-----------------------------------------------------------------
cuts <- data.frame(Ref = c("median", "gmean", "amean"),
                   vals = c(median(df$CLIP2_VST_TP), exp(mean(log(df$CLIP2_VST_TP))), 
                            mean(df$CLIP2_VST_TP)),
                   stringsAsFactors = FALSE)

ggplot(df, aes(x=CLIP2_VST_TP)) + 
  ggtitle("n=394") +
  geom_histogram(aes(y=..density..),      # Histogram with density instead of count on y-axis
                 binwidth=.1,
                 colour="black", fill="white") +
  geom_density(alpha=.2, fill="#FF6666") +   # Overlay with transparent density plot
  scale_x_continuous(name = "CLIP2 mRNA expression") +
  #scale_x_log10(name = "CLIP2 mRNA expression") +
#  geom_vline(mapping = aes(xintercept = vals, colour = Ref), data = cuts, show.legend = F) +
#  geom_text(mapping = aes(x = vals,
#                          y = c(1.2,1.1,1),
#                          label = Ref,
#                          hjust = -.1,
#                          vjust = -.1),
#            data = cuts) +
  theme(text = element_text(size=15)) 

#-------------------------------------------------------------------------------------
# LOESS regression analysis
#-------------------------------------------------------------------------------------

#Fit a polynomial surface determined by one or more numerical predictors, using local fitting.
los.1 <- loess(CLIP2_VST_TPs ~ AaO * DoseGy, degree = 1, span = 1, data = mf)
#summary(los.1)
hist(predict(los.1))
# residual standard error
los.1$s

los.2 <- loess(CLIP2_VST_TPs ~ AaO * DoseGy, degree = 2, span = 1, data = mf)
#summary(los.2)
hist(predict(los.2))
# residual standard error
los.2$s

rf <- data.frame(mf,predict(los.2))
lastn <- dim(rf)[2]
names(rf)[lastn] <- "CLIP2_VST_TPLoess"
names(rf)

rt.1 <- glm(CLIP2_VST_TPs ~ DoseGy+AaO+Sex, data = rf[rf$AaO<20,])
summary(rt.1)

rt.2 <- glm(CLIP2_VST_TPs ~ DoseGy+AaO+Sex, data = rf[rf$AaO>=20,])
summary(rt.2)

rt.3 <- glm(CLIP2_VST_TPLoess ~ DoseGy+AaO+Sex, data = rf[rf$AaO<20,])
summary(rt.3)

rt.4 <- glm(CLIP2_VST_TPLoess ~ DoseGy+AaO+Sex, data = rf[rf$AaO>=20,])
summary(rt.4)

#-------------------------------------------------------------------------
# LOESS 2D plots
#-------------------------------------------------------------------------
range(rf$CLIP2_VST_TPLoess)
ylo <- range(rf$CLIP2_VST_TPs)[1]
yhi <- range(rf$CLIP2_VST_TPs)[2]

pf.1  <- ggplot() + 
  geom_point(data = rf, aes(x = log10(DoseGy+0.01), y = CLIP2_VST_TPs, color = "meas"), size = 1.5, alpha = 0.5) + 
  geom_point(data = rf, aes(x = log10(DoseGy+0.01), y = CLIP2_VST_TPLoess, color = "loess"), size = 1.5, alpha = 0.5) + 
  facet_grid(AaO2 ~ .) +
  coord_cartesian(ylim = c(ylo,yhi)) +
  theme(text = element_text(size=15)) 
print(pf.1)

#-------------------------------------------------------------------------
# contour plots
# https://www.r-statistics.com/2016/07/using-2d-contour-plots-within-ggplot2-to-visualize-relationships-between-three-variables/
#-------------------------------------------------------------------------

pf <- mf
#pf <- mf[mf$Dose < 100,]
#pf$Dose[pf$Dose > 1000] <- 1000
#pf <-mf[mf$TsE2 != ">=20",]
dim(pf)[1]
#pf$DoseGy <- (pf$Dose+pf$AaO)/1000

#Fit a polynomial surface determined by one or more numerical predictors, using local fitting.
data.loess <- loess(CLIP2_VST_TPs ~ AaO * DoseGy, degree = 2, span = 1, data = pf)
summary(data.loess)
hist(predict(data.loess))

# Create a sequence of incrementally increasing (by selected units) values for both AaO and DoseGy
xgrid <-  seq(min(pf$AaO), max(pf$AaO), 0.5)
ygrid <-  seq(min(pf$DoseGy), max(pf$DoseGy), 0.01)
# Generate a dataframe with every possible combination of AaO and DoseGy
data.fit <-  expand.grid(AaO = xgrid, DoseGy = ygrid)
# Feed the dataframe into the loess model and receive a matrix output with estimates of
# CLIP2exp for each combination of AaO and DoseGy
mtrx3d <-  predict(data.loess, newdata = data.fit)
# Abbreviated display of final matrix
mtrx3d[1:4, 1:4]
dim(mtrx3d)
dim(mtrx3d)[1]*dim(mtrx3d)[2]

contour(x = xgrid, y = ygrid, z = mtrx3d, xlab = "AaO", ylab = "DoseGy")

# Transform data to long form
mtrx.melt <- melt(mtrx3d, id.vars = c("AaO", "DoseGy"), measure.vars = "CLIP2_VST_TPs")
names(mtrx.melt) <- c("AaO", "DoseGy", "CLIP2_VST_TPs")
dim(mtrx.melt)

# Return data to numeric form
mtrx.melt$AaO <- as.numeric(str_sub(mtrx.melt$AaO, str_locate(mtrx.melt$AaO, "=")[1,1] + 1))
mtrx.melt$DoseGy <- as.numeric(str_sub(mtrx.melt$DoseGy, str_locate(mtrx.melt$DoseGy, "=")[1,1] + 1))

#mtrx.melt <- data.frame(mtrx.melt$AaO, mtrx.melt$DoseGy, predict(gam.1, newdata = data.fit))
#names(mtrx.melt) <- c("AaO", "DoseGy", "CLIP2exp")
#dim(mtrx.melt)

head(mtrx.melt)

brks <- seq(-10,10,2)
cp.1 <- ggplot(data = mtrx.melt, aes(x=AaO,y=DoseGy,z=CLIP2_VST_TPs)) +
  geom_contour(breaks = brks) +
  geom_dl(aes(label=..level..), method="bottom.pieces", 
          stat="contour", breaks = brks) +
  geom_point(data = pf, aes(x=AaO, y=DoseGy, color = Exposed)) +
  theme_bw () + 
  theme(text = element_text(size=15))

#direct.label(cp.1, list("top.bumptwice", dl.trans(y = y + 0.2)))
print(cp.1)

cp.2 <- ggplot(data = mtrx.melt, aes(x=AaO,y=DoseGy,z=CLIP2_VST_TPs)) +
  geom_contour(breaks = brks) +
  geom_text_contour(breaks = brks, size = 4) +
  #  geom_dl(aes(label=..level..), method="bottom.pieces", 
  #          stat="contour", breaks = brks) +
  geom_point(data = pf, aes(x=AaO, y=DoseGy, color = Exposed)) +
  theme_bw () + 
  theme(text = element_text(size=15))

#direct.label(cp.1, list("top.bumptwice", dl.trans(y = y + 0.2)))
print(cp.2)

brks <- seq(6,20,2)
#brks <- c(-0.15,-0.1,-0.05,0,0.05,0.1,0.15,0.2)
#brks <- seq(-0.15,0.2,0.05)
cp.3 <- ggplot(data = mtrx.melt, aes(x=AaO,y=DoseGy,z=CLIP2_VST_TPs)) +
  ggtitle(label = c("CLIP2_VST_TP\nLOESS, degree = 2, span = 1")) + 
  geom_contour_fill(breaks = brks, alpha = 0.3) +
  scale_y_continuous(name = "Thyroid dose (Gy)") + 
  scale_x_continuous(name = "Age at Operation (yr)", breaks = seq(10,45,5)) + 
  #scale_fill_gradientn(colours = terrain.colors(7)) +
  scale_fill_gradientn(name= "Range", colours = colorspace::diverge_hcl(7), breaks = brks, labels = factor(brks)) +
  geom_contour(color = "black", size = 0.1, breaks = brks) +
  geom_text_contour(breaks = brks, size = 4) +
  geom_point(data = pf, aes(x=AaO, y=DoseGy, color = Exposed)) +
  coord_cartesian(ylim = c(0,1)) +
  geom_vline(xintercept = 20, linetype = "dashed") +
  theme_bw () + 
  theme(text = element_text(size=15))

#direct.label(cp.3, list("top.bumptwice", dl.trans(y = y + 0.2)))
print(cp.3)

#-------------------------------------------------------------------------
# extract array of curves
#---------------------------------------------------------------------------
RColorBrewer::display.brewer.all()

pf.AaO <- subset(mtrx.melt, AaO == 15 |  AaO == 20 | AaO == 25 | AaO == 30 | AaO == 35 | AaO == 40)
#pf.AaO <- subset(mtrx.melt, AaO == 15 |  AaO == 20 | AaO == 25)
head(pf.AaO)
#pf.a16 <- subset(mtrx.melt, AaO == 30) 
#plot(x=pf.a16$DoseGy ,y = pf.a16$CLIP2exp, xlim = c(0,1), ylim = c(-1,1))
cf.1 <- ggplot(data = pf.AaO, aes(x=DoseGy,y=CLIP2_VST_TPs+mdCLIP2, group=AaO, color=factor(AaO))) +
  geom_point() + 
  coord_cartesian(xlim = c(0.0,1), ylim = c(-0.1+mdCLIP2,0.2+mdCLIP2)) +
  scale_color_manual(values = cbbPalette[2:8], name = "AaO (yr)") +
  #scale_color_brewer(palette = "Paired", name = "AaO (yr)") +
  #scale_color_hue(c = 40, name = "AaO (yr)") +
  scale_x_continuous(name = "Thyroid dose (Gy)", breaks = seq(0,5,0.2)) +
  scale_y_continuous(name = "CLIP2 expression (CLIP2_VST_TP)") +
  #theme_bw () + 
  theme(text = element_text(size=15), legend.position = c(0.75,0.8))
print(cf.1)

pf.DoseGy <- subset(mtrx.melt, DoseGy == 0 |  DoseGy == 0.1 | DoseGy == 0.5 | DoseGy == 1)
head(pf.DoseGy)
#pf.a16 <- subset(mtrx.melt, AaO == 30) 
#plot(x=pf.a16$DoseGy ,y = pf.a16$CLIP2exp, xlim = c(0,1), ylim = c(-1,1))
cf.2 <- ggplot(data = pf.DoseGy, aes(x=AaO,y=CLIP2_VST_TPs, group=DoseGy, color=factor(DoseGy))) +
  geom_point() + 
  coord_cartesian(xlim = c(10,40), ylim = c(-0.1,0.2)) +
  scale_color_manual(values = cbbPalette[5:8], name = "Thyroid dose (Gy)") +
  scale_x_continuous(name = "Age at operation (yr)", breaks = seq(10,40,5)) +
  scale_y_continuous(name = "CLIP2_VST_TP") +
  #theme_bw () + 
  theme(text = element_text(size=15), legend.position = c(0.25,0.8))
print(cf.2)

df.loess <- mtrx.melt 
df.loess$CLIP2_VST_TP <- df.loess$CLIP2_VST_TPs+mdCLIP2
names(df.loess)[2] <- "Dose"
df.loess <- data.frame(df.loess,"CLIP2expr")
names(df.loess)[5] <- "Marker"
names(df.loess)
curvdir <- "~/imodel/CLIP2/stats/curves"
setwd(curvdir)
fsavname <- "CLIP2vst-loess.Rdata"
save(df.loess, file = fsavname)
