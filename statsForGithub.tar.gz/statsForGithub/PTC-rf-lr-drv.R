#----------------------------------------------------------
# Random forest with PTC data
# jck, 2021/08/09
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# libraries
library(caTools)
library(randomForest)
library(caret)
library(MLmetrics)
library(DescTools)
library(scoring)
library(pdp) # for partial dependence plots from many packages!
library(vip)
library(pROC)
library(forcats)

# plotting
library(ggplot2)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

datdir <- "~/Nextcloud/imodel/CLIP2/stats/data"
setwd(datdir)
load(file = "PTC-edited-20210809.Rdata")
dim(df0) # 468  19
names(df0)
#[1] "REBC_ID"      "Sex"          "AaO"          "AaE"          "Dose"         "lPur"         "CLIP2_VST_NT" "CLIP2_VST_TP"
#[9] "csmDEL14"     "csmDEL5p"     "cdelSNVr"     "cID5"         "cID8"         "drv"          "AaO2"         "AaE2"        
#[17] "TsE"          "TsE2"         "Exposed"   

df0$TsE2 <- fct_relevel(df0$TsE2,"unexp","<20",">=20")
df0$AaE2 <- fct_relevel(df0$AaE2,"unexp","<5",">=5")

df <- df0
dim(df)

# Fig 2B
df$csmDEL <- df$csmDEL14 + df$csmDEL5p

df <- subset(df, cdelSNVr >= 0 & cdelSNVr < 1)

# remove outliers
hist(df$CLIP2_VST_TP)
df <- subset(df, CLIP2_VST_TP > 6)
hist(df$CLIP2_VST_TP)

hist(df$cdelSNVr)

df$CLIP2exp <- df$CLIP2_VST_TP-median(df$CLIP2_VST_TP[df$AaE2 == "unexp"])
df$DoseGy <- df$Dose/1000

# only pure tumors: Fig S1
#df <- subset(df, lPur == "no")
dim(df)[1]

#-----------------------------------------------------------------------------------------
# random forest
#-----------------------------------------------------------------------------------------
set.seed(1202)
selline <- c("drv",
             "DoseGy","Sex","AaO",
             #"Exposed",
             "AaE",
             "TsE",
             #"AaO2",
             #"AaE2",
             #"TsE2",
             "csmDEL","cdelSNVr",    
             "cID5","cID8",
             "CLIP2exp" 
)

cdf <- df[,selline]
str(cdf)
dim(cdf)
#cdf <- cdf[complete.cases(cdf[c("drv","AaO","AaE","TsE")]),]
#cdf <- subset(cdf, TsE2 != ">=20")
dim(cdf)
cdf <- cdf[complete.cases(cdf[c("drv")]),]
dim(cdf)
cdf$AaO <- as.numeric(cdf$AaO)
#cdf$AaE <- as.numeric(cdf$AaE)
#cdf$TsE <- as.numeric(cdf$TsE)
cdf$csmDEL <- as.numeric(cdf$csmDEL)
cdf$cID5 <- as.numeric(cdf$cID5)
cdf$cID8 <- as.numeric(cdf$cID8)
str(cdf)

cdf <- droplevels(cdf)

#cdf$size <- factor(cdf$size) # imputation needs factors
f <- as.formula(drv ~ .)
cdf.imp <- rfImpute(f, data = cdf)
#cdf.imp$size <- as.integer(cdf.imp$size)-1 # recast to integer

cdf <- cdf[complete.cases(cdf),]

dim(cdf)
dim(cdf.imp)

cdf <- cdf.imp

dim(cdf)

table(cdf[,1])
#---------------------------------------------------
# do it!
#---------------------------------------------------
f <- as.formula(drv ~ .)
rf <- randomForest(f, data = cdf,
                   ntree = 1000,
                   #mtry = 4,
                   importance = TRUE,
                   proximity = TRUE)
print(rf)

# oob prediction 
rf.roc <- roc(cdf$drv,rf$votes[,2])
#plot(rf.roc)
auc(rf.roc) 
ci.auc(rf.roc) 

rf.bs <- BrierScore(as.numeric(cdf$drv)-1,rf$votes[,2])
rf.bs 

pred <- factor(ifelse(rf$votes[,2] > .5, "fus", "mut"))
confusionMatrix(data = pred, reference = cdf$drv, positive = "fus")

#-------------------------------------------------------------------------
# some plots
#-------------------------------------------------------------------------
plot(rf)
varImpPlot(rf)
#varUsed(rf)

# extract vimp data
idf <- data.frame(importance(rf))

#------------------------------------------------
# plot MeanDecreaseAccuracy
#------------------------------------------------
both <- data.frame(idf[order(idf$MeanDecreaseAccuracy, decreasing = TRUE),])
pf.1 <- data.frame(rownames(both),as.numeric(both$MeanDecreaseAccuracy))
pf.1 <- data.frame(pf.1)
colnames(pf.1) <- c("Covariable","Value")
pf.1$Covariable <- factor(pf.1$Covariable, levels = pf.1$Covariable[order(pf.1$Value)])
pf.1$Selected <- "no"
pf.1$Selected[1:3] <- "yes"
pf.1$Selected <- as.factor(pf.1$Selected)
pf.1$Covariable <- factor(pf.1$Covariable, levels = pf.1$Covariable[order(pf.1$Value)])

#table(pf.1$Selected,pf.1$Covariable)

fp.1 <- ggplot()+
  ggtitle("MeanDecreaseAccuracy")+
  geom_bar(data = pf.1, aes(y=Covariable, x=Value, fill = Selected), stat = "identity", position = "dodge") +
  scale_fill_manual(values = c("no" = cbPalette[1], "yes" = cbPalette[2])) +
  theme(legend.position=c(.6,.4)) 
print(fp.1)

#---------------------------------------------------------------------------
# logistic regression
#---------------------------------------------------------------------------
mf <- cdf

#mf$TsE2 <- fct_relevel(mf$TsE2,"unexp","<20",">=20")
#mf$AaE2 <- fct_relevel(mf$AaE2,"unexp","<5",">=5")

# Dose
ptc.all <- glm(drv ~ ., 
                data = mf, family = binomial) 
summary(ptc.all)
round(AIC(ptc.all),1) 

prob = predict(ptc.all,type=c("response"))
g <- roc(drv ~ prob, data = mf)
auc(g) # 0.7673 
ci.auc(g) # 95% CI: 0.7158-0.8189 (DeLong)
all.bs <- BrierScore(as.numeric(mf$drv)-1,prob)
all.bs 

pred <- factor(ifelse(prob > .5, "fus", "mut"))
confusionMatrix(data = pred, reference = mf$drv, positive = "fus")

# AaO
ptc.AaO <- glm(drv ~ AaO, 
               data = mf, family = binomial) 
summary(ptc.AaO)
AIC(ptc.AaO)

# Dose
ptc.DoseGy <- glm(drv ~ DoseGy, 
               data = mf, family = binomial) 
summary(ptc.DoseGy)
AIC(ptc.DoseGy)

# TsE2
#ptc.TsE2 <- glm(drv ~ TsE2, 
#               data = mf, family = binomial) 
#summary(ptc.TsE2)
#AIC(ptc.TsE2) 

# AaE2
#ptc.AaE2 <- glm(drv ~ AaE2, 
#                data = mf, family = binomial) 
#summary(ptc.AaE2)
#AIC(ptc.AaE2)

# csmDEL
ptc.csmDEL <- glm(drv ~ csmDEL, 
               data = mf, family = binomial) 
summary(ptc.csmDEL)
AIC(ptc.csmDEL) 

# cdelSNVr
ptc.cdelSNVr <- glm(drv ~ cdelSNVr, 
                  data = mf, family = binomial) 
summary(ptc.cdelSNVr)
AIC(ptc.cdelSNVr) 

# cID5
ptc.cID5 <- glm(drv ~ cID5, 
                  data = mf, family = binomial) 
summary(ptc.cID5)
AIC(ptc.cID5) 

# cID8
ptc.cID8 <- glm(drv ~ cID8, 
                  data = mf, family = binomial) 
summary(ptc.cID8)
AIC(ptc.cID8) 

# CLIP2exp
ptc.CLIP2exp <- glm(drv ~ CLIP2exp, 
                data = mf, family = binomial) 
summary(ptc.CLIP2exp)
AIC(ptc.CLIP2exp) 

# flimsy because small contrast!
mf$C2sur <- 1
mf$C2sur[mf$CLIP2exp > .35] <- 2
mf$C2sur <- factor(mf$C2sur, levels = c(1:2), labels = c("no","yes"))
table(mf$C2sur)
ptc.C2sur <- glm(drv ~ C2sur, 
                data = mf, family = binomial) 
summary(ptc.C2sur)
AIC(ptc.C2sur)

tbl <- table(mf$C2sur,mf$drv)
tbl
chisq.test(tbl)

prob = predict(ptc.C2sur,type=c("response"))
g <- roc(drv ~ prob, data = mf)
auc(g) # 0.7673 
ci.auc(g) # 95% CI: 0.7158-0.8189 (DeLong)
C2sur.bs <- BrierScore(as.numeric(mf$drv)-1,prob)
C2sur.bs 

#---------------------------------------------------------------------------
# partial plotting
# ATTENTION: partial is a function from package pdp
#---------------------------------------------------------------------------
vip::vip(rf, bar = FALSE, horizontal = FALSE, size = 1.5, feature_names = "fus")

pdp::partial(ptc.all, pred.var = c("TsE2"), plot = T, prob = T) # package pdp
randomForest::partialPlot(rf, pred.data = cdf, x.var = c("CLIP2exp"))

p2 <- pdp::partial(rf, train = cdf, pred.var = "CLIP2exp", which.class = 2, plot = TRUE, prob = T,
                   plot.engine = "ggplot2")
print(p2)

plot(partial(rf, train = cdf, pred.var = "CLIP2exp", which.class = 2, plot = F, prob = T))

headline <- c("Model", "CV", "Value", "prob")
# continuous
# AaO
lAaO <- partial(ptc.AaO, pred.var = c("AaO"), plot = F, prob = T, plot.engine = "ggplot2")
lAaO <- cbind("LR","AaO",lAaO)
names(lAaO) <- headline

rAaO <- partial(rf, train = cdf, pred.var = "AaO", which.class = 2, plot = F, prob = T, plot.engine = "ggplot2")
rAaO <- cbind("RF","AaO",rAaO)
names(rAaO) <- headline

# DoseGy
lDoseGy <- partial(ptc.DoseGy, pred.var = c("DoseGy"), plot = F, prob = T)
lDoseGy <- cbind("LR","DoseGy",lDoseGy)
names(lDoseGy) <- headline

rDoseGy <- partial(rf, train = cdf, pred.var = "DoseGy", which.class = 2, plot = F, prob = T)
rDoseGy <- cbind("RF","DoseGy",rDoseGy)
names(rDoseGy) <- headline

# cdelSNVr
lcdelSNVr <- partial(ptc.cdelSNVr, pred.var = c("cdelSNVr"), plot = F, prob = T)
lcdelSNVr <- cbind("LR","cdelSNVr",lcdelSNVr)
names(lcdelSNVr) <- headline

rcdelSNVr <- partial(rf, train = cdf, pred.var = "cdelSNVr", which.class = 2, plot = F, prob = T)
rcdelSNVr <- cbind("RF","cdelSNVr",rcdelSNVr)
names(rcdelSNVr) <- headline

# csmDEL
lcsmDEL <- partial(ptc.csmDEL, pred.var = c("csmDEL"), plot = F, prob = T)
lcsmDEL <- cbind("LR","csmDEL",lcsmDEL)
names(lcsmDEL) <- headline

rcsmDEL <- partial(rf, train = cdf, pred.var = "csmDEL", which.class = 2, plot = F, prob = T)
rcsmDEL <- cbind("RF","csmDEL",rcsmDEL)
names(rcsmDEL) <- headline

# cID8
lcID8 <- partial(ptc.cID8, pred.var = c("cID8"), plot = F, prob = T)
lcID8 <- cbind("LR","cID8",lcID8)
names(lcID8) <- headline

rcID8 <- partial(rf, train = cdf, pred.var = "cID8", which.class = 2, plot = F, prob = T)
rcID8 <- cbind("RF","cID8",rcID8)
names(rcID8) <- headline

# cID5
lcID5 <- partial(ptc.cID5, pred.var = c("cID5"), plot = F, prob = T)
lcID5 <- cbind("LR","cID5",lcID5)
names(lcID5) <- headline

rcID5 <- partial(rf, train = cdf, pred.var = "cID5", which.class = 2, plot = F, prob = T)
rcID5 <- cbind("RF","cID5",rcID5)
names(rcID5) <- headline

# CLIP2exp
lCLIP2exp <- partial(ptc.CLIP2exp, pred.var = c("CLIP2exp"), plot = F, prob = T)
lCLIP2exp <- cbind("LR","CLIP2exp",lCLIP2exp)
names(lCLIP2exp) <- headline

rCLIP2exp <- partial(rf, train = cdf, pred.var = "CLIP2exp", which.class = 2, plot = F, prob = T)
rCLIP2exp <- cbind("RF","CLIP2exp",rCLIP2exp)
names(rCLIP2exp) <- headline

# TsE2
lTsE2 <- partial(ptc.TsE2, pred.var = c("TsE2"), plot = F, prob = T)
lTsE2 <- cbind("LR","TsE2",lTsE2)
names(lTsE2) <- headline

rTsE2 <- partial(rf, train = cdf, pred.var = "TsE2", which.class = 2, plot = F, prob = T)
rTsE2 <- cbind("RF","TsE2",rTsE2)
names(rTsE2) <- headline

# AaE2
lAaE2 <- partial(ptc.AaE2, pred.var = c("AaE2"), plot = F, prob = T)
lAaE2 <- cbind("LR","AaE2",lAaE2)
names(lAaE2) <- headline

rAaE2 <- partial(rf, train = cdf, pred.var = "AaE2", which.class = 2, plot = F, prob = T)
rAaE2 <- cbind("RF","AaE2",rAaE2)
names(rAaE2) <- headline

#pf <- rbind(lcdelSNVr,rcdelSNVr,lDoseGy,rDoseGy)
#pf <- rbind(lcID8,rcID8,lcID5,rcID5)
#pf <- rbind(lcdelSNVr,rcdelSNVr,lDoseGy,rDoseGy,lAaO,rAaO,lcID8,rcID8)
#pf <- rbind(lcdelSNVr,rcdelSNVr,lDoseGy,rDoseGy,lAaO,rAaO,lcID8,rcID8,lcID5,rcID5,lTsE2,rTsE2)
#pf <- rbind(lcdelSNVr,rcdelSNVr,lDoseGy,rDoseGy,lAaO,rAaO,lcID8,rcID8,lcID5,rcID5,lCLIP2exp,rCLIP2exp)
pf <- rbind(lcdelSNVr,rcdelSNVr,lDoseGy,rDoseGy,lAaO,rAaO,lcID8,rcID8,lcID5,rcID5,lcsmDEL,rcsmDEL)
#pf <- rbind(lTsE2,rTsE2,lAaE2,rAaE2)
summary(pf)
str(pf)

#setwd(plotdir)
#write.csv(pf,file="Fig2A.csv")

# data frame of cut points
#xline <- c(55,3,3.5,5.5,10,7.8)
#type <- c("Age","Size","PFprot","PFldh","PFneutroP","PFneutroC")
#xline <- c(55,3,3.5,5.5,7.8)
#type <- c("Age","Size","PFprot","PFldh","PFneutroC")
#cutp <- data.frame(type,xline)
#names(cutp) <- c("CV","value")
#cutp

# data frame of labels
#xline <- c(55,3,3.5,5.5,10,7.8)
#tline <- c("55 yr","3 (> 50 %)","3.5 g/dL","exp(5.5) U/L","10 %","exp(7.8) x 1000/mm3")
#type <- c("Age","Size","PFprot","PFldh","PFneutroP","PFneutroC")
#xline <- c(55,3,3.5,5.5,7.8)
#tline <- c("55 yr","3 (> 50 %)","3.5 g/dL","exp(5.5) U/L","exp(7.8) x 1000/mm3")
#type <- c("AaO","TsE","Dose")
#cutp_text <- data.frame(type,xline,tline)
#names(cutp_text) <- c("CV","Value","char")
#cutp_text

myPalette <- c(cbPalette[2],cbPalette[3])

pf$CV <- fct_relevel(pf$CV,c("DoseGy","AaO","cdelSNVr","csmDEL","cID5","cID8"))

fp.1 <- ggplot() + 
  ggtitle("n = 336") + 
  geom_point(data = pf, aes(x=Value, y=prob, color=Model)) + 
  facet_wrap(. ~ CV, ncol = 2, scales="free_x") + 
  #facet_wrap(. ~ CV, nrow = 2) + 
  scale_color_manual(values=myPalette) +
  scale_y_continuous(name = "Probability (fus)", limits = c(0,1), breaks = seq(0,1,.2)) +
  #geom_vline(data = cutp_text, aes(xintercept = Value, group = CV), linetype="dashed") +
  #geom_label(data = cutp_text, aes(x = xline, y = 0.6, label = tline, group = CV)) +
  coord_cartesian(ylim = c(-0.01, 1.01)) + 
  #guides(color=FALSE) +
  #theme(text = element_text(size=15), legend.position=c(.09,.92)) 
  theme(text = element_text(size=15), legend.position=c(.3,.8)) 
print(fp.1)
