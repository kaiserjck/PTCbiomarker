#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# Plot ERR and others
# jck, 2021/07/03
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
library(forcats)
#library(psych) # pairs.panels

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/Nextcloud/imodel/CLIP2"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#------------------------------------------------------------
# read data and prepare
#------------------------------------------------------------
setwd(curvdir)

load(file = "CLIP2-logreg-lDose-acen-msex-intact.Rdata")
mf <- desc

load(file = "CLIP2vst-loess.Rdata")
ef <- df.loess

headline <- c("CLIP2","AaO","Dose","Value")
names(mf)
mfp <- subset(mf, Estimator == "POC")
mfp <- data.frame(mfp$Marker,mfp$AaO,mfp$Dose,mfp$estmn)
names(mfp) <- headline
mfp <- subset(mfp, Dose > 0)
mfp$CLIP2 <- "Probability of CLIP2 protein marker"

efp <- data.frame(ef$Marker,ef$AaO,ef$Dose,ef$CLIP2_VST_TP)
names(efp) <- headline
efp <- subset(efp, Dose > 0 & Dose <= 1.5)
efp$CLIP2 <- "CLIP2 expression (CLIP2_VST_TP)"
range(efp$Value)

#-------------------------------------------------------------
# plotting with POC
#-------------------------------------------------------------
setwd(plotdir)
pf.all <- rbind(mfp,efp)
dim(pf.all)
str(pf.all)

pf <- subset(pf.all, AaO == 15 |  AaO == 20 | AaO == 25 | AaO == 30 | AaO == 35)
pf$fAaO <- as.factor(pf$AaO)
pf$fAaO <- fct_rev(pf$fAaO)
str(pf)

#myPalette <- c(cbPalette[2],cbPalette[3],cbPalette[4])
myPalette <- cbPalette

fp.1 <- ggplot() + 
  geom_line(data = pf, aes(x=Dose, y=Value, group=fAaO, color=fAaO), size = 1) + 
  facet_wrap(. ~ CLIP2, scales = "free_y") + 
  scale_color_manual(values = cbbPalette[2:8], name = "AaO (yrs)") +
  #scale_x_continuous(name = "Thyroid dose (Gy)", limits = c(0,1), breaks = seq(0,1,0.2)) +
  scale_x_log10(name = "Thyroid dose (Gy)", limits = c(0.01,1.5)) +
  #scale_y_continuous(name = "Probability of CLIP2 (+)", limits = c(0,1), breaks = seq(0,1,.2)) +
  #coord_cartesian(ylim = c(0,10)) +
  theme(text = element_text(size=15), legend.position = c(0.8,0.2), axis.title.y=element_blank()) 
  #theme(text = element_text(size=7), legend.position = c(0.8,0.2), axis.title.y=element_blank()) 
print(fp.1)

ggsave("Figure2-protein.eps", device=cairo_ps, fallback_resolution = 600, width = 17.4, height = 17.4, units = "cm")
#ggsave("Figure3.eps", device=cairo_ps, fallback_resolution = 600)

#library(cowplot)
#plot_grid(fp.2.1, fp.1, labels = c('A', 'B'), nrow = 1, label_size = 12)
