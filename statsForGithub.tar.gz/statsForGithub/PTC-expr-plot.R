#----------------------------------------------------------
# CLIP2 expression
# jck, 2021/07/28
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# libraries
library(caTools)
library(randomForest)
library(caret)
library(MLmetrics)
library(DescTools)
library(scoring)
library(pdp) # for partial dependence plots from many packages!
library(vip)
library(pROC)
library(rstatix)
library(psych)

# plotting
library(ggplot2)
library(reshape2)
library(stringr)
library(directlabels)
library(metR)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

datdir <- "~/imodel/CLIP2/stats/data"
setwd(datdir)
load(file = "PTC-edited-20210511.Rdata")
dim(df0)
names(df0)
#[1] "Sex"          "AaO"          "AaE"          "Dose"         "CLIP2_VST_NT" "CLIP2_VST_TP" "cdelSNVr"     "cID8"         "drv"         
#[10] "C2rat"        "C2sur"        "AaEcat"       "AaE2"         "AaOcat"       "AaO2"         "TsE"          "TsE2"         "Dcat"        
#[19] "D3" 

#df <- subset(df0, Dose < 2000)


#---------------------------------------------------------------------------------
# CLIP2 expression
#---------------------------------------------------------------------------------
df <- df0
dim(df)
set.seed(1503)
df <- df[complete.cases(df[c("CLIP2_VST_TP","Sex","AaO","AaE","TsE","Dose")]),]
#df <- df[complete.cases(df[c("CLIP2_VST_TP","Dose")]),]
dim(df[df$AaO2 == "<20",])[1]

#df$Dose[df$Dose > 1000] <- 1000

df$DoseAaO <- df$Dose + df$AaO

dim(df) # 369   19
hist(df$CLIP2_VST_TP)
hist(df$CLIP2_VST_TP[df$AaO2 == "<20"])
df <- subset(df, CLIP2_VST_TP > 6) # remove outliers
dim(df)# 356 19
hist(df$CLIP2_VST_TP)
hist(df$CLIP2_VST_TP[df$AaO2 == "<20"])
df$Exposed <- 1
df$Exposed[df$Dose > 0] <- 2
df$Exposed <- factor(df$Exposed, levels = 1:2, labels = c("no","yes"))
table(df$Exposed,df$AaE2)
# no yes 
# 66 290 

hist(log10(df$DoseAaO))

df$D5 <- 1
df$D5[df$Dose > 0] <- 2
df$D5[df$Dose > 50] <- 3
df$D5[df$Dose > 100] <- 4
df$D5[df$Dose > 200] <- 5

df$D5 <- factor(df$D5, levels = 1:5, labels = c("unexp","<50","50-100","100-200",">200"))
table(df$D5)

df$D3 <- 1
df$D3[df$Dose > 0] <- 2
df$D3[df$Dose > 100] <- 3

df$D3 <- factor(df$D3, levels = 1:3, labels = c("unexp","<=100",">100"))
table(df$D3)

t.test(data = df, CLIP2_VST_TP ~ Sex)
t.test(data = df, CLIP2_VST_TP ~ Exposed)
dim(df[df$AaO2 == "<20",])[1] # 32
t.test(data = df[df$AaO2 == "<20",], CLIP2_VST_TP ~ Exposed)
t.test(data = df[df$TsE2 != ">=20",], CLIP2_VST_TP ~ Exposed)

pwc <- pairwise_t_test(CLIP2_VST_TP ~ TsE2, p.adjust.method = "bonferroni", data = df)
pwc
pwc <- pairwise_t_test(CLIP2_VST_TP ~ D5, p.adjust.method = "bonferroni", data = df)
pwc
pwc <- pairwise_t_test(CLIP2_VST_TP ~ D3, p.adjust.method = "bonferroni", data = df)
pwc


#---------------------------------------------------------------------------
# GLM regression
#---------------------------------------------------------------------------
mf <- df

mf$CLIP2exp <- mf$CLIP2_VST_TP-median(mf$CLIP2_VST_TP[mf$AaE2 == "unexp"])

dim(mf)[1] # 356

aggregate(df$TsE,list(df$TsE2),mean)
aggregate(df$Dose,list(df$TsE2),mean)
aggregate(df$Dose,list(df$TsE2),length)
aggregate(df$Dose,list(df$D5),mean)
aggregate(df$Dose,list(df$D5),length)
aggregate(df$Dose,list(df$Exposed),mean)

# TsE2
ptc.1 <- glm(CLIP2exp ~ TsE2, data = mf) 
summary(ptc.1)

ptc.2 <- glm(CLIP2exp ~ AaE2, data = mf) 
summary(ptc.2)

ptc.3 <- glm(CLIP2exp ~ Exposed, data = mf[mf$TsE2 != ">=20",]) 
summary(ptc.3)

ptc.4 <- glm(CLIP2exp ~  Exposed, data = mf)
summary(ptc.4)

ptc.5 <- glm(CLIP2exp ~  D3 + Sex, data = mf) 
summary(ptc.5)

ptc.6 <- glm(CLIP2exp ~  Dose + Sex, data = mf[mf$Dose <= 100 & mf$TsE2 != ">=20",]) 
summary(ptc.6)

ptc.7 <- glm(CLIP2exp ~  Dose + Sex, data = mf[mf$AaO < 20,]) 
summary(ptc.7)

ptc.8 <- glm(CLIP2exp ~  Dose + Sex, data = mf[mf$AaO < 18 & mf$Dose < 1000,]) 
summary(ptc.8)

ptc.9 <- glm(CLIP2exp ~  Dose:AaO2 + Sex, data =  mf[mf$Dose < 1000,]) 
summary(ptc.9)

ptc.10 <- glm(CLIP2exp ~  Dose:AaO2 + Sex, data =  mf) 
summary(ptc.10)

ptc.11 <- glm(CLIP2exp ~ Exposed:AaO2-1, data = mf) 
summary(ptc.11)

Dose = seq(0,1000,10)
predict(ptc.9, newdata = data.frame(Dose))

pl <- profile(ptc.9)
plot(pl)
coef(pl)
upar <- coef(pl)
lp.CI <- confint(pl)
round(lp.CI,5)
has.profile <- TRUE


#-------------------------------------------------------------------------
# contour plots
# https://www.r-statistics.com/2016/07/using-2d-contour-plots-within-ggplot2-to-visualize-relationships-between-three-variables/
#-------------------------------------------------------------------------


pf <- mf
#pf$Dose[pf$Dose > 1000] <- 1000
#pf <-mf[mf$TsE2 != ">=20",]
dim(pf)[1]
#pf$DoseGy <- (pf$Dose+pf$AaO)/1000
pf$DoseGy <- pf$Dose/1000

#Fit a polynomial surface determined by one or more numerical predictors, using local fitting.
data.loess <- loess(CLIP2exp ~ AaO * DoseGy, data = pf)
summary(data.loess)
hist(predict(data.loess))

# Create a sequence of incrementally increasing (by selected units) values for both AaO and DoseGy
xgrid <-  seq(min(pf$AaO), max(pf$AaO), 0.5)
ygrid <-  seq(min(pf$DoseGy), max(pf$DoseGy), 0.01)
# Generate a dataframe with every possible combination of AaO and DoseGy
data.fit <-  expand.grid(AaO = xgrid, DoseGy = ygrid)
# Feed the dataframe into the loess model and receive a matrix output with estimates of
# CLIP2exp for each combination of AaO and DoseGy
mtrx3d <-  predict(data.loess, newdata = data.fit)
# Abbreviated display of final matrix
mtrx3d[1:4, 1:4]
dim(mtrx3d)
dim(mtrx3d)[1]*dim(mtrx3d)[2]

contour(x = xgrid, y = ygrid, z = mtrx3d, xlab = "AaO", ylab = "DoseGy")

# Transform data to long form
mtrx.melt <- melt(mtrx3d, id.vars = c("AaO", "DoseGy"), measure.vars = "CLIP2exp")
names(mtrx.melt) <- c("AaO", "DoseGy", "CLIP2exp")
dim(mtrx.melt)

# Return data to numeric form
mtrx.melt$AaO <- as.numeric(str_sub(mtrx.melt$AaO, str_locate(mtrx.melt$AaO, "=")[1,1] + 1))
mtrx.melt$DoseGy <- as.numeric(str_sub(mtrx.melt$DoseGy, str_locate(mtrx.melt$DoseGy, "=")[1,1] + 1))

head(mtrx.melt)

brks <- c(-0.6,-0.4,-0.2,0,0.2,0.4,0.6)
cp.1 <- ggplot(data = mtrx.melt, aes(x=AaO,y=DoseGy,z=CLIP2exp)) +
  geom_contour(breaks = brks) +
  geom_dl(aes(label=..level..), method="bottom.pieces", 
          stat="contour", breaks = brks) +
  geom_point(data = pf, aes(x=AaO, y=DoseGy, color = Exposed)) +
  theme_bw () + 
  theme(text = element_text(size=15))

#direct.label(cp.1, list("top.bumptwice", dl.trans(y = y + 0.2)))
print(cp.1)

cp.2 <- ggplot(data = mtrx.melt, aes(x=AaO,y=DoseGy,z=CLIP2exp)) +
  geom_contour(breaks = brks) +
  geom_text_contour(breaks = brks, size = 4) +
#  geom_dl(aes(label=..level..), method="bottom.pieces", 
#          stat="contour", breaks = brks) +
  geom_point(data = pf, aes(x=AaO, y=DoseGy, color = Exposed)) +
  theme_bw () + 
  theme(text = element_text(size=15))

#direct.label(cp.1, list("top.bumptwice", dl.trans(y = y + 0.2)))
print(cp.2)

cp.3 <- ggplot(data = mtrx.melt, aes(x=AaO,y=DoseGy,z=CLIP2exp)) +
  geom_contour_fill(breaks = brks, alpha = 0.3) +
  scale_y_continuous(name = "Thyroid dose (Gy)") + 
  scale_x_continuous(name = "Age at Operation (yr)", breaks = seq(10,45,5)) + 
  #scale_fill_gradientn(colours = terrain.colors(7)) +
  scale_fill_gradientn(name= "CLIP2\nexpr.", colours = colorspace::diverge_hcl(7), breaks = brks, labels = factor(brks)) +
  geom_contour(color = "black", size = 0.1, breaks = brks) +
  geom_text_contour(breaks = brks, size = 4) +
  geom_point(data = pf, aes(x=AaO, y=DoseGy, color = Exposed)) +
  coord_cartesian(ylim = c(0,1)) +
  geom_vline(xintercept = 20, linetype = "dashed") +
  theme_bw () + 
  theme(text = element_text(size=15))

#direct.label(cp.1, list("top.bumptwice", dl.trans(y = y + 0.2)))
print(cp.3)

#---------------------------------------------------------------------------
# GAM regression
#---------------------------------------------------------------------------

library(mgcv)
gam.1 <- gam(CLIP2exp ~  te(DoseGy,AaO,k=30), data = mtrx.melt)
summary(gam.1)
deviance(gam.1)
AIC(gam.1)
gam.check(gam.1)
hist(predict(gam.1))

gam.2 <-gam(CLIP2exp ~  s(DoseGy) + AaO, data = mtrx.melt)
summary(gam.2)
deviance(gam.2)
AIC(gam.2)
gam.check(gam.2)
hist(predict(gam.2))

gam.3 <-gam(CLIP2exp ~  s(DoseGy) + s(AaO), data = mtrx.melt)
summary(gam.3)
deviance(gam.3)
AIC(gam.3)
gam.check(gam.3)
hist(predict(gam.3))

df.gam <- data.frame(mtrx.melt[,1:2],predict(gam.1))
names(df.gam) <- names(mtrx.melt)
head(df.gam)

data.gam <- gam(CLIP2exp ~  s(DoseGy) + s(AaO), data = pf)
summary(data.gam)
deviance(data.gam)
AIC(data.gam)
gam.check(data.gam)
hist(predict(data.gam))

df.gam <- data.frame(mtrx.melt[,1:2],predict(data.gam, newdata = data.fit))
names(df.gam) <- c("AaO", "DoseGy", "CLIP2exp")
head(df.gam)


rf <- data.frame(pf,predict(data.loess))
names(rf)[25] <- "CLIP2loess"
names(rf)

rt.1 <- glm(CLIP2exp ~ DoseGy:AaO2, data = rf)
summary(rt.1)

rt.2 <- glm(CLIP2loess ~ DoseGy:AaO2, data = rf)
summary(rt.2)

plot(x=rf$DoseGy[rf$AaO<20],y=rf$CLIP2loess[rf$AaO<20])










