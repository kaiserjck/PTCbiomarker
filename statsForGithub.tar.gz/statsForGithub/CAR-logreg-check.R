#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# Comparison of results with Morton 2021
# for surrogate CLIP2 marker (C2sur) and Mutation/Fusion marker (Driver type drv)
# jck, 2021/06/23
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
library(survival)
#library(psych) # pairs.panels

library(caTools)
library(randomForest)
library(caret)
library(MLmetrics)
library(DescTools)
library(scoring)

library(grid)
library(gridExtra)

library(pROC)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# directories
datdir <- "~/imodel/CLIP2/stats/data"
setwd(datdir)

---------------------------------------------
# UkrAm PTC data
#---------------------------------------------
load(file = "CLIP2_20210621.Rdata")
names(thyroid)
#[1] "Case"    "Clip2"   "Dose"    "l10Dose" "DoseGy"  "Cohort"  "Sex"     "Oblast"  "AaO"     "AaO2"    "AaE"     "AaE2"    "TsE"    
#[14] "TsE2"    "Type"    "DST"     "Exposed" "Score"   "CN"      "RET"     "BRAF"   

df <- thyroid
dim(df)# 141  21
str(df)
summary(df)

# Age means
aggregate(df$AaO,list(df$AaO2),mean)
#   Group.1        x
# 1     <20 16.59816
# 2    >=20 26.74246

aggregate(df$AaO,list(df$AaE2),mean)
#     Group.1        x
# 1        <5 18.21159
# 2       >=5 27.63315
# 3 unexposed 15.00833

aggregate(df$AaO,list(df$TsE2),mean)
#     Group.1        x
# 1       <20 21.42860
# 2      >=20 29.21529
# 3 unexposed 15.00833

df$lDose <- log(df$DoseGy)
#-----------------------------------------------------
# logistic regression
#-----------------------------------------------------

dim(df)[1] # 141
ukr.1 <- glm(Clip2 ~ lDose, data = df, family = "binomial")
summary(ukr.1)

#---------------------------------------------------------------
# Selmansberger et al., Carcinogenesis 2015, Table 4
#---------------------------------------------------------------
# AaO < 20
dim(df[df$AaO2 == "<20",])[1] # 76
ukr.2 <- glm(Clip2 ~ lDose, data = df[df$AaO2 == "<20",], family = "binomial")
summary(ukr.2)
pr1 <- profile(ukr.2)
#plot(pr1)
#pairs(pr1)
confint(pr1, level = 0.95)

prob = predict(ukr.2,type=c("response"))
g <- roc(Clip2 ~ prob, data=df[df$AaO2 == "<20",])
auc(g) # Area under the curve: 0.7663
ci.auc(g) # 95% CI: 0.6519-0.8807 (DeLong)
BrierScore(as.numeric(df$Clip2[df$AaO2 == "<20"])-1,prob) # 0.1884805

pLevel <- length(df$Clip2[df$Clip2 == "pos" & df$AaO2 == "<20"])/length(df$Clip2[df$AaO2 == "<20"])
pLevel
pred <- factor(ifelse(prob > pLevel, "pos", "neg"))
confusionMatrix(reference = reorder(df$Clip2[df$AaO2 == "<20"]), data = pred, positive = "pos")

# AaO >= 20
ukr.3 <- glm(Clip2 ~ lDose, data = df[df$AaO2 == ">=20",], family = "binomial")
summary(ukr.3)

prob = predict(ukr.3,type=c("response"))
g <- roc(Clip2 ~ prob, data=df[df$AaO2 == ">=20",])
auc(g) 
ci.auc(g) 
BrierScore(as.numeric(df$Clip2[df$AaO2 == ">=20"])-1,prob)

pLevel <- length(df$Clip2[df$Clip2 == "pos" & df$AaO2 == ">=20"])/length(df$Clip2[df$AaO2 == ">=20"])
pLevel
pred <- factor(ifelse(prob > pLevel, "pos", "neg"))
confusionMatrix(reference = reorder(df$Clip2[df$AaO2 == ">=20"]), data = pred, positive = "pos")

# AaE < 5
ukr.4 <- glm(Clip2 ~ lDose, data = df[df$AaE2 == "<5",], family = "binomial")
summary(ukr.4)

# AaE >= 5
ukr.5 <- glm(Clip2 ~ lDose, data = df[df$AaE2 == ">=5",], family = "binomial")
summary(ukr.5)

#-------------------------------------------------------------------
# new: TsE dependence
#-------------------------------------------------------------------

# TsE < 20
ukr.6 <- glm(Clip2 ~ lDose, data = df[df$TsE2 == "<20",], family = "binomial")
summary(ukr.6)

# TsE >= 20
ukr.7 <- glm(Clip2 ~ lDose, data = df[df$TsE2 == ">=20",], family = "binomial")
summary(ukr.7)

#-------------------------------------------------------------------
# Morton et al. 2021
#-------------------------------------------------------------------
setwd(datdir)
load(file = "PTC-edited-20210805.Rdata")
dim(df0) # 468  12
names(df0)
#[1] "Sex"          "AaO"          "AaE"          "Dose"         "CLIP2_VST_NT" "CLIP2_VST_TP" "drv"          "AaO2"         "AaE2"        
#[10] "TsE2"         "TsE"          "Exposed" 

str(df0)
summary(df0)

# check na's
cs <- colSums(!is.na(df0))
cs <- as.data.frame(cs)
print(cs)

# quick and dirty
#df0$lDose <- log((df0$Dose+1)/1000)

#--------------------------------------------
# driver type marker 
#--------------------------------------------

#ddf <- df0[complete.cases(df0[,c("drv","Dose","AaO","AaE2","TsE2"),]),]
ddf <- cdf
dim(ddf) # 429 12
table(ddf$drv)
# mut fus 
# 253 176 

range(ddf$Dose) # 0 8800

# like Selmansberger et al. 2015
ddf$lDose <- log(ddf$Dose/1000)
ddf$lDose[ddf$Dose == 0] <-  log(ddf$AaO[ddf$Dose == 0]/1000)
ddf$lDose[ddf$Exposed == "no"] <-  log(ddf$AaO[ddf$Exposed == "no"]/1000)

table(ddf$drv[ddf$AaO2 == "<20"])
# mut fus 
#  23  35 

# validation
prob = predict(ukr.2,newdata=ddf[ddf$AaO2 == "<20",], type=c("response"))
g <- roc(drv ~ prob, data=ddf[ddf$AaO2 == "<20",])
auc(g) # Area under the curve: 0.6652
ci.auc(g) # 95% CI: 0.5252-0.8052 (DeLong)
BrierScore(as.numeric(ddf$drv[ddf$AaO2 == "<20"])-1,prob) # 0.2304531

pLevel <- length(ddf$drv[ddf$drv == "fus" & ddf$AaO2 == "<20"])/length(ddf$drv[ddf$AaO2 == "<20"])
pLevel
pred <- factor(ifelse(prob > pLevel, "fus", "mut"))
confusionMatrix(reference = reorder(ddf$drv[ddf$AaO2 == "<20"]), data = pred, positive = "fus")

# logistic regression
dim(ddf[ddf$AaO2 == "<20",])[1] # 58
mfm.2 <- glm(drv ~ lDose, data = ddf[ddf$AaO2 == "<20",], family = "binomial")
summary(mfm.2)

prob = predict(mfm.2,type=c("response"))
g <- roc(drv ~ prob, data=ddf[ddf$AaO2 == "<20",])
auc(g) # Area under the curve: 0.6652
ci.auc(g) # 95% CI:  0.5252-0.8052 (DeLong)
BrierScore(as.numeric(ddf$drv[ddf$AaO2 == "<20"])-1,prob) # 0.2075218

mfm.3 <- glm(drv ~ lDose, data = ddf[ddf$AaO2 == ">=20",], family = "binomial")
summary(mfm.3)

prob = predict(mfm.3,type=c("response"))
g <- roc(drv ~ prob, data=ddf[ddf$AaO2 == ">=20",])
auc(g) # Area under the curve: 0.6227
ci.auc(g) # 95% CI:0.5623-0.6831 (DeLong)
BrierScore(as.numeric(ddf$drv[ddf$AaO2 == ">=20"])-1,prob) # 0.2221338

mfm.4 <- glm(drv ~ lDose, data = ddf[ddf$AaE2 == "<5",], family = "binomial")
summary(mfm.4)

mfm.5 <- glm(drv ~ lDose, data = ddf[ddf$AaE2 == ">=5",], family = "binomial")
summary(mfm.5)

#--------------------------------------------------------
# plotting
#--------------------------------------------------------

dr2Gy <- data.frame(seq(0.01,2,0.01))
names(dr2Gy) <- "DoseGy"
ldr2Gy <- data.frame(log(dr2Gy))
names(ldr2Gy) <- "lDose"

probab <- function(lp)
{
        1/(1+exp(-lp))
}

p975 <- qnorm(0.975)
p025 <- qnorm(0.025)

# build data frames for plotting
# AaO < 20
lp <- predict(ukr.2, newdata = ldr2Gy)
resp <- predict(ukr.2, newdata = ldr2Gy, type = "response")
lolp <- p025*predict(ukr.2, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(ukr.2, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
uf.2 <- data.frame("S2015 (CLIP2)","AaO", "AaO <20", dr2Gy, prob, lo, hi)
names(uf.2) <- c("Study","CV","Cat","Dose","prob","lo","hi")
uf.2

# AaO >= 20
lp <- predict(ukr.3, newdata = ldr2Gy)
lolp <- p025*predict(ukr.3, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(ukr.3, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
uf.3 <- data.frame("S2015 (CLIP2)","AaO", "AaO >=20",dr2Gy, prob, lo, hi)
names(uf.3) <- c("Study","CV","Cat","Dose","prob","lo","hi")
uf.3

# AaE < 5
lp <- predict(ukr.4, newdata = ldr2Gy)
lolp <- p025*predict(ukr.4, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(ukr.4, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
uf.4 <- data.frame("S2015 (CLIP2)","AaE", "AaE <5",dr2Gy, prob, lo, hi)
names(uf.4) <- c("Study","CV","Cat","Dose","prob","lo","hi")
uf.4

# AaE >= 5
lp <- predict(ukr.5, newdata = ldr2Gy)
lolp <- p025*predict(ukr.5, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(ukr.5, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
uf.5 <- data.frame("S2015 (CLIP2)","AaE", "AaE >=5",dr2Gy, prob, lo, hi)
names(uf.5) <- c("Study","CV","Cat","Dose","prob","lo","hi")
uf.5

uf <- rbind(uf.2,uf.3,uf.4,uf.5)
summary(uf)

# Driver type, Morton 2021
# AaO < 20
lp <- predict(mfm.2, newdata = ldr2Gy)
lolp <- p025*predict(mfm.2, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(mfm.2, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
tf.2 <- data.frame("M2021 (driver)","AaO", "AaO <20",dr2Gy, prob, lo, hi)
names(tf.2) <- c("Study","CV","Cat","Dose","prob","lo","hi")
tf.2

# AaO >= 20
lp <- predict(mfm.3, newdata = ldr2Gy)
lolp <- p025*predict(mfm.3, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(mfm.3, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
tf.3 <- data.frame("M2021 (driver)","AaO", "AaO >=20",dr2Gy, prob, lo, hi)
names(tf.3) <- c("Study","CV","Cat","Dose","prob","lo","hi")
tf.3

# AaE < 5
lp <- predict(mfm.4, newdata = ldr2Gy)
lolp <- p025*predict(mfm.4, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(mfm.4, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
tf.4 <- data.frame("M2021 (driver)","AaE", "AaE <5",dr2Gy, prob, lo, hi)
names(tf.4) <- c("Study","CV","Cat","Dose","prob","lo","hi")
tf.4

# AaE >= 5
lp <- predict(mfm.5, newdata = ldr2Gy)
lolp <- p025*predict(mfm.5, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(mfm.5, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
tf.5 <- data.frame("M2021 (driver)","AaE", "AaE >=5",dr2Gy, prob, lo, hi)
names(tf.5) <- c("Study","CV","Cat","Dose","prob","lo","hi")
tf.5

tf <- rbind(tf.2,tf.3,tf.4,tf.5)
summary(tf)

#setwd(datdir)
#pf.2015 <- pf
#save(pf.2015, file = "PC2-Selmansberger2015-Rdata")

uf.AaO <- subset(uf, CV == "AaO")
#sf.AaO <- subset(sf, CV == "AaO")
tf.AaO <- subset(tf, CV == "AaO")
pf <- rbind(uf.AaO,tf.AaO)
summary(pf)

fp.1 <- ggplot() + 
        geom_line(data = pf, aes(x=Dose, y=prob, color = Study), size = 1.0) + 
        #geom_line(data = sf, aes(x=Dose, y=prob, color = Cat)) + 
        geom_ribbon(data = pf, aes(x=Dose,ymin=lo, ymax=hi, group = Study), alpha=0.2) +
        facet_wrap(. ~ Cat, nrow = 3) + 
        scale_color_manual(values = cbPalette[2:5]) +
        scale_x_continuous(name = "Thyroid dose (Gy)") +
        scale_y_continuous(name = "Probability (Marker+)", limits = c(0,1), breaks = seq(0,1,.2)) +
        coord_cartesian(xlim = c(0.01, 2.01), ylim = c(-0.01, 1.01)) + 
        #guides(color=FALSE) +
        theme(text = element_text(size=15)) 
print(fp.1)

#---------------------------------------------------------------
# plot with ERR from Tronko, cf. Kaiser 2016
#---------------------------------------------------------------
uf.AaOlo <- subset(uf, Cat == "AaO <20")
#sf.AaOlo <- subset(sf, Cat == "AaO <20")
tf.AaOlo <- subset(tf, Cat == "AaO <20")
#pf <- rbind(uf.AaOlo,sf.AaOlo,tf.AaOlo)
pf <- rbind(uf.AaOlo,tf.AaOlo)
#pf <- rbind(uf.AaOlo,sf.AaOlo)
summary(pf)

# Tronko 2006
errm <- 5.25
errlo <- 1.7
errhi <- 27.5
pTm <- errm/(1+errm)
pTlo <- errlo/(1+errlo)
pThi <- errhi/(1+errhi)
p.T <- data.frame("AaO <20",1,pTm,pTlo,pThi)
names(p.T) <- c("CVCat","Dose","prob","hi","lo")

xline <- c(1.150)
yline <- c(0.8)
tline <- c("Tronko 2006")
cvcat <- c("AaO <20")
study_text <- data.frame(cvcat,tline,xline,yline)
names(study_text) <- c("CVCat","Study","Dose","prob")
study_text

fp.2 <- ggplot() + 
        geom_line(data = pf, aes(x=Dose, y=prob, color = Study), size = 1.0) + 
        #geom_line(data = sf, aes(x=Dose, y=prob, color = Cat)) + 
        geom_ribbon(data = pf, aes(x=Dose,ymin=lo, ymax=hi, group = Study), alpha=0.2) +
        geom_point(data = p.T, aes(x=Dose, y=prob), size=4) +
        geom_errorbar(data = p.T, aes(x=Dose, ymin=lo, ymax=hi), width = .1, size = 1) +
        geom_label(data = study_text, aes(x = Dose, y = prob, label = Study, group = CVCat)) +
        #facet_wrap(. ~ Cat, nrow = 3) + 
        scale_color_manual(values = cbPalette[2:5]) +
        scale_x_continuous(name = "Thyroid dose (Gy)") +
        scale_y_continuous(name = "Probability (Marker positive)", limits = c(0,1), breaks = seq(0,1,.2)) +
        coord_cartesian(xlim = c(0.01, 2.01), ylim = c(-0.01, 1.01)) + 
        #guides(color=FALSE) +
        theme(text = element_text(size=15), legend.position = c(0.3,0.2)) 
print(fp.2)


