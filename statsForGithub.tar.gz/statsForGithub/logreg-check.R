#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# Comparison of results with Morton 2021
# for surrogate CLIP2 marker (C2sur) and Mutation/Fusion marker (Driver type drv)
# jck, 2021/06/23
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# library
library(ggplot2)
library(survival)
#library(psych) # pairs.panels

library(caTools)
library(randomForest)
library(caret)
library(MLmetrics)
library(DescTools)
library(scoring)

library(grid)
library(gridExtra)

library(pROC)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# directories
datdir <- "~/imodel/CLIP2/stats/data"
setwd(datdir)

#-------------------------------------------------------------------
# Morton et al. 2021
#-------------------------------------------------------------------
setwd(datdir)
load(file = "PTC-edited-20210511.Rdata")
dim(df0) # 393  19
names(df0)
#[1] "Sex"          "AaO"          "AaE"          "Dose"         "CLIP2_VST_NT" "CLIP2_VST_TP" "cdelSNVr"     "cID8"         "drv"         
#[10] "C2rat"        "C2sur"        "AaEcat"       "AaE2"         "AaOcat"       "AaO2"         "TsE"          "TsE2"         "Dcat"        
#[19] "D3" 

str(df0)
summary(df0)

# check na's
#cs <- colSums(!is.na(df0))
#cs <- as.data.frame(cs)
#print(cs)

# like Selmansberger et al. 2015
#df0$lDose <- log(df0$Dose/1000)
#df0$lDose[df0$Dose == 0] <-  log(df0$AaO[df0$Dose == 0]/1000)
#df0$lDose[df0$Exposed == "no"] <-  log(df0$AaO[df0$Exposed == "no"]/1000)

# quick and dirty
#df0$lDose <- log((df0$Dose+1)/1000)

#--------------------------------------------
# driver type marker 
#--------------------------------------------

ddf <- df0[complete.cases(df0[,c("drv","Dose","AaO","AaE","TsE"),]),]
dim(ddf) # 383  19
table(ddf$drv)
# mut fus 
# 227 156 

range(ddf$Dose) # 0 5365

# logistic regression
dim(ddf)[1] # 383
mfm.1 <- glm(drv ~ Dose + AaO + Sex, data = ddf, family = "binomial")
summary(mfm.1)

prob = predict(mfm.1,type=c("response"))
g <- roc(drv ~ prob, data=ddf)
auc(g) 
ci.auc(g) 
BrierScore(as.numeric(ddf$drv)-1,prob) 

length(ddf$Dose [ddf$Dose > 1000]) # 15
ddf$Dose [ddf$Dose > 1000] <- 1000
range(ddf$Dose) # 0 1000
mfm.2 <- glm(drv ~ Dose + AaO + Sex, data = ddf, family = "binomial")
summary(mfm.2)

prob = predict(mfm.2,type=c("response"))
g <- roc(drv ~ prob, data=ddf)
auc(g) 
ci.auc(g) 
BrierScore(as.numeric(ddf$drv)-1,prob) # 0.2228592



mfm.5 <- glm(drv ~ lDose, data = ddf[ddf$AaE2 == ">=5",], family = "binomial")
summary(mfm.5)

#--------------------------------------------------------
# plotting
#--------------------------------------------------------

dr2Gy <- data.frame(seq(0.01,2,0.01))
names(dr2Gy) <- "DoseGy"
ldr2Gy <- data.frame(log(dr2Gy))
names(ldr2Gy) <- "lDose"

probab <- function(lp)
{
        1/(1+exp(-lp))
}

p975 <- qnorm(0.975)
p025 <- qnorm(0.025)

# build data frames for plotting
# AaO < 20
lp <- predict(ukr.2, newdata = ldr2Gy)
resp <- predict(ukr.2, newdata = ldr2Gy, type = "response")
lolp <- p025*predict(ukr.2, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(ukr.2, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
uf.2 <- data.frame("S2015 (CLIP2)","AaO", "AaO <20", dr2Gy, prob, lo, hi)
names(uf.2) <- c("Study","CV","Cat","Dose","prob","lo","hi")
uf.2

# AaO >= 20
lp <- predict(ukr.3, newdata = ldr2Gy)
lolp <- p025*predict(ukr.3, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(ukr.3, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
uf.3 <- data.frame("S2015 (CLIP2)","AaO", "AaO >=20",dr2Gy, prob, lo, hi)
names(uf.3) <- c("Study","CV","Cat","Dose","prob","lo","hi")
uf.3

# AaE < 5
lp <- predict(ukr.4, newdata = ldr2Gy)
lolp <- p025*predict(ukr.4, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(ukr.4, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
uf.4 <- data.frame("S2015 (CLIP2)","AaE", "AaE <5",dr2Gy, prob, lo, hi)
names(uf.4) <- c("Study","CV","Cat","Dose","prob","lo","hi")
uf.4

# AaE >= 5
lp <- predict(ukr.5, newdata = ldr2Gy)
lolp <- p025*predict(ukr.5, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(ukr.5, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
uf.5 <- data.frame("S2015 (CLIP2)","AaE", "AaE >=5",dr2Gy, prob, lo, hi)
names(uf.5) <- c("Study","CV","Cat","Dose","prob","lo","hi")
uf.5

uf <- rbind(uf.2,uf.3,uf.4,uf.5)
summary(uf)

# C2sur, Morton 2021
# AaO < 20
lp <- predict(mor.2, newdata = ldr2Gy)
lolp <- p025*predict(mor.2, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(mor.2, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
sf.2 <- data.frame("M2021 (CLIP2, surr.)","AaO", "AaO <20",dr2Gy, prob, lo, hi)
names(sf.2) <- c("Study","CV","Cat","Dose","prob","lo","hi")
sf.2

# AaO >= 20
lp <- predict(mor.3, newdata = ldr2Gy)
lolp <- p025*predict(mor.3, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(mor.3, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
sf.3 <- data.frame("M2021 (CLIP2, surr.)","AaO", "AaO >=20",dr2Gy, prob, lo, hi)
names(sf.3) <- c("Study","CV","Cat","Dose","prob","lo","hi")
sf.3

# AaE < 5
lp <- predict(mor.4, newdata = ldr2Gy)
lolp <- p025*predict(mor.4, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(mor.4, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
sf.4 <- data.frame("M2021 (CLIP2, surr.)","AaE", "AaE <5",dr2Gy, prob, lo, hi)
names(sf.4) <- c("Study","CV","Cat","Dose","prob","lo","hi")
sf.4

# AaE >= 5
lp <- predict(mor.5, newdata = ldr2Gy)
lolp <- p025*predict(mor.5, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(mor.5, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
sf.5 <- data.frame("M2021 (CLIP2, surr.)","AaE", "AaE >=5",dr2Gy, prob, lo, hi)
names(sf.5) <- c("Study","CV","Cat","Dose","prob","lo","hi")
sf.5

sf <- rbind(sf.2,sf.3,sf.4,sf.5)
summary(sf)

# Driver type, Morton 2021
# AaO < 20
lp <- predict(mfm.2, newdata = ldr2Gy)
lolp <- p025*predict(mfm.2, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(mfm.2, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
tf.2 <- data.frame("M2021 (driver)","AaO", "AaO <20",dr2Gy, prob, lo, hi)
names(tf.2) <- c("Study","CV","Cat","Dose","prob","lo","hi")
tf.2

# AaO >= 20
lp <- predict(mfm.3, newdata = ldr2Gy)
lolp <- p025*predict(mfm.3, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(mfm.3, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
tf.3 <- data.frame("M2021 (driver)","AaO", "AaO >=20",dr2Gy, prob, lo, hi)
names(tf.3) <- c("Study","CV","Cat","Dose","prob","lo","hi")
tf.3

# AaE < 5
lp <- predict(mfm.4, newdata = ldr2Gy)
lolp <- p025*predict(mfm.4, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(mfm.4, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
tf.4 <- data.frame("M2021 (driver)","AaE", "AaE <5",dr2Gy, prob, lo, hi)
names(tf.4) <- c("Study","CV","Cat","Dose","prob","lo","hi")
tf.4

# AaE >= 5
lp <- predict(mfm.5, newdata = ldr2Gy)
lolp <- p025*predict(mfm.5, newdata = ldr2Gy, se.fit = T)$se.fit
hilp <- p975*predict(mfm.5, newdata = ldr2Gy, se.fit = T)$se.fit
prob <- probab(lp)
lo <- probab(lp+lolp)
hi <- probab(lp+hilp)
tf.5 <- data.frame("M2021 (driver)","AaE", "AaE >=5",dr2Gy, prob, lo, hi)
names(tf.5) <- c("Study","CV","Cat","Dose","prob","lo","hi")
tf.5

tf <- rbind(tf.2,tf.3,tf.4,tf.5)
summary(tf)

#setwd(datdir)
#pf.2015 <- pf
#save(pf.2015, file = "PC2-Selmansberger2015-Rdata")

uf.AaO <- subset(uf, CV == "AaO")
sf.AaO <- subset(sf, CV == "AaO")
tf.AaO <- subset(tf, CV == "AaO")
pf <- rbind(uf.AaO,sf.AaO,tf.AaO)
summary(pf)

fp.1 <- ggplot() + 
        geom_line(data = pf, aes(x=Dose, y=prob, color = Study), size = 1.0) + 
        #geom_line(data = sf, aes(x=Dose, y=prob, color = Cat)) + 
        geom_ribbon(data = pf, aes(x=Dose,ymin=lo, ymax=hi, group = Study), alpha=0.2) +
        facet_wrap(. ~ Cat, nrow = 3) + 
        scale_color_manual(values = cbPalette[2:5]) +
        scale_x_continuous(name = "Thyroid dose (Gy)") +
        scale_y_continuous(name = "Probability (Marker+)", limits = c(0,1), breaks = seq(0,1,.2)) +
        coord_cartesian(xlim = c(0.01, 2.01), ylim = c(-0.01, 1.01)) + 
        #guides(color=FALSE) +
        theme(text = element_text(size=15)) 
print(fp.1)

#---------------------------------------------------------------
# plot with ERR from Tronko, cf. Kaiser 2016
#---------------------------------------------------------------
uf.AaOlo <- subset(uf, Cat == "AaO <20")
sf.AaOlo <- subset(sf, Cat == "AaO <20")
tf.AaOlo <- subset(tf, Cat == "AaO <20")
#pf <- rbind(uf.AaOlo,sf.AaOlo,tf.AaOlo)
#pf <- rbind(uf.AaOlo,tf.AaOlo)
pf <- rbind(uf.AaOlo,sf.AaOlo)
summary(pf)

# Tronko 2006
errm <- 5.25
errlo <- 1.7
errhi <- 27.5
pTm <- errm/(1+errm)
pTlo <- errlo/(1+errlo)
pThi <- errhi/(1+errhi)
p.T <- data.frame("AaO <20",1,pTm,pTlo,pThi)
names(p.T) <- c("CVCat","Dose","prob","hi","lo")

xline <- c(1.150)
yline <- c(0.8)
tline <- c("Tronko 2006")
cvcat <- c("AaO <20")
study_text <- data.frame(cvcat,tline,xline,yline)
names(study_text) <- c("CVCat","Study","Dose","prob")
study_text

fp.2 <- ggplot() + 
        geom_line(data = pf, aes(x=Dose, y=prob, color = Study), size = 1.0) + 
        #geom_line(data = sf, aes(x=Dose, y=prob, color = Cat)) + 
        geom_ribbon(data = pf, aes(x=Dose,ymin=lo, ymax=hi, group = Study), alpha=0.2) +
        geom_point(data = p.T, aes(x=Dose, y=prob), size=4) +
        geom_errorbar(data = p.T, aes(x=Dose, ymin=lo, ymax=hi), width = .1, size = 1) +
        geom_label(data = study_text, aes(x = Dose, y = prob, label = Study, group = CVCat)) +
        #facet_wrap(. ~ Cat, nrow = 3) + 
        scale_color_manual(values = cbPalette[2:5]) +
        scale_x_continuous(name = "Thyroid dose (Gy)") +
        scale_y_continuous(name = "Probability (Marker positive)", limits = c(0,1), breaks = seq(0,1,.2)) +
        coord_cartesian(xlim = c(0.01, 2.01), ylim = c(-0.01, 1.01)) + 
        #guides(color=FALSE) +
        theme(text = element_text(size=15), legend.position = c(0.3,0.2)) 
print(fp.2)

# validation
prob = predict(ukr.2,newdata=ddf[ddf$AaO2 == "<20",], type=c("response"))
g <- roc(drv ~ prob, data=ddf[ddf$AaO2 == "<20",])
auc(g) # Area under the curve: 0.6459
ci.auc(g) # 95% CI: 0.495-0.7969 (DeLong)
BrierScore(as.numeric(ddf$drv[ddf$AaO2 == "<20"])-1,prob) # 0.2316045

pLevel <- length(ddf$drv[ddf$drv == "fus" & ddf$AaO2 == "<20"])/length(ddf$drv[ddf$AaO2 == "<20"])
pLevel
pred <- factor(ifelse(prob > pLevel, "fus", "mut"))
confusionMatrix(reference = reorder(ddf$drv[ddf$AaO2 == "<20"]), data = pred, positive = "fus")


