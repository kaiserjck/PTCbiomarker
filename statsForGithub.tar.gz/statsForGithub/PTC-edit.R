#----------------------------------------------------------
# Treating NCI CLIP2 data
# jck, 2021/08/05
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

#------------------------------------------------------------
setwd("~/imodel/CLIP2/stats/data")
load(file = "PTC-selectedCOV-20210511.Rdata")
dim(df0) # 468   9
names(df0)
#[1] "SEX"                       "AGE_SURGERY"               "AGE_EXPOSURE"              "DOSE"                     
#[5] "CLIP2_VST_NT"              "CLIP2_VST_TP"              "WGS_TP_N_del_SNV_clonal"   "SigPro_DC83_Clonal_ID8_Ct"
#[9] "Designated_DriverType" 

# rename covariables
names(df0) <- c("Sex","AaO","AaE","Dose","CLIP2_VST_NT","CLIP2_VST_TP","cdelSNVr","cID8","drv")
str(df0)

# Sex
df0$Sex <- factor(df0$Sex, levels = c("female","male"), labels = c("w","m"))
str(df0)
table(df0$Sex)
#   w   m 
# 335 105 

#---------------------------------------------------------
# Driver type fusion vs. mutation
#---------------------------------------------------------
table(df0$drv)
df0$drv[df0$drv == "Fusion.IGF2/IGF2BP3"] <- "Fusion"
df0$drv[df0$drv == "Fusion.OtherRTK"] <- "Fusion"
df0$drv[df0$drv == "Fusion.RET"] <- "Fusion"
df0$drv[df0$drv == "NTRK3-Fusion"] <- "Fusion"
df0$drv[df0$drv == "Mut.BRAF"] <- "Mut"
df0$drv[df0$drv == "Mut.RAS"] <- "Mut"
df0$drv <- factor(df0$drv, levels = c("Mut","Fusion"), labels = c("mut","fus"))
table(df0$drv)
# mut fus 
# 253 176
#------------------------------------------------------
# Categories
#------------------------------------------------------

# only two levels
# AaO2
table(df0$AaO)
df0$AaO2[is.na(df0$AaO)!= T] <- 1
df0$AaO2[df0$AaO > 19 ] <- 2
df0$AaO2 <- factor(df0$AaO2, levels = c(1:2), labels = c("<20",">=20"))
table(df0$AaO2)
t.test(Dose ~ AaO2, data = df0)
chisq.test(table(df0$drv,df0$AaO2))

# TsE
TsE <- df0$AaO-df0$AaE
hist(TsE)
df0$TsE2[is.na(TsE)!= T] <- 1
df0$TsE2[TsE > 20] <- 2
df0$TsE2[df0$Dose == 0] <- 3
df0$TsE2 <- factor(df0$TsE2, levels = c(1:3), labels = c("<20",">=20","unexp"))
table(df0$TsE2)
t.test(Dose ~ TsE2, data = df0[df0$TsE2 != "unexp",])

# show NAs
dim(df0)
cs <- colSums(!is.na(df0))
cs <- as.data.frame(cs)
print(cs)

setwd("~/imodel/CLIP2/stats/data")
save(df0, file = "PTC-edited-20210805.Rdata")

