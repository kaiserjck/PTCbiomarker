#----------------------------------------------------------
# CLIP2 expression
# jck, 2021/08/03
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

# libraries
library(caTools)
library(randomForest)
library(caret)
library(MLmetrics)
library(DescTools)
library(scoring)
library(pdp) # for partial dependence plots from many packages!
library(vip)
library(pROC)
library(rstatix)
library(psych)

# plotting
library(ggplot2)
library(reshape2)
library(stringr)
library(directlabels)
library(metR)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

datdir <- "~/imodel/CLIP2/stats/data"
setwd(datdir)
load(file = "PTC-edited-20210511.Rdata")
dim(df0)
names(df0)
#[1] "Sex"          "AaO"          "AaE"          "Dose"         "CLIP2_VST_NT" "CLIP2_VST_TP" "cdelSNVr"     "cID8"         "drv"         
#[10] "C2rat"        "C2sur"        "AaEcat"       "AaE2"         "AaOcat"       "AaO2"         "TsE"          "TsE2"         "Dcat"        
#[19] "D3" 

#df <- subset(df0, Dose < 2000)


#---------------------------------------------------------------------------------
# CLIP2 expression in focus
#---------------------------------------------------------------------------------
df <- df0
dim(df)[1] # 393

df <- df[complete.cases(df[c("CLIP2_VST_TP","Sex","AaO","AaE","TsE","Dose")]),]
dim(df)[1] # 369

# remove 13 outliers]
hist(df$CLIP2_VST_TP)
df <- subset(df, CLIP2_VST_TP > 6)
hist(df$CLIP2_VST_TP)
dim(df)[1] # 356

# new covars
# Exposed
df$Exposed <- 1
df$Exposed[df$Dose > 0] <- 2
df$Exposed <- factor(df$Exposed, levels = 1:2, labels = c("no","yes"))
table(df$Exposed)
# no yes 
# 66 290

# Dose groups
df$D3 <- 1
df$D3[df$Dose > 0] <- 2
df$D3[df$Dose > 100] <- 3
df$D3 <- factor(df$D3, levels = 1:3, labels = c("unexp","<=100",">100"))
table(df$D3)
# unexp <=100  >100 
#   66   154   136 

# some tests
t.test(data = df, CLIP2_VST_TP ~ Sex)
t.test(data = df, CLIP2_VST_TP ~ Exposed)
t.test(data = df[df$AaO2 == "<20",], CLIP2_VST_TP ~ Exposed)
t.test(data = df[df$TsE2 != ">=20",], CLIP2_VST_TP ~ Exposed)

pwc <- pairwise_t_test(CLIP2_VST_TP ~ TsE2, p.adjust.method = "bonferroni", data = df)
pwc
pwc <- pairwise_t_test(CLIP2_VST_TP ~ D3, p.adjust.method = "bonferroni", data = df)
pwc

#---------------------------------------------------------------------------
# GLM+LOESS regression
#---------------------------------------------------------------------------
mf <- df

# subtract median of unexposed for simplification
mf$CLIP2exp <- mf$CLIP2_VST_TP-median(mf$CLIP2_VST_TP[mf$AaE2 == "unexp"])
mf$DoseGy <- mf$Dose/1000

dim(mf)[1] # 356

aggregate(df$Dose,list(df$TsE2),mean)
aggregate(df$Dose,list(df$TsE2),length)
aggregate(df$Dose,list(df$Exposed),mean)

# TsE2
ptc.1 <- glm(CLIP2exp ~ TsE2, data = mf) 
summary(ptc.1)

# AaE2
ptc.2 <- glm(CLIP2exp ~ AaE2, data = mf) 
summary(ptc.2)

ptc.3 <- glm(CLIP2exp ~ DoseGy*AaO, data = mf) 
summary(ptc.3)
sigma(ptc.3)


pl <- profile(ptc.3)
plot(pl)
coef(pl)
upar <- coef(pl)
lp.CI <- confint(pl)
round(lp.CI,5)

#Fit a polynomial surface determined by one or more numerical predictors, using local fitting.
los.1 <- loess(CLIP2exp ~ AaO * DoseGy, data = mf)
#summary(los.1)
hist(predict(los.1))
# residual standard error
los.1$s

los.2 <- loess(CLIP2exp ~ AaO * DoseGy, degree = 2, span = 0.9, data = mf)
#summary(los.2)
hist(predict(los.2))
# residual standard error
los.2$s

rf <- data.frame(mf,predict(los.2))
names(rf)[23] <- "CLIP2loess"
names(rf)

rt.1 <- glm(CLIP2exp ~ DoseGy, data = rf[rf$AaO<20,])
summary(rt.1)

rt.2 <- glm(CLIP2exp ~ DoseGy, data = rf[rf$AaO>=20,])
summary(rt.2)

rt.3 <- glm(CLIP2loess ~ DoseGy, data = rf[rf$AaO<20,])
summary(rt.3)

rt.4 <- glm(CLIP2loess ~ DoseGy, data = rf[rf$AaO>=20,])
summary(rt.4)

plot(x=rf$DoseGy[rf$AaO<20],y=rf$CLIP2loess[rf$AaO<20])
plot(x=rf$DoseGy[rf$AaO>=20],y=rf$CLIP2loess[rf$AaO>=20])

#-------------------------------------------------------------------------
# contour plots
# https://www.r-statistics.com/2016/07/using-2d-contour-plots-within-ggplot2-to-visualize-relationships-between-three-variables/
#-------------------------------------------------------------------------


pf <- mf
#pf$Dose[pf$Dose > 1000] <- 1000
#pf <-mf[mf$TsE2 != ">=20",]
dim(pf)[1]
#pf$DoseGy <- (pf$Dose+pf$AaO)/1000
pf$DoseGy <- pf$Dose/1000

#Fit a polynomial surface determined by one or more numerical predictors, using local fitting.
data.loess <- loess(CLIP2exp ~ AaO * DoseGy, degree = 2, span = 0.9, data = pf)
summary(data.loess)
hist(predict(data.loess))

# Create a sequence of incrementally increasing (by selected units) values for both AaO and DoseGy
xgrid <-  seq(min(pf$AaO), max(pf$AaO), 0.5)
ygrid <-  seq(min(pf$DoseGy), max(pf$DoseGy), 0.01)
# Generate a dataframe with every possible combination of AaO and DoseGy
data.fit <-  expand.grid(AaO = xgrid, DoseGy = ygrid)
# Feed the dataframe into the loess model and receive a matrix output with estimates of
# CLIP2exp for each combination of AaO and DoseGy
mtrx3d <-  predict(data.loess, newdata = data.fit)
# Abbreviated display of final matrix
mtrx3d[1:4, 1:4]
dim(mtrx3d)
dim(mtrx3d)[1]*dim(mtrx3d)[2]

contour(x = xgrid, y = ygrid, z = mtrx3d, xlab = "AaO", ylab = "DoseGy")

# Transform data to long form
mtrx.melt <- melt(mtrx3d, id.vars = c("AaO", "DoseGy"), measure.vars = "CLIP2exp")
names(mtrx.melt) <- c("AaO", "DoseGy", "CLIP2exp")
dim(mtrx.melt)

# Return data to numeric form
mtrx.melt$AaO <- as.numeric(str_sub(mtrx.melt$AaO, str_locate(mtrx.melt$AaO, "=")[1,1] + 1))
mtrx.melt$DoseGy <- as.numeric(str_sub(mtrx.melt$DoseGy, str_locate(mtrx.melt$DoseGy, "=")[1,1] + 1))

head(mtrx.melt)

brks <- c(-0.6,-0.4,-0.2,0,0.2,0.4,0.6)
cp.1 <- ggplot(data = mtrx.melt, aes(x=AaO,y=DoseGy,z=CLIP2exp)) +
  geom_contour(breaks = brks) +
  geom_dl(aes(label=..level..), method="bottom.pieces", 
          stat="contour", breaks = brks) +
  geom_point(data = pf, aes(x=AaO, y=DoseGy, color = Exposed)) +
  theme_bw () + 
  theme(text = element_text(size=15))

#direct.label(cp.1, list("top.bumptwice", dl.trans(y = y + 0.2)))
print(cp.1)

cp.2 <- ggplot(data = mtrx.melt, aes(x=AaO,y=DoseGy,z=CLIP2exp)) +
  geom_contour(breaks = brks) +
  geom_text_contour(breaks = brks, size = 4) +
#  geom_dl(aes(label=..level..), method="bottom.pieces", 
#          stat="contour", breaks = brks) +
  geom_point(data = pf, aes(x=AaO, y=DoseGy, color = Exposed)) +
  theme_bw () + 
  theme(text = element_text(size=15))

#direct.label(cp.1, list("top.bumptwice", dl.trans(y = y + 0.2)))
print(cp.2)

cp.3 <- ggplot(data = mtrx.melt, aes(x=AaO,y=DoseGy,z=CLIP2exp)) +
  geom_contour_fill(breaks = brks, alpha = 0.3) +
  scale_y_continuous(name = "Thyroid dose (Gy)") + 
  scale_x_continuous(name = "Age at Operation (yr)", breaks = seq(10,45,5)) + 
  #scale_fill_gradientn(colours = terrain.colors(7)) +
  scale_fill_gradientn(name= "CLIP2\nexpr.", colours = colorspace::diverge_hcl(7), breaks = brks, labels = factor(brks)) +
  geom_contour(color = "black", size = 0.1, breaks = brks) +
  geom_text_contour(breaks = brks, size = 4) +
  geom_point(data = pf, aes(x=AaO, y=DoseGy, color = Exposed)) +
  coord_cartesian(ylim = c(0,3)) +
  geom_vline(xintercept = 20, linetype = "dashed") +
  theme_bw () + 
  theme(text = element_text(size=15))

#direct.label(cp.1, list("top.bumptwice", dl.trans(y = y + 0.2)))
print(cp.3)






#-----------------------------------------------------------------------------------------
# selection of covariables
#-----------------------------------------------------------------------------------------
# select covariables for random forest
selline <- c("CLIP2exp", # shifted CLIP2_VST_TP
             "DoseGy", "AaO"
)
#-------------------------------------------------------------------------
# train/test analysis for hyperparameter: hold-out of 30% test data
#-------------------------------------------------------------------------
set.seed(1202)
# generate nsample sets of train/test data
# share of outcome cluster is maintained by createDataPartition (caret)
nsample <- 100
sample <- createDataPartition(mf$CLIP2exp, p=.7, list=FALSE, times = nsample)
train <- mf[sample[,nsample],selline]
test <- mf[-sample[,nsample],selline]
dim(train)[1]/dim(mf)[1]

# hyperparameter testing: span, degree
vspan <- seq(0.3,1,0.1)
lr.rse <- vector()
ts.rse <- vector()

mmcall <- 0
for(j in 1:length(vspan))
{
  vrse.lr <- vector()
  vrse.ts <- vector()
  for(i in 1:nsample)
  {
    mmcall <- mmcall+1
    lf <- mf[sample[,i],selline] # learn frame
    tf <- mf[-sample[,i],selline]  # test frame
  
    los.lr <- loess(CLIP2exp ~ DoseGy+AaO, degree = 1, span = vspan[j], 
                    control=loess.control(surface="direct"), # enable extrapolation to avoid NAs 
                    data = lf) # learn
    #vrse.lr[i] <- los.lr$s
    ss.lr <- sum(residuals(los.lr)^2)
    vrse.lr[i] <- sqrt(ss.lr/dim(lf)[1])
  
    # calculate test statistics
    CLIP2loess <- predict(los.lr, newdata = tf)
    ss.ts <- sum((tf$CLIP2exp - CLIP2loess)^2)
    vrse.ts[i] <- sqrt(ss.ts/dim(tf)[1])
  }
  lr.rse[j] <- mean(vrse.lr)
  ts.rse[j] <- mean(vrse.ts)
}

for(j in 1:length(vspan))
{
  cat(sprintf(" %2d %6.2f %8.4f %8.4f\n", j, vspan[j],lr.rse[j],ts.rse[j]))
}










