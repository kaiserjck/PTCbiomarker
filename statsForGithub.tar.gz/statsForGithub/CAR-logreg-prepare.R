#----------------------------------------------------------
# Reanalysis of PTC data from 2015
# jck, 2021/06/21
#----------------------------------------------------------
rm(list = ls()) # remove all objects from the current workspace

datdir <- "~/imodel/CLIP2/stats/data"
setwd(datdir)

load(file = "CLIP2_GT_UK_DOSE_reduced_20140915.Rdata")
names(thyroid)
#[1] "Case"     "Cohort"   "Gender"   "Oblast"   "AaO"      "AaE"      "Latency"  "Type"     "DST"      "Exposed"  "Score"    "CN"      
#[13] "Clip2"    "RET"      "BRAF"     "Dose"     "Log_dose" "DOSE_OLD" "Comment"  "DoseGy"   "Clip2n"   "Clip2sym" "Clip2col" "agecat2"  


# renaming
names(thyroid)[7] <- c("TsE")
names(thyroid)[17] <- c("l10Dose")

#Exposed
thyroid$expo <- 2
thyroid$expo[thyroid$Exposed == "no"] <- 1
thyroid$expo <- factor(thyroid$expo, levels = 1:2, c("no","yes"))
thyroid$Exposed <- thyroid$expo
table(thyroid$Exposed)

# Sex
thyroid$Sex <- 2
thyroid$Sex[thyroid$Gender == "Male"] <- 1
thyroid$Sex <- factor(thyroid$Sex, levels = 1:2, labels = c("m","w"))
table(thyroid$Sex)

# Clip2
thyroid$C2 <- 2
thyroid$C2[thyroid$Clip2 == "negative"] <- 1
thyroid$C2 <- factor(thyroid$C2, levels = 1:2, c("neg","pos"))
table(thyroid$C2)
thyroid$Clip2 <- thyroid$C2

# AaO2
thyroid$AaO2 <- 1
thyroid$AaO2[thyroid$AaO >= 20] <- 2
thyroid$AaO2 <- factor(thyroid$AaO2, levels = 1:2, c("<20", ">=20"))
table(thyroid$AaO2)

#AaE2
thyroid$AaE2 <- 1
thyroid$AaE2[thyroid$AaE >= 5] <- 2
thyroid$AaE2[thyroid$Exposed == "no"] <- 3
thyroid$AaE2 <- factor(thyroid$AaE2, levels = 1:3, c("<5", ">=5","unexposed"))
table(thyroid$AaE2)

#TsE2
thyroid$TsE2 <- 1
thyroid$TsE2[thyroid$TsE >= 20] <- 2
thyroid$TsE2[thyroid$Exposed == "no"] <- 3
thyroid$TsE2 <- factor(thyroid$TsE2, levels = 1:3, c("<20", ">=20","unexposed"))
table(thyroid$TsE2)

dim(thyroid)
str(thyroid)

selline <- c("Case","Clip2","Dose","l10Dose","DoseGy","Cohort","Sex","Oblast",
             "AaO","AaO2","AaE","AaE2","TsE","TsE2",
             "Type","DST","Exposed","Score","CN",      
             "RET","BRAF"
             )

ef <- thyroid[,selline]
dim(ef)
str(ef)
summary(ef)

thyroid <- ef
setwd(datdir)
save(thyroid, file = "CLIP2_20210621.Rdata")


